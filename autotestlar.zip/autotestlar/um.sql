-- mistakes_upgrade.sql
-- Adds:
-- 1) attempts.hidden_from_mistakes
-- 2) mistake_resolutions table (per-user per-question "mark as done")
-- Safe to run multiple times.

BEGIN;

-- 1) Hide an attempt from mistakes list (does NOT delete history)
ALTER TABLE attempts
  ADD COLUMN IF NOT EXISTS hidden_from_mistakes boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_attempts_user_hidden_mistakes
  ON attempts(user_id, hidden_from_mistakes);

-- 2) Mark a question as "done" (resolved) for overall mistakes (deduped)
CREATE TABLE IF NOT EXISTS mistake_resolutions (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  resolved_at timestamptz NOT NULL DEFAULT now(),
  source_attempt_id uuid NULL REFERENCES attempts(id) ON DELETE SET NULL,
  note text NULL,
  PRIMARY KEY (user_id, question_id)
);

CREATE INDEX IF NOT EXISTS idx_mistake_resolutions_user_resolved_at
  ON mistake_resolutions(user_id, resolved_at DESC);

COMMIT;
