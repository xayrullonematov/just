import os
from app.core.config import settings
from app.core.security import hash_password
from app.db.session import SessionLocal
from app.models.models import Category, CorrectAnswer, Notification, Option, Question, Test, User


def _is_non_local_env(app_env: str) -> bool:
    return (app_env or "dev").lower() not in {"dev", "development", "local", "test"}


def ensure_seed_allowed() -> None:
    if _is_non_local_env(settings.app_env) and os.getenv("ALLOW_PROD_SEED") != "1":
        raise RuntimeError("Refusing to run seed script outside local/test env. Set ALLOW_PROD_SEED=1 to override.")


def run():
    ensure_seed_allowed()

    db = SessionLocal()
    user = db.query(User).filter_by(email='demo@example.com').first()
    if not user:
        user = User(email='demo@example.com', name='Demo', password_hash=hash_password('demo12345'), is_email_verified=True, is_admin=True)
        db.add(user)
        db.flush()
    else:
        user.is_admin = True


    category_defaults = [
        ("yol_belgilari", "Yo'l belgilari"),
        ("yol_chiziqlari", "Yo'l chiziqlari"),
        ("svetofor", "Svetofor"),
        ("harakat_qoidalari", "Harakatlanish qoidalari"),
        ("ustuvorlik", "Ustuvorlik qoidalari"),
        ("tormoz_va_toxtash", "Tormozlash va to'xtash"),
        ("birinchi_yordam", "Birinchi tibbiy yordam"),
        ("transport_vositasi", "Transport vositasi"),
        ("chorrahalar", "Chorrahalar"),
        ("piyodalar", "Piyodalar"),
    ]
    for slug, name in category_defaults:
        if not db.query(Category).filter_by(slug=slug).first():
            db.add(Category(slug=slug, name=name, parent_id=None))

    test = db.query(Test).filter_by(title='Bilet 1').first()
    if not test:
        test = Test(title='Bilet 1', type='ticket', question_count=2, time_limit_seconds=1200, selection_strategy='bilet', filter_json={'bilet_number': 1})
        db.add(test)
        db.flush()

        q1 = Question(test_id=test.id, text='YHQ savol 1?', bilet_number=1, question_number=1)
        q2 = Question(test_id=test.id, text='YHQ savol 2?', bilet_number=1, question_number=2)
        db.add_all([q1, q2])
        db.flush()
        o11 = Option(question_id=q1.id, text='A')
        o12 = Option(question_id=q1.id, text='B')
        o21 = Option(question_id=q2.id, text='A')
        o22 = Option(question_id=q2.id, text='B')
        db.add_all([o11, o12, o21, o22])
        db.flush()
        db.add_all([CorrectAnswer(question_id=q1.id, option_id=o11.id), CorrectAnswer(question_id=q2.id, option_id=o22.id)])


    daily_test = db.query(Test).filter_by(type='daily').first()
    if not daily_test:
        daily_test = Test(title='Kunlik test', type='daily', question_count=20, time_limit_seconds=None, selection_strategy='daily', filter_json={})
        db.add(daily_test)

    if not db.query(Notification).filter_by(user_id=user.id).first():
        db.add(Notification(user_id=user.id, title='Xush kelibsiz', body='Platformaga hush kelibsiz!', is_read=False))

    db.commit()
    db.close()


if __name__ == '__main__':
    run()
