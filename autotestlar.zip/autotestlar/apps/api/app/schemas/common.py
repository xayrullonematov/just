from pydantic import BaseModel


class APIErrorPayload(BaseModel):
    code: str
    message: str
    field: str | None = None
    details: dict = {}


class APIError(BaseModel):
    error: APIErrorPayload
