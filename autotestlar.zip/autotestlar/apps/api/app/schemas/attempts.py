from datetime import datetime
from pydantic import BaseModel


class StartAttemptIn(BaseModel):
    test_id: str
    mode: str


class StartAttemptOut(BaseModel):
    attempt_id: str
    expires_at: datetime | None


class AnswerIn(BaseModel):
    question_id: str
    option_id: str
