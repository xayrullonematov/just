from datetime import datetime, timedelta, timezone
import uuid

from sqlalchemy import select, exists, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.models import Attempt, AttemptQuestion, Test, Question, Option, CorrectAnswer, Answer
from app.core.config import settings


EXAM_QUESTION_COUNT = 20
EXAM_TIME_LIMIT_SECONDS = 25 * 60  # 1500


def _error(code: str, message: str, details: dict | None = None):
    return {"error": {"code": code, "message": message, "field": None, "details": details or {}}}


# ✅ FIX 3: r2_key → full CDN URL
def _r2_public_url(r2_key: str | None) -> str | None:
    key = (r2_key or "").strip().lstrip("/")
    if not key:
        return None
    if key.startswith("http://") or key.startswith("https://"):
        return key
    base = (settings.r2_public_base_url or "").strip().rstrip("/")
    if not base:
        return None
    return f"{base}/{key}"

def _select_questions_for_test(db: Session, test: Test):
    strategy = (test.selection_strategy or "by_test").lower()
    filters = test.filter_json or {}

    base = select(Question)

    if strategy == "random":
        query = base.order_by(func.random()).limit(test.question_count)

    elif strategy == "bilet":
        bilet_number = filters.get("bilet_number")
        if bilet_number is None:
            return []
        query = (
            base.where(Question.bilet_number == int(bilet_number))
            .order_by(Question.question_number.asc().nulls_last(), Question.id.asc())
            .limit(test.question_count)
        )

    elif strategy == "category":
        category_id = filters.get("category_id")
        if not category_id:
            return []
        query = (
            base.where(Question.category_id == uuid.UUID(str(category_id)))
            .order_by(func.random())
            .limit(test.question_count)
        )

    elif strategy == "daily":
        bilet_number = filters.get("bilet_number")
        if bilet_number is not None:
            query = base.where(Question.bilet_number == int(bilet_number)).order_by(func.random()).limit(test.question_count)
        else:
            query = base.order_by(func.random()).limit(test.question_count)

    elif strategy == "by_test":
        query = base.where(Question.test_id == test.id).limit(test.question_count)

    else:
        return []

    return db.scalars(query).all()


def _select_exam_questions(db: Session):
    query = select(Question).order_by(func.random()).limit(EXAM_QUESTION_COUNT)
    return db.scalars(query).all()


def start_attempt(db: Session, user_id: uuid.UUID, test_id: uuid.UUID, mode: str):
    mode_norm = (mode or "").lower().strip() or "exam"

    active = db.scalar(
        select(Attempt).where(
            Attempt.user_id == user_id,
            Attempt.test_id == test_id,
            Attempt.mode == mode_norm,
            Attempt.status == "in_progress",
        )
    )
    if active:
        return active

    test = db.get(Test, test_id)
    if not test:
        return _error("TEST_NOT_FOUND", "Test topilmadi.")

    if mode_norm == "exam":
        total_questions = db.scalar(select(func.count()).select_from(Question)) or 0
        if total_questions < EXAM_QUESTION_COUNT:
            return _error(
                "NOT_ENOUGH_QUESTIONS",
                "Imtihonni boshlash uchun savollar yetarli emas.",
                {"required": EXAM_QUESTION_COUNT, "available": int(total_questions)},
            )

        expires_at = datetime.now(timezone.utc) + timedelta(seconds=EXAM_TIME_LIMIT_SECONDS)

        attempt = Attempt(
            user_id=user_id,
            test_id=test_id,
            mode=mode_norm,
            status="in_progress",
            expires_at=expires_at,
        )
        db.add(attempt)
        db.flush()

        questions = _select_exam_questions(db)
        if len(questions) < EXAM_QUESTION_COUNT:
            db.rollback()
            return _error(
                "NOT_ENOUGH_QUESTIONS",
                "Imtihonni boshlash uchun savollar yetarli emas.",
                {"required": EXAM_QUESTION_COUNT, "available": int(len(questions))},
            )

        for idx, q in enumerate(questions, start=1):
            db.add(AttemptQuestion(attempt_id=attempt.id, index=idx, question_id=q.id))

        db.commit()
        db.refresh(attempt)
        return attempt

    expires_at = None
    if mode_norm == "exam" and test.time_limit_seconds:
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=test.time_limit_seconds)

    attempt = Attempt(user_id=user_id, test_id=test_id, mode=mode_norm, status="in_progress", expires_at=expires_at)
    db.add(attempt)
    db.flush()

    questions = _select_questions_for_test(db, test)
    if not questions:
        db.rollback()
        return _error("QUESTIONS_NOT_FOUND", "Test uchun savollar topilmadi.")

    for idx, q in enumerate(questions, start=1):
        db.add(AttemptQuestion(attempt_id=attempt.id, index=idx, question_id=q.id))

    db.commit()
    db.refresh(attempt)
    return attempt


def guard_active_time(db: Session, attempt: Attempt):
    if attempt.status != "in_progress":
        return _error("ATTEMPT_NOT_ACTIVE", "Urinish aktiv emas.")
    if attempt.expires_at:
        expires = attempt.expires_at if attempt.expires_at.tzinfo else attempt.expires_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            attempt.status = "timed_out"
            db.commit()
            return _error("TIME_EXPIRED", "Vaqt tugadi.", {"attempt_id": str(attempt.id)})
    return None


def submit_answer(db: Session, attempt: Attempt, question_id: uuid.UUID, option_id: uuid.UUID):
    locked_attempt = db.scalar(select(Attempt).where(Attempt.id == attempt.id).with_for_update())
    if not locked_attempt:
        return _error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.")

    if locked_attempt.status != "in_progress":
        return _error("ATTEMPT_NOT_ACTIVE", "Urinish aktiv emas.")

    if locked_attempt.expires_at:
        expires = locked_attempt.expires_at if locked_attempt.expires_at.tzinfo else locked_attempt.expires_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires:
            locked_attempt.status = "timed_out"
            db.commit()
            return _error("TIME_EXPIRED", "Vaqt tugadi.", {"attempt_id": str(locked_attempt.id)})

    target = db.scalar(
        select(AttemptQuestion)
        .where(
            AttemptQuestion.attempt_id == locked_attempt.id,
            ~exists(select(Answer.id).where(Answer.attempt_id == locked_attempt.id, Answer.question_id == AttemptQuestion.question_id)),
        )
        .order_by(AttemptQuestion.index.asc())
        .limit(1)
    )
    if not target or target.question_id != question_id:
        return _error("INVALID_SEQUENCE", "Faqat navbatdagi savolga javob berish mumkin.")

    current_index = target.index

    option = db.scalar(select(Option).where(Option.id == option_id, Option.question_id == question_id))
    if not option:
        return _error("OPTION_INVALID", "Variant noto'g'ri savolga tegishli.")

    existing = db.scalar(select(Answer).where(Answer.attempt_id == locked_attempt.id, Answer.question_id == question_id))
    if existing:
        return _error("DUPLICATE_ANSWER", "Savolga allaqachon javob berilgan.")

    correct = db.scalar(select(CorrectAnswer).where(CorrectAnswer.question_id == question_id))
    is_correct = bool(correct and correct.option_id == option_id)

    # ✅ FIX 1: attempt counters yangilanadi (DB da 0 qolmaydi)
    locked_attempt.answered_count = int(locked_attempt.answered_count or 0) + 1
    locked_attempt.correct_answers = int(locked_attempt.correct_answers or 0) + (1 if is_correct else 0)

    db.add(Answer(attempt_id=locked_attempt.id, question_id=question_id, option_id=option_id, is_correct=is_correct))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        duplicate = db.scalar(select(Answer).where(Answer.attempt_id == locked_attempt.id, Answer.question_id == question_id))
        if duplicate:
            return _error("DUPLICATE_ANSWER", "Savolga allaqachon javob berilgan.")
        return _error("ANSWER_CONFLICT", "Javob yuborishda kolliziya yuz berdi. Qayta urinib ko'ring.")

    # ✅ FIX 2: live totals frontend uchun
    answered_count = int(locked_attempt.answered_count or 0)
    correct_total = int(locked_attempt.correct_answers or 0)
    wrong_total = answered_count - correct_total

    # keyingi unanswered savolni topamiz
    next_aq = db.scalar(
        select(AttemptQuestion)
        .where(
            AttemptQuestion.attempt_id == locked_attempt.id,
            ~exists(
                select(Answer.id).where(
                    Answer.attempt_id == locked_attempt.id,
                    Answer.question_id == AttemptQuestion.question_id,
                )
            ),
        )
        .order_by(AttemptQuestion.index.asc())
        .limit(1)
    )

    next_payload = None
    if next_aq:
        next_q = db.get(Question, next_aq.question_id)
        if next_q:
            # ✅ FIX 4: options tartibli, har doim bir xil
            opts = db.scalars(
                select(Option)
                .where(Option.question_id == next_q.id)
                .order_by(Option.id.asc())
            ).all()
            next_payload = {
                "index": int(next_aq.index),
                "question": {
                    "id": str(next_q.id),
                    "text": next_q.text,
                    # ✅ FIX 3: r2_key → to'liq CDN URL
                    "image_url": _r2_public_url(next_q.r2_key),
                    "options": [{"id": str(o.id), "text": o.text} for o in opts],
                },
            }

    return {
        "ok": True,
        "is_correct": is_correct,
        "answered_count": answered_count,
        "correct_total": correct_total,
        "wrong_total": wrong_total,
        "next_index": current_index + 1,
        "next": next_payload,
    }
