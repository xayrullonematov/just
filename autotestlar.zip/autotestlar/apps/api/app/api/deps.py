import secrets
import uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.models.models import User, WebSession
from app.core.security import decode_access_token
from fastapi import Cookie, Depends, Header

def error(code: str, message: str, field: str | None = None, details: dict | None = None):
    return {"error": {"code": code, "message": message, "field": field, "details": details or {}}}


def get_current_user_from_session(db: Session, session_id: str | None):
    if not session_id:
        return None
    rec = db.scalar(select(WebSession).where(WebSession.id == session_id))
    if not rec:
        return None
    now = datetime.now(timezone.utc)
    expires = rec.expires_at if rec.expires_at.tzinfo else rec.expires_at.replace(tzinfo=timezone.utc)
    if expires <= now:
        return None
    rec.last_seen_at = now
    try:
        db.commit()
    except Exception:
        db.rollback()
    return db.scalar(select(User).where(User.id == rec.user_id, User.deleted_at.is_(None)))


def get_current_user(db: Session, access_token: str | None, session_id: str | None = None):
    user = get_current_user_from_session(db, session_id)
    if user:
        return user

    if not access_token:
        return None
    user_id = decode_access_token(access_token)
    if not user_id:
        return None
    return db.scalar(select(User).where(User.id == uuid.UUID(user_id), User.deleted_at.is_(None)))


def ensure_csrf(csrf_cookie: str | None, csrf_header: str | None):
    return bool(csrf_cookie and csrf_header and secrets.compare_digest(csrf_cookie, csrf_header))

def current_user_dep(
    db: Session,
    access_token: str | None = Cookie(None),
    session_id: str | None = Cookie(None),
):
    # cookie’dan olingan token/session bilan mavjud funksiyangni ishlatamiz
    return get_current_user(db, access_token=access_token, session_id=session_id)


def csrf_ok_dep(
    csrf_cookie: str | None = Cookie(None, alias="csrf_token"),
    csrf_header: str | None = Header(None, alias="X-CSRF-Token"),
):
    return ensure_csrf(csrf_cookie, csrf_header)
