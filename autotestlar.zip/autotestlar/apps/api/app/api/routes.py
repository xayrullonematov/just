import csv
import io
import json
import re
import secrets
import urllib.parse
import uuid
from datetime import datetime, timedelta, timezone

import httpx
from fastapi import APIRouter, Depends, Cookie, Header, UploadFile, File, Request
from fastapi.responses import JSONResponse, RedirectResponse
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token as google_id_token
from sqlalchemy import select, func, update, exists
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.models import (
    User,
    Session as UserSession,
    EmailVerification,
    PasswordReset,
    RecoveryCode,
    SecurityAuditEvent,
    Test,
    Attempt,
    AttemptQuestion,
    Question,
    Option,
    Answer,
    CorrectAnswer,
    Notification,
    AuthAccount,
    WebSession,
    Category,
    MistakeResolution,
)
from app.schemas.attempts import StartAttemptIn, AnswerIn
from app.services.attempts import start_attempt, submit_answer, guard_active_time
from app.api.deps import error, get_current_user, ensure_csrf
from app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_twofa_challenge_token,
    decode_twofa_challenge,
    generate_raw_token,
    hash_token,
    generate_totp_secret,
    verify_totp,
    generate_recovery_codes,
)
from app.core.rate_limit import hit
from app.core.config import settings
from app.core.email_service import send_email, render_verify_email, render_reset_email
from app.core.telegram_auth import verify_telegram_payload

router = APIRouter(prefix="/api/v1")

R2_KEY_PATTERN = re.compile(r"^questions/b\d{1,4}/q\d{1,4}_[a-zA-Z0-9._-]+$")
AVATAR_R2_KEY_PATTERN = re.compile(r"^avatars/[a-zA-Z0-9/_\.-]+$")


def json_error(code: str, message: str, status: int = 400, field: str | None = None, details: dict | None = None):
    return JSONResponse(status_code=status, content=error(code, message, field, details))


def _extract_next_url(raw_next: str | None) -> str:
    if not raw_next:
        return "/app"
    parsed = urllib.parse.urlparse(raw_next)
    if parsed.scheme or parsed.netloc:
        return "/app"
    if not raw_next.startswith("/"):
        return "/app"
    return raw_next


def require_auth(db: Session, access_token: str | None, session_id: str | None = None):
    return get_current_user(db, access_token, session_id=session_id)


def _ip(req: Request | None) -> str:
    if not req or not req.client:
        return "unknown"
    return req.client.host


def _valid_email(v: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v or ""))


def _strong_password(v: str) -> bool:
    return len(v or "") >= 8


def _review_allowed_for_status(status: str) -> bool:
    return status in {"finished", "timed_out"}


def _current_allowed_for_status(status: str) -> bool:
    return status == "in_progress"


def _validate_profile_name(raw_name: str) -> tuple[str | None, JSONResponse | None]:
    name = str(raw_name or "").strip()
    if not name:
        return None, json_error("NAME_REQUIRED", "Ism kiritilishi shart.", 400, field="name")
    if len(name) > 120:
        return None, json_error("NAME_TOO_LONG", "Ism juda uzun.", 400, field="name")
    return name, None


def _question_image_url(r2_key: str | None) -> str | None:
    key = (r2_key or "").strip()
    if not key:
        return None
    if key.startswith("http://") or key.startswith("https://"):
        return key
    key = key.lstrip("/")
    base = (settings.r2_public_base_url or "").strip().rstrip("/")
    if not base:
        return None
    return f"{base}/{key}"


def _normalize_question_r2_key(raw_key: str | None) -> str | None:
    key = (raw_key or "").strip().lstrip("/")
    if not key:
        return None
    if not R2_KEY_PATTERN.match(key):
        return None
    return key


def _normalize_avatar_r2_key(raw_key: str | None) -> str | None:
    key = (raw_key or "").strip().lstrip("/")
    if not key:
        return None
    if not AVATAR_R2_KEY_PATTERN.match(key):
        return None
    return key


def _user_avatar_url(user: User) -> str | None:
    avatar_key = _normalize_avatar_r2_key(getattr(user, "avatar_r2_key", None))
    if avatar_key:
        return _question_image_url(avatar_key)
    return user.avatar_url


def _normalize_avatar_url(raw_url: str | None) -> str | None:
    url = (raw_url or "").strip()
    if not url:
        return None
    if len(url) > 512:
        return None
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme.lower() != "https":
        return None
    if not parsed.hostname:
        return None
    if parsed.username or parsed.password:
        return None
    return url


def _is_expired(dt: datetime) -> bool:
    x = dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    return x < datetime.now(timezone.utc)


def _safe_commit(db: Session) -> bool:
    try:
        db.commit()
        return True
    except Exception:
        db.rollback()
        return False


def _sanitize_submit_answer_response(mode: str, result: dict) -> dict:
    return result


def _normalize_ts(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _build_weekly_correct_answers(rows: list[tuple[datetime | None, datetime | None, int]], now: datetime | None = None) -> list[int]:
    now_utc = _normalize_ts(now) or datetime.now(timezone.utc)
    start_day = now_utc.date() - timedelta(days=6)
    daily = {start_day + timedelta(days=i): 0 for i in range(7)}

    for finished_at, started_at, correct_answers in rows:
        ts = _normalize_ts(finished_at) or _normalize_ts(started_at)
        if not ts:
            continue
        day = ts.date()
        if day in daily:
            daily[day] += int(correct_answers or 0)

    return [daily[start_day + timedelta(days=i)] for i in range(7)]


def _compute_ranking_percent(position: int, participants: int) -> int | None:
    if position <= 0 or participants <= 0:
        return None
    return round((position / participants) * 100)


def _next_unanswered_attempt_question_query(attempt_id: uuid.UUID):
    return (
        select(AttemptQuestion)
        .where(
            AttemptQuestion.attempt_id == attempt_id,
            ~exists(
                select(Answer.id).where(
                    Answer.attempt_id == attempt_id,
                    Answer.question_id == AttemptQuestion.question_id,
                )
            ),
        )
        .order_by(AttemptQuestion.index.asc())
        .limit(1)
    )


def _set_cookie(res: JSONResponse | RedirectResponse, key: str, value: str, max_age: int | None = None, httponly: bool = True):
    kwargs = {
        "key": key,
        "value": value,
        "httponly": httponly,
        "secure": settings.cookie_secure,
        "samesite": settings.cookie_samesite,
        "path": "/",
    }
    if settings.cookie_domain:
        kwargs["domain"] = settings.cookie_domain
    if max_age is not None:
        kwargs["max_age"] = max_age
    res.set_cookie(**kwargs)


def _set_auth_cookies(res: JSONResponse | RedirectResponse, access_token: str, refresh_token: str):
    _set_cookie(res, settings.access_cookie_name, access_token, max_age=settings.refresh_token_expire_days * 24 * 3600)
    _set_cookie(res, settings.refresh_cookie_name, refresh_token, max_age=settings.refresh_token_expire_days * 24 * 3600)


def _set_session_cookie(res: JSONResponse | RedirectResponse, session_id: str):
    _set_cookie(res, settings.session_cookie_name, session_id, max_age=settings.session_ttl_days * 24 * 3600)


def _clear_auth_cookies(res: JSONResponse):
    opts = {"path": "/"}
    if settings.cookie_domain:
        opts["domain"] = settings.cookie_domain
    res.delete_cookie(settings.access_cookie_name, **opts)
    res.delete_cookie(settings.refresh_cookie_name, **opts)
    res.delete_cookie(settings.session_cookie_name, **opts)


def _clear_oauth_temp_cookies(res: RedirectResponse) -> RedirectResponse:
    res.delete_cookie("google_oauth_state", path="/", domain=settings.cookie_domain or None)
    res.delete_cookie("google_oauth_next", path="/", domain=settings.cookie_domain or None)
    return res


def _google_redirect_with_cookie_cleanup(url: str) -> RedirectResponse:
    return _clear_oauth_temp_cookies(RedirectResponse(url=url, status_code=302))


def audit(db: Session, event_type: str, user_id: uuid.UUID | None = None, ip: str | None = None, details: dict | None = None):
    db.add(SecurityAuditEvent(user_id=user_id, event_type=event_type, ip=ip, details=json.dumps(details or {}), created_at=datetime.now(timezone.utc)))


def _issue_refresh_session(db: Session, user_id: uuid.UUID):
    access = create_access_token(str(user_id))
    refresh = generate_raw_token()
    db.add(UserSession(
        user_id=user_id,
        refresh_token_hash=hash_token(refresh),
        created_at=datetime.now(timezone.utc),
        expires_at=datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_expire_days),
        revoked_at=None,
    ))
    return access, refresh


def _issue_web_session(db: Session, user_id: uuid.UUID, req: Request):
    sid = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    db.add(WebSession(
        id=sid,
        user_id=user_id,
        created_at=now,
        last_seen_at=now,
        expires_at=now + timedelta(days=settings.session_ttl_days),
        user_agent=(req.headers.get("user-agent") or "")[:512],
        ip=_ip(req),
    ))
    return sid


def _get_or_create_user_from_provider(
    db: Session,
    provider: str,
    provider_account_id: str,
    name: str,
    email: str | None,
    avatar_url: str | None,
    raw_profile: dict,
    email_verified: bool,
):
    acc = db.scalar(select(AuthAccount).where(AuthAccount.provider == provider, AuthAccount.provider_account_id == provider_account_id))
    user = db.get(User, acc.user_id) if acc else None

    if not user and email:
        user = db.scalar(select(User).where(User.email == email, User.deleted_at.is_(None)))

    now = datetime.now(timezone.utc)
    normalized_avatar_url = _normalize_avatar_url(avatar_url)
    if not user:
        user = User(
            email=email,
            name=(name or "User").strip()[:120],
            password_hash=None,
            is_email_verified=bool(email and email_verified),
            avatar_url=None,
            avatar_r2_key=None,
            created_at=now,
            updated_at=now,
            last_login_at=now,
        )
        db.add(user)
        db.flush()
    else:
        if email and not user.email:
            user.email = email
        if name:
            user.name = name[:120]
        if normalized_avatar_url and not user.avatar_r2_key and not user.avatar_url:
            user.avatar_url = normalized_avatar_url
        if email and email_verified:
            user.is_email_verified = True
        user.updated_at = now
        user.last_login_at = now

    if not acc:
        db.add(AuthAccount(
            user_id=user.id,
            provider=provider,
            provider_account_id=provider_account_id,
            email=email,
            raw_profile=raw_profile,
            created_at=now,
        ))
    else:
        acc.email = email
        acc.raw_profile = raw_profile

    return user


def _resolved_attempt_metrics(attempt: Attempt, total: int, answered: int, correct: int) -> tuple[int, int, int]:
    fallback_score = round(correct * 100 / (total or 1))
    score = attempt.score_percent if attempt.score_percent is not None else fallback_score
    answered_count = attempt.answered_count if attempt.answered_count is not None else answered
    correct_answers = attempt.correct_answers if attempt.correct_answers is not None else correct
    return score, answered_count, correct_answers


def _row_question_text(row: dict) -> str:
    return str(row.get("text") or row.get("question") or "").strip()


def _get_or_create_bilet_test(db: Session, bilet_number: int) -> Test:
    candidates = db.scalars(select(Test).where(Test.selection_strategy == "bilet", Test.type == "ticket")).all()
    for t in candidates:
        filt = t.filter_json or {}
        if str(filt.get("bilet_number")) == str(bilet_number):
            return t

    test = Test(
        title=f"Bilet {bilet_number}",
        type="ticket",
        question_count=10,
        time_limit_seconds=1200,
        selection_strategy="bilet",
        filter_json={"bilet_number": bilet_number},
        is_active=True,
    )
    db.add(test)
    db.flush()
    return test


def _get_or_create_category_by_slug(db: Session, slug: str) -> Category:
    normalized = (slug or "").strip().lower()
    if not normalized:
        return None
    cat = db.scalar(select(Category).where(Category.slug == normalized))
    if cat:
        return cat

    name = normalized.replace("_", " ").replace("-", " ").strip().title()
    cat = Category(name=name or normalized, slug=normalized, parent_id=None)
    db.add(cat)
    db.flush()
    return cat


_ALLOWED_IMPORT_CONTENT_TYPES = {
    "application/json",
    "text/json",
    "text/csv",
    "application/csv",
    "application/vnd.ms-excel",
    "application/octet-stream",
    "",
}


def _read_upload_text_limited(file_obj, max_bytes: int) -> str | None:
    chunks: list[bytes] = []
    total = 0
    while True:
        part = file_obj.read(1024 * 1024)
        if not part:
            break
        total += len(part)
        if total > max_bytes:
            return None
        chunks.append(part)
    try:
        return b"".join(chunks).decode("utf-8")
    except UnicodeDecodeError:
        return ""


def _json_structure_within_limits(root, max_depth: int, max_nodes: int) -> bool:
    stack: list[tuple[object, int]] = [(root, 1)]
    nodes = 0
    while stack:
        node, depth = stack.pop()
        nodes += 1
        if nodes > max_nodes or depth > max_depth:
            return False
        if isinstance(node, dict):
            for v in node.values():
                stack.append((v, depth + 1))
        elif isinstance(node, list):
            for v in node:
                stack.append((v, depth + 1))
    return True


def _parse_admin_import_payload(file: UploadFile):
    file_name = (file.filename or "").lower()
    if not (file_name.endswith('.json') or file_name.endswith('.csv')):
        return None, json_error("INVALID_FILE_TYPE", "Faqat .json yoki .csv fayl ruxsat etiladi.", 400)

    content_type = (file.content_type or "").lower().strip()
    if content_type not in _ALLOWED_IMPORT_CONTENT_TYPES:
        return None, json_error("INVALID_CONTENT_TYPE", "Fayl turi ruxsat etilmagan.", 415)

    file.file.seek(0)
    raw = _read_upload_text_limited(file.file, settings.admin_import_max_file_bytes)
    if raw is None:
        return None, json_error("FILE_TOO_LARGE", "Fayl hajmi juda katta.", 413, details={"max_bytes": settings.admin_import_max_file_bytes})
    if raw == "":
        return None, json_error("INVALID_ENCODING", "Fayl UTF-8 formatida bo'lishi kerak.", 400)

    if file_name.endswith('.json'):
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return None, json_error("INVALID_JSON", "JSON fayl formati noto'g'ri.", 400)

        if not _json_structure_within_limits(payload, settings.admin_import_max_json_depth, settings.admin_import_max_json_nodes):
            return None, json_error("JSON_TOO_COMPLEX", "JSON tuzilmasi juda murakkab.", 400)

        if not isinstance(payload, list):
            return None, json_error("INVALID_PAYLOAD", "JSON root qiymati massiv bo'lishi kerak.", 400)
        if len(payload) > settings.admin_import_max_rows:
            return None, json_error("TOO_MANY_ROWS", "Juda ko'p qator yuborildi.", 400, details={"max_rows": settings.admin_import_max_rows})
        return payload, None

    rows = list(csv.DictReader(io.StringIO(raw)))
    if len(rows) > settings.admin_import_max_rows:
        return None, json_error("TOO_MANY_ROWS", "Juda ko'p qator yuborildi.", 400, details={"max_rows": settings.admin_import_max_rows})
    return rows, None


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@router.get("/auth/csrf")
def auth_csrf(csrf_token: str | None = Cookie(default=None, alias=settings.csrf_cookie_name)):
    token = csrf_token or secrets.token_urlsafe(24)
    res = JSONResponse(content={"ok": True, "csrf_token": token})
    _set_cookie(res, settings.csrf_cookie_name, token, max_age=3600, httponly=False)
    return res


@router.get("/auth/me")
def auth_me(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    db.commit()
    return {"id": str(user.id), "email": user.email, "name": user.name, "avatar_url": _user_avatar_url(user), "avatar_r2_key": user.avatar_r2_key}


@router.get("/auth/google/start")
def auth_google_start(req: Request, next: str | None = None):
    if not settings.google_client_id:
        return json_error("GOOGLE_NOT_CONFIGURED", "Google OAuth sozlanmagan.", 500)
    if not hit(f"google:start:{_ip(req)}", 30, 60):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)

    safe_next = _extract_next_url(next)
    state = secrets.token_urlsafe(32)
    redirect_uri = f"{settings.backend_url}/api/v1/auth/google/callback"
    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "offline",
        "prompt": "select_account",
    }
    url = f"https://accounts.google.com/o/oauth2/v2/auth?{urllib.parse.urlencode(params)}"

    res = RedirectResponse(url=url, status_code=302)
    _set_cookie(res, "google_oauth_state", state, max_age=600, httponly=True)
    _set_cookie(res, "google_oauth_next", safe_next, max_age=600, httponly=True)
    return res


@router.get("/auth/google/callback")
async def auth_google_callback(
    req: Request,
    code: str | None = None,
    state: str | None = None,
    db: Session = Depends(get_db),
    google_state_cookie: str | None = Cookie(default=None, alias="google_oauth_state"),
    google_next_cookie: str | None = Cookie(default=None, alias="google_oauth_next"),
):
    safe_next = _extract_next_url(google_next_cookie)

    if not settings.google_client_id or not settings.google_client_secret:
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_not_configured")

    if not hit(f"google:callback:{_ip(req)}", 40, 60):
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=rate_limited")

    if not code:
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_code_missing")
    if not state or not google_state_cookie or not secrets.compare_digest(state, google_state_cookie):
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_state_invalid")

    redirect_uri = f"{settings.backend_url}/api/v1/auth/google/callback"

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            token_res = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "code": code,
                    "client_id": settings.google_client_id,
                    "client_secret": settings.google_client_secret,
                    "redirect_uri": redirect_uri,
                    "grant_type": "authorization_code",
                },
            )
            token_data = token_res.json()
    except Exception:
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_exchange_failed")

    if token_res.status_code >= 400 or not token_data.get("id_token"):
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_token_invalid")

    try:
        payload = google_id_token.verify_oauth2_token(
            token_data["id_token"],
            google_requests.Request(),
            settings.google_client_id,
        )
    except Exception:
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=google_id_token_invalid")

    if not payload.get("email") or not payload.get("email_verified"):
        return _google_redirect_with_cookie_cleanup(f"{settings.frontend_url}/login?error=email_not_verified")

    user = _get_or_create_user_from_provider(
        db=db,
        provider="google",
        provider_account_id=str(payload.get("sub") or ""),
        name=str(payload.get("name") or "User"),
        email=str(payload.get("email") or "").lower(),
        avatar_url=payload.get("picture"),
        raw_profile=payload,
        email_verified=bool(payload.get("email_verified")),
    )

    sid = _issue_web_session(db, user.id, req)
    access, refresh = _issue_refresh_session(db, user.id)
    audit(db, "google_login_success", user.id, _ip(req))
    db.commit()

    res = RedirectResponse(url=f"{settings.frontend_url}{safe_next}", status_code=302)
    _set_session_cookie(res, sid)
    _set_auth_cookies(res, access, refresh)
    return _clear_oauth_temp_cookies(res)


@router.post("/auth/telegram/callback")
def auth_telegram_callback(payload: dict, req: Request, db: Session = Depends(get_db)):
    if not settings.telegram_bot_token:
        return json_error("TELEGRAM_NOT_CONFIGURED", "Telegram auth sozlanmagan.", 500)
    if not hit(f"telegram:callback:{_ip(req)}", 60, 60):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)

    valid, message, status = verify_telegram_payload(
        payload,
        settings.telegram_bot_token,
        settings.telegram_auth_max_age_seconds,
    )
    if not valid:
        code = "TELEGRAM_NOT_CONFIGURED" if status == 500 else ("AUTH_EXPIRED" if "eskirgan" in message else "AUTH_FAILED")
        return json_error(code, message, status)

    telegram_id = str(payload.get("id") or "")
    if not telegram_id:
        return json_error("AUTH_FAILED", "Telegram user id yo'q.", 400)

    first = str(payload.get("first_name") or "").strip()
    last = str(payload.get("last_name") or "").strip()
    name = (first + " " + last).strip() or (payload.get("username") or "Telegram User")
    avatar_url = payload.get("photo_url")

    user = _get_or_create_user_from_provider(
        db=db,
        provider="telegram",
        provider_account_id=telegram_id,
        name=name,
        email=None,
        avatar_url=avatar_url,
        raw_profile=payload,
        email_verified=False,
    )

    sid = _issue_web_session(db, user.id, req)
    access, refresh = _issue_refresh_session(db, user.id)
    audit(db, "telegram_login_success", user.id, _ip(req))
    db.commit()

    res = JSONResponse(content={"ok": True, "redirect_to": f"{settings.frontend_url}/app"})
    _set_session_cookie(res, sid)
    _set_auth_cookies(res, access, refresh)
    return res


@router.get("/public/metrics")
def public_metrics(db: Session = Depends(get_db)):
    users = db.scalar(select(func.count()).select_from(User).where(User.deleted_at.is_(None))) or 0
    tests = db.scalar(select(func.count()).select_from(Test).where(Test.is_active == True)) or 0
    questions = db.scalar(select(func.count()).select_from(Question)) or 0
    return {"users": users, "tests": tests, "questions": questions}


@router.post("/auth/signup")
def auth_signup(payload: dict, req: Request, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    name = (payload.get("name") or "").strip() or "User"

    if not hit(f"signup:{_ip(req)}", 3, 600):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)
    if not _valid_email(email):
        return json_error("VALIDATION_ERROR", "Email noto'g'ri.", field="email")
    if not _strong_password(password):
        return json_error("WEAK_PASSWORD", "Parol kamida 8 belgidan iborat bo'lishi kerak.", field="password")
    if db.scalar(select(User).where(User.email == email)):
        return json_error("EMAIL_TAKEN", "Email band.", field="email")

    user = User(email=email, name=name, password_hash=hash_password(password), is_email_verified=False)
    db.add(user)
    db.flush()

    raw = generate_raw_token()
    db.add(EmailVerification(user_id=user.id, token_hash=hash_token(raw), expires_at=datetime.now(timezone.utc) + timedelta(hours=24), used_at=None))
    audit(db, "signup", user.id, _ip(req), {"email": email})
    db.commit()

    verify_url = f"/verify-email?token={raw}"
    send_email(email, "Verify your email", render_verify_email(verify_url))
    return {"ok": True, "verification_link": verify_url if settings.app_env == "dev" else None}


@router.post("/auth/verify-email")
def auth_verify_email(payload: dict, db: Session = Depends(get_db)):
    token = payload.get("token") or ""
    rec = db.scalar(select(EmailVerification).where(EmailVerification.token_hash == hash_token(token)))
    if not rec or rec.used_at is not None or _is_expired(rec.expires_at):
        return json_error("TOKEN_INVALID", "Tasdiqlash tokeni noto'g'ri yoki eskirgan.")
    user = db.get(User, rec.user_id)
    user.is_email_verified = True
    rec.used_at = datetime.now(timezone.utc)
    audit(db, "email_verified", user.id)
    db.commit()
    return {"ok": True}


@router.post("/auth/login")
def auth_login(payload: dict, req: Request, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    code = payload.get("code")
    recovery_code = payload.get("recovery_code")

    if not hit(f"login:{_ip(req)}:{email}", 5, 60):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)

    user = db.scalar(select(User).where(User.email == email, User.deleted_at.is_(None)))
    if not user or not user.password_hash or not verify_password(password, user.password_hash):
        audit(db, "login_failed", user.id if user else None, _ip(req), {"reason": "bad_credentials"})
        _safe_commit(db)
        return json_error("AUTH_FAILED", "Email yoki parol noto'g'ri.", 401)
    if not user.is_email_verified:
        return json_error("EMAIL_NOT_VERIFIED", "Email tasdiqlanmagan.", 403)

    if user.twofa_enabled:
        ok = False
        if code and user.twofa_secret:
            ok = verify_totp(user.twofa_secret, str(code))
        elif recovery_code:
            rec = db.scalar(select(RecoveryCode).where(RecoveryCode.user_id == user.id, RecoveryCode.code_hash == hash_token(str(recovery_code)), RecoveryCode.used_at.is_(None)))
            if rec:
                rec.used_at = datetime.now(timezone.utc)
                ok = True
        if not ok:
            challenge = create_twofa_challenge_token(str(user.id))
            audit(db, "twofa_required", user.id, _ip(req))
            db.commit()
            return json_error("TWO_FA_REQUIRED", "2FA tasdiqlash talab qilinadi.", 401, details={"challenge_token": challenge})

    user.last_login_at = datetime.now(timezone.utc)
    user.updated_at = datetime.now(timezone.utc)
    sid = _issue_web_session(db, user.id, req)
    access, refresh = _issue_refresh_session(db, user.id)
    audit(db, "login_success", user.id, _ip(req))
    db.commit()

    res = JSONResponse(content={"ok": True, "requires_2fa": False})
    _set_auth_cookies(res, access, refresh)
    _set_session_cookie(res, sid)
    return res


@router.post("/auth/2fa/setup")
def auth_2fa_setup(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    secret = generate_totp_secret()
    user.twofa_secret = secret
    user.twofa_enabled = False
    db.execute(update(RecoveryCode).where(RecoveryCode.user_id == user.id).values(used_at=datetime.now(timezone.utc)))
    codes = generate_recovery_codes(8)
    for c in codes:
        db.add(RecoveryCode(user_id=user.id, code_hash=hash_token(c), used_at=None, created_at=datetime.now(timezone.utc)))
    audit(db, "twofa_setup_started", user.id)
    db.commit()
    return {"ok": True, "secret": secret, "recovery_codes": codes}


@router.post("/auth/2fa/enable")
def auth_2fa_enable(
    payload: dict,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    code = str(payload.get("code") or "")
    if not user.twofa_secret or not verify_totp(user.twofa_secret, code):
        return json_error("TWO_FA_INVALID", "2FA kod noto'g'ri.")
    user.twofa_enabled = True
    audit(db, "twofa_enabled", user.id)
    db.commit()
    return {"ok": True}


@router.post("/auth/2fa/verify")
def auth_2fa_verify(payload: dict, req: Request, db: Session = Depends(get_db)):
    challenge = payload.get("challenge_token") or ""
    code = str(payload.get("code") or "")
    recovery_code = payload.get("recovery_code")
    if not hit(f"2fa_verify:{_ip(req)}", 6, 60):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)
    user_id = decode_twofa_challenge(challenge)
    if not user_id:
        return json_error("TOKEN_INVALID", "2FA challenge token yaroqsiz.", 401)
    try:
        parsed_user_id = uuid.UUID(user_id)
    except ValueError:
        return json_error("TOKEN_INVALID", "2FA challenge token yaroqsiz.", 401)
    user = db.get(User, parsed_user_id)
    if not user or not user.twofa_enabled:
        return json_error("UNAUTHORIZED", "2FA yoqilmagan.", 401)

    ok = False
    if code and user.twofa_secret:
        ok = verify_totp(user.twofa_secret, code)
    elif recovery_code:
        rec = db.scalar(select(RecoveryCode).where(RecoveryCode.user_id == user.id, RecoveryCode.code_hash == hash_token(str(recovery_code)), RecoveryCode.used_at.is_(None)))
        if rec:
            rec.used_at = datetime.now(timezone.utc)
            ok = True
    if not ok:
        audit(db, "twofa_verify_failed", user.id, _ip(req))
        db.commit()
        return json_error("TWO_FA_INVALID", "2FA kod noto'g'ri.", 401)

    sid = _issue_web_session(db, user.id, req)
    access, refresh = _issue_refresh_session(db, user.id)
    audit(db, "twofa_login_success", user.id, _ip(req))
    db.commit()
    res = JSONResponse(content={"ok": True})
    _set_auth_cookies(res, access, refresh)
    _set_session_cookie(res, sid)
    return res


@router.post("/auth/refresh")
def auth_refresh(
    db: Session = Depends(get_db),
    refresh_token: str | None = Cookie(default=None, alias="refresh_token"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    if not refresh_token:
        return json_error("UNAUTHORIZED", "Refresh token yo'q.", 401)

    rec = db.scalar(select(UserSession).where(UserSession.refresh_token_hash == hash_token(refresh_token), UserSession.revoked_at.is_(None)))
    if not rec or _is_expired(rec.expires_at):
        return json_error("UNAUTHORIZED", "Refresh token yaroqsiz.", 401)

    rec.revoked_at = datetime.now(timezone.utc)
    access, new_refresh = _issue_refresh_session(db, rec.user_id)
    audit(db, "token_refreshed", rec.user_id)
    db.commit()

    res = JSONResponse(content={"ok": True})
    _set_auth_cookies(res, access, new_refresh)
    return res


@router.post("/auth/logout")
def auth_logout(
    db: Session = Depends(get_db),
    req: Request = None,
    refresh_token: str | None = Cookie(default=None, alias="refresh_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    uid = None
    if refresh_token:
        rec = db.scalar(select(UserSession).where(UserSession.refresh_token_hash == hash_token(refresh_token), UserSession.revoked_at.is_(None)))
        if rec:
            uid = rec.user_id
            rec.revoked_at = datetime.now(timezone.utc)
    if session_id:
        s = db.scalar(select(WebSession).where(WebSession.id == session_id))
        if s:
            uid = uid or s.user_id
            db.delete(s)

    if uid:
        audit(db, "logout", uid, _ip(req) if req else None)
    db.commit()
    res = JSONResponse(content={"ok": True})
    _clear_auth_cookies(res)
    return res


@router.post("/auth/logout-all")
def auth_logout_all(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    db.execute(update(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None)).values(revoked_at=datetime.now(timezone.utc)))
    db.execute(update(WebSession).where(WebSession.user_id == user.id).values(expires_at=datetime.now(timezone.utc) - timedelta(seconds=1)))
    audit(db, "logout_all", user.id)
    db.commit()
    res = JSONResponse(content={"ok": True})
    _clear_auth_cookies(res)
    return res


@router.post("/auth/forgot-password")
def auth_forgot_password(payload: dict, req: Request, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    if not hit(f"forgot:{_ip(req)}:{email}", 3, 600):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)
    user = db.scalar(select(User).where(User.email == email, User.deleted_at.is_(None)))
    if user:
        raw = generate_raw_token()
        db.add(PasswordReset(user_id=user.id, token_hash=hash_token(raw), expires_at=datetime.now(timezone.utc) + timedelta(hours=1), used_at=None))
        link = f"/reset-password?token={raw}"
        send_email(email, "Reset your password", render_reset_email(link))
        audit(db, "forgot_password_requested", user.id, _ip(req))
        db.commit()
        if settings.app_env == "dev":
            return {"ok": True, "reset_link": link}
    return {"ok": True}


@router.post("/auth/reset-password")
def auth_reset_password(payload: dict, req: Request, db: Session = Depends(get_db)):
    token = payload.get("token") or ""
    new_password = payload.get("new_password") or ""
    if not hit(f"reset:{_ip(req)}", 3, 600):
        return json_error("RATE_LIMITED", "Juda ko'p urinish.", 429)
    if not _strong_password(new_password):
        return json_error("WEAK_PASSWORD", "Parol kamida 8 belgidan iborat bo'lishi kerak.", field="new_password")

    rec = db.scalar(select(PasswordReset).where(PasswordReset.token_hash == hash_token(token)))
    if not rec or rec.used_at is not None or _is_expired(rec.expires_at):
        return json_error("TOKEN_INVALID", "Parol tiklash tokeni noto'g'ri yoki eskirgan.")

    user = db.get(User, rec.user_id)
    now = datetime.now(timezone.utc)
    user.password_hash = hash_password(new_password)
    user.updated_at = now
    rec.used_at = now
    db.execute(update(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None)).values(revoked_at=now))
    db.execute(update(WebSession).where(WebSession.user_id == user.id).values(expires_at=now - timedelta(seconds=1), last_seen_at=now))
    audit(db, "password_reset", user.id, _ip(req))
    db.commit()
    return {"ok": True}


@router.get("/me")
def me(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    db.commit()
    return {"id": str(user.id), "email": user.email, "name": user.name, "is_email_verified": user.is_email_verified, "twofa_enabled": user.twofa_enabled, "avatar_url": _user_avatar_url(user), "avatar_r2_key": user.avatar_r2_key}


@router.get("/me/dashboard")
def me_dashboard(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)

    daily_limit = 10
    now_utc = datetime.now(timezone.utc)
    today_start = datetime(now_utc.year, now_utc.month, now_utc.day, tzinfo=timezone.utc)
    daily_done = db.scalar(select(func.count()).select_from(Attempt).where(Attempt.user_id == user.id, Attempt.mode == "daily", Attempt.started_at >= today_start)) or 0

    window_start = now_utc - timedelta(days=6)
    weekly_rows = db.execute(
        select(Attempt.finished_at, Attempt.started_at, Attempt.correct_answers)
        .where(
            Attempt.user_id == user.id,
            Attempt.status.in_(["finished", "timed_out"]),
            Attempt.correct_answers > 0,
            (Attempt.finished_at >= window_start) | (Attempt.started_at >= window_start),
        )
    ).all()
    weekly = _build_weekly_correct_answers(weekly_rows, now_utc)

    score_sub = (
        select(Attempt.user_id.label("user_id"), func.coalesce(func.sum(Attempt.correct_answers), 0).label("sum_correct"))
        .where(Attempt.status.in_(["finished", "timed_out"]))
        .group_by(Attempt.user_id)
        .subquery()
    )

    user_total_correct = db.scalar(
        select(score_sub.c.sum_correct).where(score_sub.c.user_id == user.id)
    )
    total_ranked_users = db.scalar(
        select(func.count()).select_from(score_sub).where(score_sub.c.sum_correct > 0)
    ) or 0

    ranking_percent = None
    if user_total_correct and user_total_correct > 0 and total_ranked_users > 0:
        better_users = db.scalar(
            select(func.count()).select_from(score_sub).where(score_sub.c.sum_correct > user_total_correct)
        ) or 0
        ranking_percent = _compute_ranking_percent(better_users + 1, total_ranked_users)

    active_tests = db.scalars(select(Test).where(Test.type == "ticket", Test.is_active == True).limit(3)).all()
    tasks = [{"title": t.title, "questions": t.question_count, "time_minutes": max((t.time_limit_seconds or 900) // 60, 1), "level": "O'rta"} for t in active_tests]

    return {
        "user_name": user.name,
        "subtitle": "Telegram Web App uchun moslashgan tezkor tayyorgarlik platformasi",
        "daily_limit": daily_limit,
        "daily_done": daily_done,
        "plan_name": "Bepul",
        "plan_note": "Izohlar va cheksiz testlar Premium rejada",
        "ranking_percent": ranking_percent,
        "weekly_correct_answers": weekly,
        "daily_tasks": tasks,
    }


@router.post("/me/profile")
def me_profile_update(
    payload: dict,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    name, name_error = _validate_profile_name(payload.get("name"))
    if name_error:
        return name_error

    user.name = name
    user.updated_at = datetime.now(timezone.utc)
    audit(db, "profile_updated", user.id)
    db.commit()
    return {"ok": True, "name": user.name, "email": user.email}


@router.post("/me/avatar")
def me_avatar(
    payload: dict,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    raw_avatar_key = payload.get("avatar_r2_key")
    raw_avatar_url = payload.get("avatar_url")

    if raw_avatar_url not in (None, "") and raw_avatar_key in (None, ""):
        return json_error("AVATAR_R2_KEY_REQUIRED", "Avatar uchun r2 key yuboring.", 400, field="avatar_r2_key")

    avatar_r2_key = _normalize_avatar_r2_key(str(raw_avatar_key) if raw_avatar_key is not None else None)
    if raw_avatar_key not in (None, "") and not avatar_r2_key:
        return json_error("AVATAR_R2_KEY_INVALID", "avatar_r2_key formati noto'g'ri.", 400, field="avatar_r2_key")

    user.avatar_r2_key = avatar_r2_key
    if avatar_r2_key:
        user.avatar_url = None

    user.updated_at = datetime.now(timezone.utc)
    audit(db, "avatar_updated", user.id)
    db.commit()
    return {"ok": True, "avatar_url": _user_avatar_url(user), "avatar_r2_key": user.avatar_r2_key}


@router.delete("/me")
def me_delete(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    user.deleted_at = datetime.now(timezone.utc)
    user.email = f"deleted+{user.id}@example.invalid"
    user.name = "Deleted User"
    db.execute(update(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None)).values(revoked_at=datetime.now(timezone.utc)))
    db.execute(update(WebSession).where(WebSession.user_id == user.id).values(expires_at=datetime.now(timezone.utc) - timedelta(seconds=1)))
    audit(db, "account_deleted", user.id)
    db.commit()

    res = JSONResponse(content={"ok": True})
    _clear_auth_cookies(res)
    return res


@router.get("/tests")
def list_tests(
    type: str = "ticket",
    include_progress: int = 1,
    page: int = 1,
    page_size: int = 20,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)

    page = max(page, 1)
    page_size = min(max(page_size, 1), 100)
    offset = (page - 1) * page_size

    # FIX: func.max(Attempt.id) on UUID is not supported in PostgreSQL.
    # Use func.max(Attempt.started_at) to find the latest attempt per test,
    # then re-join to get the actual Attempt.id for that row.
    latest_attempt_time_sub = (
        select(
            Attempt.test_id.label("test_id"),
            func.max(Attempt.started_at).label("max_started_at"),
        )
        .where(Attempt.user_id == user.id)
        .group_by(Attempt.test_id)
        .subquery()
    )
    latest_attempt_sub = (
        select(Attempt.id.label("last_attempt_id"), Attempt.test_id.label("test_id"))
        .join(
            latest_attempt_time_sub,
            (Attempt.test_id == latest_attempt_time_sub.c.test_id)
            & (Attempt.started_at == latest_attempt_time_sub.c.max_started_at)
            & (Attempt.user_id == user.id),
        )
        .subquery()
    )
    best_score_sub = (
        select(Attempt.test_id.label("test_id"), func.max(Attempt.score_percent).label("best_score_percent"))
        .where(Attempt.user_id == user.id)
        .group_by(Attempt.test_id)
        .subquery()
    )

    total = db.scalar(select(func.count()).select_from(Test).where(Test.type == type, Test.is_active == True)) or 0

    rows = db.execute(
        select(
            Test.id,
            Test.title,
            Test.question_count,
            Test.time_limit_seconds,
            latest_attempt_sub.c.last_attempt_id,
            Attempt.status.label("last_attempt_status"),
            Attempt.score_percent.label("last_score_percent"),
            Attempt.answered_count.label("last_answered_count"),
            best_score_sub.c.best_score_percent,
        )
        .outerjoin(latest_attempt_sub, latest_attempt_sub.c.test_id == Test.id)
        .outerjoin(Attempt, Attempt.id == latest_attempt_sub.c.last_attempt_id)
        .outerjoin(best_score_sub, best_score_sub.c.test_id == Test.id)
        .where(Test.type == type, Test.is_active == True)
        .order_by(Test.title.asc(), Test.id.asc())
        .offset(offset)
        .limit(page_size)
    ).all()

    return {
        "items": [
            {
                "id": str(r.id),
                "title": r.title,
                "question_count": r.question_count,
                "time_limit_seconds": r.time_limit_seconds,
                "best_score_percent": int(r.best_score_percent or 0),
                "last_attempt_id": str(r.last_attempt_id) if r.last_attempt_id else None,
                "last_attempt_status": r.last_attempt_status,
                "last_score_percent": int(r.last_score_percent) if r.last_score_percent is not None else None,
                "last_answered_count": int(r.last_answered_count or 0),
            }
            for r in rows
        ],
        "page": page,
        "page_size": page_size,
        "total": int(total),
    }


@router.get("/tests/{test_id}")
def get_test(
    test_id: str,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)

    test = db.get(Test, uuid.UUID(test_id))
    if not test or not test.is_active:
        return json_error("TEST_NOT_FOUND", "Test topilmadi.", 404)

    return {
        "id": str(test.id),
        "title": test.title,
        "type": test.type,
        "question_count": test.question_count,
        "time_limit_seconds": test.time_limit_seconds,
        "selection_strategy": test.selection_strategy,
        "filter_json": test.filter_json or {},
    }


@router.post("/attempts/start")
def attempts_start(
    payload: StartAttemptIn,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    result = start_attempt(db, user.id, uuid.UUID(payload.test_id), payload.mode)
    if isinstance(result, dict) and "error" in result:
        return JSONResponse(status_code=400, content=result)
    return {"attempt_id": str(result.id), "expires_at": result.expires_at}


@router.post("/daily/start")
def daily_start(
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    test = db.scalar(select(Test).where(Test.type == "daily", Test.is_active == True).order_by(Test.id.asc()))
    if not test:
        test = db.scalar(select(Test).where(Test.selection_strategy == "daily", Test.is_active == True).order_by(Test.id.asc()))
    if not test:
        ticket_ids = db.scalars(select(Test.id).where(Test.type == "ticket", Test.is_active == True)).all()
        if not ticket_ids:
            return json_error("TEST_NOT_FOUND", "Kunlik test topilmadi.", 404)
        test = db.get(Test, secrets.choice(ticket_ids))

    result = start_attempt(db, user.id, test.id, "daily")
    if isinstance(result, dict) and "error" in result:
        return JSONResponse(status_code=400, content=result)
    return {"attempt_id": str(result.id), "test_id": str(test.id), "expires_at": result.expires_at}


@router.get("/attempts/{attempt_id}/current")
def attempts_current(
    attempt_id: str,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    attempt = db.get(Attempt, uuid.UUID(attempt_id))
    if not attempt or attempt.user_id != user.id:
        return json_error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.", 404)
    if not _current_allowed_for_status(attempt.status):
        return json_error("ATTEMPT_NOT_ACTIVE", "Joriy savol faqat aktiv urinish uchun mavjud.", 403)
    err = guard_active_time(db, attempt)
    if err:
        return JSONResponse(status_code=400, content=err)
    aq = db.scalar(_next_unanswered_attempt_question_query(attempt.id))
    if not aq:
        return json_error("ATTEMPT_COMPLETE", "Savollar tugagan.")
    index = aq.index
    q = db.get(Question, aq.question_id)
    options = db.scalars(select(Option).where(Option.question_id == q.id)).all()
    total = db.scalar(select(func.count()).select_from(AttemptQuestion).where(AttemptQuestion.attempt_id == attempt.id))
    return {
        "attempt_id": str(attempt.id),
        "index": index,
        "total": total,
        "question": {
            "id": str(q.id),
            "text": q.text,
            "image_url": _question_image_url(q.r2_key),
            "options": [{"id": str(o.id), "text": o.text} for o in options],
        },
        "expires_at": attempt.expires_at,
    }


@router.post("/attempts/{attempt_id}/answer")
def attempts_answer(
    attempt_id: str,
    payload: AnswerIn,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    if not hit(f"answer:{user.id}", 120, 60):
        return json_error("RATE_LIMITED", "Juda ko'p javob yuborildi.", 429)
    attempt = db.get(Attempt, uuid.UUID(attempt_id))
    if not attempt or attempt.user_id != user.id:
        return json_error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.", 404)
    if not _current_allowed_for_status(attempt.status):
        return json_error("ATTEMPT_NOT_ACTIVE", "Joriy savol faqat aktiv urinish uchun mavjud.", 403)
    result = submit_answer(db, attempt, uuid.UUID(payload.question_id), uuid.UUID(payload.option_id))
    if isinstance(result, dict) and "error" in result:
        return JSONResponse(status_code=400, content=result)

    if result.get("next") and result["next"].get("question"):
        raw_key = result["next"]["question"].get("image_url")
        result["next"]["question"]["image_url"] = _question_image_url(raw_key)

    return _sanitize_submit_answer_response(attempt.mode, result)


@router.post("/attempts/{attempt_id}/finish")
def attempts_finish(
    attempt_id: str,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    attempt = db.scalar(select(Attempt).where(Attempt.id == uuid.UUID(attempt_id)).with_for_update())
    if not attempt or attempt.user_id != user.id:
        return json_error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.", 404)

    total = db.scalar(select(func.count()).select_from(AttemptQuestion).where(AttemptQuestion.attempt_id == attempt.id)) or 0
    answered = int(attempt.answered_count or 0)
    correct = int(attempt.correct_answers or 0)

    if attempt.answered_count is None:
        answered = db.scalar(select(func.count()).select_from(Answer).where(Answer.attempt_id == attempt.id)) or 0
    if attempt.correct_answers is None:
        correct = db.scalar(select(func.count()).select_from(Answer).where(Answer.attempt_id == attempt.id, Answer.is_correct == True)) or 0

    safe_total = total or 1
    score = round(correct * 100 / safe_total)

    if attempt.status != "in_progress":
        resolved_score, resolved_answered, resolved_correct = _resolved_attempt_metrics(attempt, total, answered, correct)
        return {
            "status": attempt.status,
            "score_percent": resolved_score,
            "passed": resolved_score >= 70,
            "answered_count": resolved_answered,
            "correct_answers": resolved_correct,
            "total_questions": total,
        }

    attempt.status = "finished"
    attempt.finished_at = datetime.now(timezone.utc)
    attempt.score_percent = score
    attempt.correct_answers = correct
    attempt.answered_count = answered
    db.commit()
    return {
        "status": "finished",
        "score_percent": score,
        "passed": score >= 70,
        "answered_count": answered,
        "correct_answers": correct,
        "total_questions": total,
    }


@router.get("/attempts/{attempt_id}/review")
def attempts_review(
    attempt_id: str,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    attempt = db.get(Attempt, uuid.UUID(attempt_id))
    if not attempt or attempt.user_id != user.id:
        return json_error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.", 404)
    if not _review_allowed_for_status(attempt.status):
        return json_error("ATTEMPT_NOT_AVAILABLE", "Natijalarni ko'rish uchun urinish yakunlangan bo'lishi kerak.", 403)

    rows = db.scalars(select(AttemptQuestion).where(AttemptQuestion.attempt_id == attempt.id).order_by(AttemptQuestion.index)).all()
    question_ids = [r.question_id for r in rows]

    questions = db.scalars(select(Question).where(Question.id.in_(question_ids))).all() if question_ids else []
    questions_by_id = {q.id: q for q in questions}

    options = db.scalars(select(Option).where(Option.question_id.in_(question_ids))).all() if question_ids else []
    options_by_question_id: dict[uuid.UUID, list[Option]] = {}
    for opt in options:
        options_by_question_id.setdefault(opt.question_id, []).append(opt)

    answers = db.scalars(select(Answer).where(Answer.attempt_id == attempt.id, Answer.question_id.in_(question_ids))).all() if question_ids else []
    answers_by_question_id = {a.question_id: a for a in answers}

    correct_answers = db.scalars(select(CorrectAnswer).where(CorrectAnswer.question_id.in_(question_ids))).all() if question_ids else []
    correct_by_question_id = {c.question_id: c for c in correct_answers}

    items = []
    for r in rows:
        q = questions_by_id.get(r.question_id)
        if not q:
            continue
        opts = options_by_question_id.get(q.id, [])
        ans = answers_by_question_id.get(q.id)
        corr = correct_by_question_id.get(q.id)
        items.append({
            "question_id": str(q.id),
            "text": q.text,
            "image_url": _question_image_url(q.r2_key),
            "options": [{"id": str(o.id), "text": o.text} for o in opts],
            "chosen_option_id": str(ans.option_id) if ans else None,
            "correct_option_id": str(corr.option_id) if corr else None,
            "explanation": q.explanation or "",
        })

    total = db.scalar(select(func.count()).select_from(AttemptQuestion).where(AttemptQuestion.attempt_id == attempt.id)) or 0
    answered = db.scalar(select(func.count()).select_from(Answer).where(Answer.attempt_id == attempt.id)) or 0
    correct = db.scalar(select(func.count()).select_from(Answer).where(Answer.attempt_id == attempt.id, Answer.is_correct == True)) or 0
    score, answered_count, correct_answers = _resolved_attempt_metrics(attempt, total, answered, correct)

    return {
        "attempt": {
            "id": str(attempt.id),
            "test_title": (db.scalar(select(Test.title).where(Test.id == attempt.test_id)) or "Review"),
            "score_percent": score,
            "answered_count": answered_count,
            "correct_answers": correct_answers,
            "total_questions": total,
            "status": attempt.status,
        },
        "score_percent": score,
        "items": items,
    }


@router.get("/me/notifications")
def me_notifications(
    page: int = 1,
    page_size: int = 20,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    page = max(page, 1)
    page_size = min(max(page_size, 1), 100)
    offset = (page - 1) * page_size

    total = db.scalar(select(func.count()).select_from(Notification).where(Notification.user_id == user.id)) or 0
    notes = db.scalars(
        select(Notification)
        .where(Notification.user_id == user.id)
        .order_by(Notification.id.desc())
        .offset(offset)
        .limit(page_size)
    ).all()
    return {
        "items": [{"id": str(n.id), "title": n.title, "body": n.body, "is_read": n.is_read} for n in notes],
        "page": page,
        "page_size": page_size,
        "total": int(total),
    }


@router.post("/me/notifications/{notification_id}/read")
def me_notification_read(
    notification_id: str,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)
    note = db.get(Notification, uuid.UUID(notification_id))
    if not note or note.user_id != user.id:
        return json_error("NOTIFICATION_NOT_FOUND", "Bildirishnoma topilmadi.", 404)
    note.is_read = True
    db.commit()
    return {"ok": True}


@router.get("/me/mistakes")
def me_mistakes(
    page: int = 1,
    page_size: int = 20,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)

    page = max(page, 1)
    page_size = min(max(page_size, 1), 100)
    offset = (page - 1) * page_size

    base_query = (
        select(
            Test.id,
            Test.title,
            Attempt.id.label("attempt_id"),
            Attempt.mode.label("mode"),
            Attempt.started_at.label("started_at"),
            Attempt.finished_at.label("finished_at"),
            func.count(Answer.id).label("wrong_count"),
            func.max(Attempt.started_at).label("last_wrong_at"),
        )
        .join(Attempt, Attempt.test_id == Test.id)
        .join(Answer, Answer.attempt_id == Attempt.id)
        .where(
            Attempt.user_id == user.id,
            Attempt.hidden_from_mistakes == False,
            Answer.is_correct == False,
        )
        .group_by(Test.id, Test.title, Attempt.id, Attempt.mode, Attempt.started_at, Attempt.finished_at)
    )
    rows = db.execute(
        base_query
        .order_by(func.max(Attempt.started_at).desc())
        .offset(offset)
        .limit(page_size)
    ).all()
    total = db.scalar(select(func.count()).select_from(base_query.subquery())) or 0

    return {
        "items": [
            {
                "test_id": str(r.id),
                "title": r.title,
                "attempt_id": str(r.attempt_id),
                "wrong_count": int(r.wrong_count or 0),
                "last_wrong_at": r.last_wrong_at.isoformat() if r.last_wrong_at else None,
                "mode": r.mode,
                "started_at": r.started_at.isoformat() if r.started_at else None,
                "finished_at": r.finished_at.isoformat() if r.finished_at else None,
            }
            for r in rows
        ],
        "page": page,
        "page_size": page_size,
        "total": int(total),
    }


@router.post("/me/mistakes/hide-attempt")
def me_mistakes_hide_attempt(
    payload: dict,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    attempt_id = str(payload.get("attempt_id") or "").strip()
    try:
        aid = uuid.UUID(attempt_id)
    except ValueError:
        return json_error("VALIDATION_ERROR", "attempt_id noto'g'ri.", 400)

    attempt = db.get(Attempt, aid)
    if not attempt or attempt.user_id != user.id:
        return json_error("ATTEMPT_NOT_FOUND", "Urinish topilmadi.", 404)

    attempt.hidden_from_mistakes = True
    db.commit()
    return {"ok": True}


@router.post("/me/mistakes/resolve")
def me_mistakes_resolve(
    payload: dict,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "CSRF token noto'g'ri.", 403)

    qid_raw = str(payload.get("question_id") or "").strip()
    src_raw = str(payload.get("source_attempt_id") or "").strip()
    note = payload.get("note")

    try:
        qid = uuid.UUID(qid_raw)
    except ValueError:
        return json_error("VALIDATION_ERROR", "question_id noto'g'ri.", 400)

    src_id = None
    if src_raw:
        try:
            src_id = uuid.UUID(src_raw)
        except ValueError:
            return json_error("VALIDATION_ERROR", "source_attempt_id noto'g'ri.", 400)

    rec = db.get(MistakeResolution, {"user_id": user.id, "question_id": qid})
    now = datetime.now(timezone.utc)

    if not rec:
        rec = MistakeResolution(
            user_id=user.id,
            question_id=qid,
            resolved_at=now,
            source_attempt_id=src_id,
            note=(str(note)[:500] if note else None),
        )
        db.add(rec)
    else:
        rec.resolved_at = now
        rec.source_attempt_id = src_id
        if note is not None:
            rec.note = str(note)[:500]

    db.commit()
    return {"ok": True}


@router.get("/me/mistakes/overall")
def me_mistakes_overall(
    page: int = 1,
    page_size: int = 50,
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)

    page = max(page, 1)
    page_size = min(max(page_size, 1), 200)
    offset = (page - 1) * page_size

    resolved_subq = (
        select(MistakeResolution.question_id)
        .where(MistakeResolution.user_id == user.id)
        .subquery()
    )

    base = (
        select(
            Question.id.label("question_id"),
            Question.text.label("text"),
            Question.explanation.label("explanation"),
            Question.r2_key.label("r2_key"),
            Question.bilet_number.label("bilet_number"),
            Question.question_number.label("question_number"),
            func.count(Answer.id).label("wrong_times"),
            func.max(Attempt.started_at).label("last_wrong_at"),
        )
        .select_from(Answer)
        .join(Attempt, Attempt.id == Answer.attempt_id)
        .join(Question, Question.id == Answer.question_id)
        .where(
            Attempt.user_id == user.id,
            Attempt.hidden_from_mistakes == False,
            Answer.is_correct == False,
            ~Question.id.in_(select(resolved_subq.c.question_id)),
        )
        .group_by(Question.id)
    )

    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    rows = db.execute(
        base.order_by(func.max(Attempt.started_at).desc()).offset(offset).limit(page_size)
    ).all()

    return {
        "items": [
            {
                "question_id": str(r.question_id),
                "text": r.text,
                "explanation": r.explanation,
                "image_url": _question_image_url(r.r2_key) if r.r2_key else None,
                "bilet_number": r.bilet_number,
                "question_number": r.question_number,
                "wrong_times": int(r.wrong_times or 0),
                "last_wrong_at": r.last_wrong_at.isoformat() if r.last_wrong_at else None,
            }
            for r in rows
        ],
        "page": page,
        "page_size": page_size,
        "total": int(total),
    }


@router.post("/admin/import/questions")
def admin_import_questions(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    access_token: str | None = Cookie(default=None, alias="access_token"),
    session_id: str | None = Cookie(default=None, alias="session_id"),
    csrf_cookie: str | None = Cookie(default=None, alias="csrf_token"),
    csrf_header: str | None = Header(default=None, alias="X-CSRF-Token"),
):
    user = require_auth(db, access_token, session_id)
    if not user:
        return json_error("UNAUTHORIZED", "Kirish talab qilinadi.", 401)
    if not ensure_csrf(csrf_cookie, csrf_header):
        return json_error("CSRF_INVALID", "Xavfsizlik tokeni noto'g'ri.", 403)
    if not user.is_admin:
        return json_error("FORBIDDEN", "Admin huquqi talab qilinadi.", 403)

    payload, parse_error = _parse_admin_import_payload(file)
    if parse_error:
        return parse_error

    created = 0
    for row in payload:
        try:
            test_raw = row.get("test_id")
            test_id = uuid.UUID(str(test_raw)) if test_raw else None
            text = _row_question_text(row)
            if not text:
                return json_error("INVALID_ROW", "Savol matni bo'sh bo'lishi mumkin emas.", 400)
        except Exception:
            return json_error("INVALID_ROW", "Qatorda majburiy maydonlar xato.", 400)

        raw_r2_key = row.get("r2_key")
        if not raw_r2_key and row.get("r2_url"):
            parsed_r2_url = urllib.parse.urlparse(str(row.get("r2_url")))
            raw_r2_key = (parsed_r2_url.path or "").lstrip("/")
        r2_key = _normalize_question_r2_key(str(raw_r2_key) if raw_r2_key is not None else None)
        if raw_r2_key and not r2_key:
            return json_error("INVALID_R2_KEY", "r2_key formati noto'g'ri.", 400, field="r2_key")

        explanation = str(row.get("explanation") or "").strip() or None
        bilet_number = row.get("bilet_number")
        question_number = row.get("question_number")
        try:
            bilet_number = int(bilet_number) if bilet_number not in (None, "") else None
            question_number = int(question_number) if question_number not in (None, "") else None
        except (TypeError, ValueError):
            return json_error("INVALID_ROW", "bilet_number/question_number butun son bo'lishi kerak.", 400)

        category_slug = str(row.get("category_slug") or "").strip().lower() or None
        category = _get_or_create_category_by_slug(db, category_slug) if category_slug else None

        strategy = str(row.get("selection_strategy") or "").strip().lower()
        if bilet_number is not None and strategy in {"", "bilet"} and not test_id:
            test_id = _get_or_create_bilet_test(db, bilet_number).id

        q = Question(
            test_id=test_id,
            text=text,
            r2_key=r2_key,
            explanation=explanation,
            bilet_number=bilet_number,
            question_number=question_number,
            category_id=category.id if category else None,
        )
        db.add(q)
        db.flush()

        options = row.get("options")
        if isinstance(options, str):
            try:
                options = json.loads(options)
            except json.JSONDecodeError:
                return json_error("INVALID_OPTIONS", "Variantlar JSON massiv bo'lishi kerak.", 400)
        if not options:
            options = ["A", "B", "C", "D"]
        if not isinstance(options, list) or len(options) < 2:
            return json_error("INVALID_OPTIONS", "Kamida 2 ta variant bo'lishi kerak.", 400)

        try:
            correct_index = int(row.get("correct_index", 0))
        except (TypeError, ValueError):
            return json_error("INVALID_CORRECT_INDEX", "correct_index butun son bo'lishi kerak.", 400)
        if correct_index < 0 or correct_index >= len(options):
            return json_error("INVALID_CORRECT_INDEX", "correct_index variantlar chegarasidan tashqarida.", 400)

        option_ids = []
        for opt in options:
            o = Option(question_id=q.id, text=str(opt))
            db.add(o)
            db.flush()
            option_ids.append(o.id)

        db.add(CorrectAnswer(question_id=q.id, option_id=option_ids[correct_index]))
        created += 1

    db.commit()
    return {"ok": True, "created": created}
