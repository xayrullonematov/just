from sqlalchemy import create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from app.core.config import settings


def _build_engine_kwargs(database_url: str) -> dict:
    """Build SQLAlchemy engine kwargs with explicit pooling controls.

    QueuePool knobs are applied for non-SQLite databases. SQLite uses its own
    pool implementations where these arguments are not appropriate.
    """

    kwargs: dict = {"future": True}
    backend_name = make_url(database_url).get_backend_name()
    if backend_name != "sqlite":
        kwargs.update(
            {
                "pool_size": settings.db_pool_size,
                "max_overflow": settings.db_max_overflow,
                "pool_timeout": settings.db_pool_timeout,
                "pool_recycle": settings.db_pool_recycle,
                "pool_pre_ping": settings.db_pool_pre_ping,
            }
        )
    return kwargs


engine = create_engine(settings.database_url, **_build_engine_kwargs(settings.database_url))
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
