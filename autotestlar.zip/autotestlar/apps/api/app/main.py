from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
import logging

from app.api.routes import router
from app.core.config import settings, validate_cookie_runtime_config
from app.core.rate_limit import ensure_rate_limiter_ready
from app.core.telegram_auth import validate_telegram_runtime_config

app = FastAPI(title="Auto Testlar API")

# Logger for server-side exceptions (so 500s aren't "silent")
logger = logging.getLogger("autotestlar.errors")

allowed_origins = [settings.frontend_url, "http://localhost:3000", "http://127.0.0.1:3000"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(dict.fromkeys(allowed_origins)),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)


def _internal_error(code: str, message: str):
    return {"error": {"code": code, "message": message, "field": None, "details": {}}}


@app.exception_handler(IntegrityError)
async def integrity_error_handler(req: Request, exc: IntegrityError):
    # Log stacktrace for debugging
    logger.exception("IntegrityError on %s %s", req.method, req.url)
    return JSONResponse(
        status_code=409,
        content=_internal_error("DB_CONFLICT", "Ma'lumotlar konflikti yuz berdi."),
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_error_handler(req: Request, exc: SQLAlchemyError):
    # Log stacktrace for debugging
    logger.exception("SQLAlchemyError on %s %s", req.method, req.url)
    return JSONResponse(
        status_code=500,
        content=_internal_error("DB_ERROR", "Ma'lumotlar bazasida xatolik yuz berdi."),
    )


@app.get("/health")
@app.head("/health")
def health():
    return {"ok": True}


@app.on_event("startup")
def validate_runtime_dependencies():
    ensure_rate_limiter_ready()
    validate_telegram_runtime_config(settings.app_env, settings.telegram_bot_token, settings.telegram_bot_username)
    validate_cookie_runtime_config(
        settings.app_env,
        settings.cookie_secure,
        settings.cookie_samesite,
        settings.frontend_url,
        settings.backend_url,
    )
