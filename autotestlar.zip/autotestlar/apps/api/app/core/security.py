from datetime import datetime, timedelta, timezone
import jwt
from jwt import InvalidTokenError
from passlib.context import CryptContext
import hashlib
import secrets
import pyotp
from app.core.config import settings

pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")
ALGO = "HS256"


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    return pwd_context.verify(password, password_hash)


def create_access_token(user_id: str, minutes: int | None = None) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=minutes or settings.access_token_expire_minutes)
    return jwt.encode({"sub": user_id, "exp": exp, "typ": "access"}, settings.secret_key, algorithm=ALGO)


def create_twofa_challenge_token(user_id: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=5)
    return jwt.encode({"sub": user_id, "exp": exp, "typ": "2fa"}, settings.secret_key, algorithm=ALGO)


def decode_access_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGO])
        if payload.get("typ") != "access":
            return None
        return payload.get("sub")
    except InvalidTokenError:
        return None


def decode_twofa_challenge(token: str) -> str | None:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGO])
        if payload.get("typ") != "2fa":
            return None
        return payload.get("sub")
    except InvalidTokenError:
        return None


def generate_raw_token() -> str:
    return secrets.token_urlsafe(48)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def generate_totp_secret() -> str:
    return pyotp.random_base32()


def verify_totp(secret: str, code: str) -> bool:
    return pyotp.TOTP(secret).verify(code, valid_window=1)


def generate_recovery_codes(n: int = 8) -> list[str]:
    return [secrets.token_hex(4) for _ in range(n)]
