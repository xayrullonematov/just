from __future__ import annotations

import hashlib
import hmac
from datetime import datetime, timezone


def validate_telegram_runtime_config(app_env: str, bot_token: str, bot_username: str) -> None:
    env = (app_env or "dev").lower()
    if env == "prod" and bot_username and not bot_token:
        raise RuntimeError("Telegram auth is enabled but TELEGRAM_BOT_TOKEN is missing")


def verify_telegram_payload(payload: dict, bot_token: str, max_age_seconds: int) -> tuple[bool, str, int]:
    if not bot_token:
        return False, "Telegram auth sozlanmagan.", 500

    incoming_hash = str(payload.get("hash") or "")
    auth_date_raw = str(payload.get("auth_date") or "")
    if not incoming_hash or not auth_date_raw.isdigit():
        return False, "Telegram payload noto'g'ri.", 400

    auth_date = int(auth_date_raw)
    now_ts = int(datetime.now(timezone.utc).timestamp())
    if auth_date > now_ts + 30:
        return False, "Telegram auth vaqti noto'g'ri.", 401
    if now_ts - auth_date > max_age_seconds:
        return False, "Telegram auth eskirgan.", 401

    data_pairs: list[tuple[str, str]] = []
    for k, v in payload.items():
        if k == "hash" or v is None:
            continue
        data_pairs.append((str(k), str(v)))
    data_pairs.sort(key=lambda kv: kv[0])
    data_check_string = "\n".join([f"{k}={v}" for k, v in data_pairs])

    secret_key = hashlib.sha256(bot_token.encode("utf-8")).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(computed_hash, incoming_hash):
        return False, "Telegram hash xato.", 401
    return True, "ok", 200
