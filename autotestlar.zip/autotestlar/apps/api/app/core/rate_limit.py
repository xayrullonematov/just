from __future__ import annotations

import secrets
from collections import defaultdict, deque
from time import time

from app.core.config import settings

try:
    from redis import Redis
except Exception:  # pragma: no cover - handled via runtime validation
    Redis = None  # type: ignore[assignment]

_buckets: dict[str, deque] = defaultdict(deque)
_redis_client: Redis | None = None

_RATE_LIMIT_LUA = """
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', ARGV[1] - ARGV[3])
local count = redis.call('ZCARD', KEYS[1])
if count >= tonumber(ARGV[2]) then
  return 0
end
redis.call('ZADD', KEYS[1], ARGV[1], ARGV[4])
redis.call('EXPIRE', KEYS[1], math.ceil(ARGV[3]))
return 1
"""


def _resolve_backend() -> str:
    backend = (settings.rate_limit_backend or "auto").lower()
    if backend not in {"auto", "memory", "redis"}:
        raise RuntimeError("Invalid rate_limit_backend. Use auto|memory|redis")

    if backend == "auto":
        if settings.app_env.lower() == "prod":
            return "redis"
        return "redis" if settings.redis_url else "memory"
    return backend


def _get_redis() -> Redis:
    global _redis_client
    if _redis_client is None:
        if Redis is None:
            raise RuntimeError("redis package is not installed")
        if not settings.redis_url:
            raise RuntimeError("REDIS_URL is required for redis rate limiting")
        _redis_client = Redis.from_url(settings.redis_url, decode_responses=True)
    return _redis_client


def _memory_hit(key: str, limit: int, window_s: int) -> bool:
    now = time()
    q = _buckets[key]
    while q and now - q[0] > window_s:
        q.popleft()

    # Prevent unbounded key growth in long-running processes.
    if not q:
        _buckets.pop(key, None)
        q = _buckets[key]

    if len(q) >= limit:
        return False

    q.append(now)
    return True


def _redis_hit(key: str, limit: int, window_s: int) -> bool:
    redis = _get_redis()
    prefix = settings.redis_rate_limit_prefix.strip() or "rl"
    redis_key = f"{prefix}:{key}"
    now = time()
    member = f"{now:.6f}:{secrets.token_hex(4)}"
    allowed = redis.eval(_RATE_LIMIT_LUA, 1, redis_key, now, limit, window_s, member)
    return bool(allowed)


def hit(key: str, limit: int, window_s: int) -> bool:
    backend = _resolve_backend()
    if backend == "memory":
        return _memory_hit(key, limit, window_s)
    return _redis_hit(key, limit, window_s)


def ensure_rate_limiter_ready() -> None:
    backend = _resolve_backend()
    if settings.app_env.lower() == "prod" and backend != "redis":
        raise RuntimeError("Production must use Redis-backed rate limiting")
    if backend == "redis":
        _get_redis().ping()


def clear_buckets() -> None:
    _buckets.clear()
