import logging
import smtplib
from concurrent.futures import ThreadPoolExecutor
from email.message import EmailMessage

from app.core.config import settings

logger = logging.getLogger(__name__)
_email_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="email-dispatch")


def render_verify_email(link: str) -> str:
    return f"Email verification link: {link}"


def render_reset_email(link: str) -> str:
    return f"Password reset link: {link}"


def _send_email_sync(to_email: str, subject: str, body: str) -> None:
    msg = EmailMessage()
    msg["From"] = settings.smtp_from
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(body)

    timeout = 10
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=timeout) as server:
        server.starttls()
        if settings.smtp_user:
            server.login(settings.smtp_user, settings.smtp_password)
        server.send_message(msg)


def _log_async_email_failure(future):
    exc = future.exception()
    if exc:
        logger.exception("Email send failed", exc_info=exc)


def send_email(to_email: str, subject: str, body: str) -> bool:
    if settings.email_provider == "dev_log":
        # do not log sensitive tokenized body
        print(f"[DEV EMAIL] to={to_email} subject={subject} body=<redacted>")
        return True

    try:
        future = _email_executor.submit(_send_email_sync, to_email, subject, body)
        future.add_done_callback(_log_async_email_failure)
        return True
    except Exception:
        logger.exception("Email enqueue failed")
        return False
