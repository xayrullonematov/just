from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://postgres:postgres@db:5432/autotestlar"
    db_pool_size: int = 20
    db_max_overflow: int = 40
    db_pool_timeout: int = 30
    db_pool_recycle: int = 1800
    db_pool_pre_ping: bool = True
    secret_key: str = "dev-secret"
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 30

    csrf_cookie_name: str = "csrf_token"
    access_cookie_name: str = "access_token"
    refresh_cookie_name: str = "refresh_token"
    session_cookie_name: str = "session_id"

    cookie_secure: bool = False
    cookie_samesite: str = "lax"
    cookie_domain: Optional[str] = None

    app_env: str = "dev"
    frontend_url: str = "http://localhost:3000"
    backend_url: str = "http://localhost:8000"
    session_ttl_days: int = 30

    google_client_id: str = ""
    google_client_secret: str = ""

    telegram_bot_token: str = ""
    telegram_bot_username: str = ""
    telegram_auth_max_age_seconds: int = 86400

    email_provider: str = "dev_log"  # dev_log | smtp
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = "noreply@example.com"

    rate_limit_backend: str = "auto"  # auto | memory | redis
    redis_url: str = ""
    redis_rate_limit_prefix: str = "rl"

    admin_import_max_file_bytes: int = 2_000_000
    admin_import_max_rows: int = 5_000
    admin_import_max_json_depth: int = 20
    admin_import_max_json_nodes: int = 100_000

    r2_public_base_url: str = ""


settings = Settings()


def validate_cookie_runtime_config(
    app_env: str,
    cookie_secure: bool,
    cookie_samesite: str,
    frontend_url: str,
    backend_url: str,
) -> None:
    env = (app_env or "dev").lower()
    samesite = (cookie_samesite or "").lower()

    if samesite not in {"lax", "strict", "none"}:
        raise RuntimeError("COOKIE_SAMESITE must be one of: lax, strict, none")

    if samesite == "none" and not cookie_secure:
        raise RuntimeError("COOKIE_SAMESITE=none requires COOKIE_SECURE=true")

    # Non-dev environments should never ship insecure cookie transport settings.
    secure_env = env not in {"dev", "development", "local", "test"}

    if secure_env:
        if not cookie_secure:
            raise RuntimeError("COOKIE_SECURE must be true outside local/test environments")

        if not str(frontend_url or "").startswith("https://"):
            raise RuntimeError("FRONTEND_URL must use https:// outside local/test environments")

        if not str(backend_url or "").startswith("https://"):
            raise RuntimeError("BACKEND_URL must use https:// outside local/test environments")
