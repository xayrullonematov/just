import json
import uuid
import psycopg2

# --- Config ---
DB_CONFIG = {
    "dbname": "autotestlar",
    "user": "autotestlar",
    "password": "V7IviJk5pM9GOK6pKkna_09QT_hiBTPPN7kdySNY0o-3Q0gaXF9NQxzqE4uWIy_2",
    "host": "autotestlar-db-1",
    "port": 5432,
}

JSON_FILE = "/app/scraped_questions.json"  # path to your JSON file
# --------------

def get_or_create_test(cur, bilet_number, test_cache):
    if bilet_number in test_cache:
        return test_cache[bilet_number]

    cur.execute("""
        SELECT id FROM tests
        WHERE selection_strategy = 'bilet'
        AND filter_json::jsonb->>'bilet_number' = %s
    """, (str(bilet_number),))
    row = cur.fetchone()

    if row:
        test_id = row[0]
    else:
        test_id = str(uuid.uuid4())
        cur.execute("""
            INSERT INTO tests (id, title, type, question_count, time_limit_seconds, selection_strategy, filter_json, is_active)
            VALUES (%s, %s, 'ticket', 10, 1200, 'bilet', %s, true)
        """, (test_id, f"Bilet {bilet_number}", json.dumps({"bilet_number": bilet_number})))

    test_cache[bilet_number] = test_id
    return test_id


def import_data():
    with open(JSON_FILE, "r", encoding="utf-8") as f:
        questions = json.load(f)

    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()

    inserted = 0
    skipped = 0
    test_cache = {}

    for item in questions:
        try:
            bilet_number = item.get("bilet_number")
            question_number = item.get("question_number")

            test_id = get_or_create_test(cur, bilet_number, test_cache) if bilet_number is not None else None

            question_id = str(uuid.uuid4())

            cur.execute("""
                INSERT INTO questions (id, test_id, text, explanation, r2_key, bilet_number, question_number)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                question_id,
                test_id,
                item["question"],
                item.get("explanation"),
                item.get("r2_key"),
                bilet_number,
                question_number,
            ))

            option_ids = []
            for option_text in item["options"]:
                option_id = str(uuid.uuid4())
                cur.execute("""
                    INSERT INTO options (id, question_id, text)
                    VALUES (%s, %s, %s)
                """, (option_id, question_id, option_text))
                option_ids.append(option_id)

            correct_index = item["correct_index"]
            correct_option_id = option_ids[correct_index]
            cur.execute("""
                INSERT INTO correct_answers (question_id, option_id)
                VALUES (%s, %s)
            """, (question_id, correct_option_id))

            inserted += 1

        except Exception as e:
            print(f"Error on bilet {item.get('bilet_number')} q{item.get('question_number')}: {e}")
            conn.rollback()
            skipped += 1
            continue

        conn.commit()

    cur.close()
    conn.close()
    print(f"Done. Inserted: {inserted}, Skipped: {skipped}")
    print(f"Tests created/linked: {len(test_cache)}")


if __name__ == "__main__":
    import_data()
