"""persist attempt scoring and finish metadata"""
from alembic import op
import sqlalchemy as sa

revision = '0007_attempt_scoring_fields'
down_revision = '0006_admin_roles'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('attempts', sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('attempts', sa.Column('score_percent', sa.Integer(), nullable=True))
    op.add_column('attempts', sa.Column('correct_answers', sa.Integer(), nullable=False, server_default='0'))
    op.add_column('attempts', sa.Column('answered_count', sa.Integer(), nullable=False, server_default='0'))


def downgrade():
    op.drop_column('attempts', 'answered_count')
    op.drop_column('attempts', 'correct_answers')
    op.drop_column('attempts', 'score_percent')
    op.drop_column('attempts', 'finished_at')
