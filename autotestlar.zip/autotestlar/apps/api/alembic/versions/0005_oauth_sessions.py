"""oauth accounts and server sessions"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0005_oauth_sessions'
down_revision = '0004_phase3_page_map'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('users', 'email', existing_type=sa.String(length=320), nullable=True)
    op.alter_column('users', 'password_hash', existing_type=sa.String(length=255), nullable=True)
    op.add_column('users', sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('users', sa.Column('last_login_at', sa.DateTime(timezone=True), nullable=True))

    op.execute("UPDATE users SET updated_at = NOW() WHERE updated_at IS NULL")
    op.alter_column('users', 'updated_at', nullable=False)

    op.create_index(
        'uq_users_email_not_null',
        'users',
        ['email'],
        unique=True,
        postgresql_where=sa.text('email IS NOT NULL'),
    )

    op.create_table(
        'auth_accounts',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('provider', sa.String(length=32), nullable=False),
        sa.Column('provider_account_id', sa.String(length=255), nullable=False),
        sa.Column('email', sa.String(length=320), nullable=True),
        sa.Column('raw_profile', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('provider', 'provider_account_id', name='uq_auth_accounts_provider_account'),
    )
    op.create_index('ix_auth_accounts_user_id', 'auth_accounts', ['user_id'])
    op.create_index('ix_auth_accounts_provider', 'auth_accounts', ['provider'])

    op.create_table(
        'web_sessions',
        sa.Column('id', sa.String(length=128), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('last_seen_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('user_agent', sa.String(length=512), nullable=True),
        sa.Column('ip', sa.String(length=64), nullable=True),
    )
    op.create_index('ix_web_sessions_user_id', 'web_sessions', ['user_id'])
    op.create_index('ix_web_sessions_expires_at', 'web_sessions', ['expires_at'])


def downgrade():
    op.drop_index('ix_web_sessions_expires_at', table_name='web_sessions')
    op.drop_index('ix_web_sessions_user_id', table_name='web_sessions')
    op.drop_table('web_sessions')

    op.drop_index('ix_auth_accounts_provider', table_name='auth_accounts')
    op.drop_index('ix_auth_accounts_user_id', table_name='auth_accounts')
    op.drop_table('auth_accounts')

    op.drop_index('uq_users_email_not_null', table_name='users')

    op.drop_column('users', 'last_login_at')
    op.drop_column('users', 'updated_at')
    op.alter_column('users', 'password_hash', existing_type=sa.String(length=255), nullable=False)
    op.alter_column('users', 'email', existing_type=sa.String(length=320), nullable=False)
