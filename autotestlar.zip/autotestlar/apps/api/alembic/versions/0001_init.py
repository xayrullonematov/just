"""init"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0001_init'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('users', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('email', sa.String(320), nullable=False), sa.Column('name', sa.String(120), nullable=False), sa.Column('password_hash', sa.String(255), nullable=False), sa.Column('is_email_verified', sa.Boolean(), nullable=False, server_default='false'), sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True))
    op.create_index('ix_users_email', 'users', ['email'], unique=True)

    op.create_table('tests', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('title', sa.String(255), nullable=False), sa.Column('type', sa.String(32), nullable=False), sa.Column('question_count', sa.Integer(), nullable=False), sa.Column('time_limit_seconds', sa.Integer(), nullable=True), sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'))
    op.create_table('questions', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('test_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('tests.id')), sa.Column('text', sa.Text(), nullable=False))
    op.create_table('options', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('question_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('questions.id')), sa.Column('text', sa.Text(), nullable=False))
    op.create_table('correct_answers', sa.Column('question_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('questions.id'), primary_key=True), sa.Column('option_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('options.id')))

    op.create_table('attempts', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')), sa.Column('test_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('tests.id')), sa.Column('mode', sa.String(20), nullable=False), sa.Column('status', sa.String(20), nullable=False), sa.Column('started_at', sa.DateTime(timezone=True), nullable=False), sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True))
    op.create_index('idx_attempts_active_unique', 'attempts', ['user_id','test_id','mode'], unique=True, postgresql_where=sa.text("status='in_progress'"))
    op.create_table('attempt_questions', sa.Column('attempt_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('attempts.id'), primary_key=True), sa.Column('index', sa.Integer(), primary_key=True), sa.Column('question_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('questions.id')))
    op.create_table('answers', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('attempt_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('attempts.id')), sa.Column('question_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('questions.id')), sa.Column('option_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('options.id')), sa.Column('is_correct', sa.Boolean(), nullable=False), sa.UniqueConstraint('attempt_id','question_id', name='uq_answers_attempt_question'))
    op.create_index('idx_answers_attempt', 'answers', ['attempt_id'])

    op.create_table('notifications', sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True), sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')), sa.Column('title', sa.String(255), nullable=False), sa.Column('body', sa.Text(), nullable=False), sa.Column('is_read', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index('idx_notifications_user_unread', 'notifications', ['user_id','is_read'])


def downgrade():
    op.drop_table('notifications')
    op.drop_table('answers')
    op.drop_table('attempt_questions')
    op.drop_table('attempts')
    op.drop_table('correct_answers')
    op.drop_table('options')
    op.drop_table('questions')
    op.drop_table('tests')
    op.drop_table('users')
