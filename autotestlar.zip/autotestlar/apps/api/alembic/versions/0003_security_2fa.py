"""security 2fa and audit"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0003_security_2fa'
down_revision = '0002_auth_tables'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('twofa_enabled', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('users', sa.Column('twofa_secret', sa.String(length=64), nullable=True))

    op.create_table('recovery_codes',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('code_hash', sa.String(length=128), nullable=False),
        sa.Column('used_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_recovery_codes_code_hash', 'recovery_codes', ['code_hash'], unique=True)

    op.create_table('security_audit_events',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('event_type', sa.String(length=64), nullable=False),
        sa.Column('ip', sa.String(length=64), nullable=True),
        sa.Column('details', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_security_audit_events_event_type', 'security_audit_events', ['event_type'])


def downgrade():
    op.drop_index('ix_security_audit_events_event_type', table_name='security_audit_events')
    op.drop_table('security_audit_events')
    op.drop_index('ix_recovery_codes_code_hash', table_name='recovery_codes')
    op.drop_table('recovery_codes')
    op.drop_column('users', 'twofa_secret')
    op.drop_column('users', 'twofa_enabled')
