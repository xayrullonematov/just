"""phase3 page-map alignment"""
from alembic import op
import sqlalchemy as sa

revision = '0004_phase3_page_map'
down_revision = '0003_security_2fa'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('avatar_url', sa.String(length=512), nullable=True))


def downgrade():
    op.drop_column('users', 'avatar_url')
