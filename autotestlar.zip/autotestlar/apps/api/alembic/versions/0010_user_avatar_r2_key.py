"""add avatar r2 key to users

Revision ID: 0010_user_avatar_r2_key
Revises: 0009_question_bank_fields
Create Date: 2026-02-20
"""

from alembic import op
import sqlalchemy as sa


revision = '0010_user_avatar_r2_key'
down_revision = '0009_question_bank_fields'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('avatar_r2_key', sa.String(length=255), nullable=True))


def downgrade():
    op.drop_column('users', 'avatar_r2_key')
