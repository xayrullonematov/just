"""add admin flag for privileged endpoints"""
from alembic import op
import sqlalchemy as sa

revision = '0006_admin_roles'
down_revision = '0005_oauth_sessions'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('is_admin', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index('ix_users_is_admin', 'users', ['is_admin'])


def downgrade():
    op.drop_index('ix_users_is_admin', table_name='users')
    op.drop_column('users', 'is_admin')
