"""add composite answers index for attempt/question lookups"""
from alembic import op

revision = '0008_answers_attempt_question_index'
down_revision = '0007_attempt_scoring_fields'
branch_labels = None
depends_on = None


def upgrade():
    op.create_index('idx_answers_attempt_question', 'answers', ['attempt_id', 'question_id'])


def downgrade():
    op.drop_index('idx_answers_attempt_question', table_name='answers')
