"""add question bank metadata and strategy fields

Revision ID: 0009_question_bank_fields
Revises: 0008_answers_attempt_question_index
Create Date: 2026-02-20
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '0009_question_bank_fields'
down_revision = '0008_answers_attempt_question_index'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'categories',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('name', sa.String(length=120), nullable=False),
        sa.Column('slug', sa.String(length=120), nullable=False, unique=True),
        sa.Column('parent_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('categories.id'), nullable=True),
    )
    op.create_index('ix_categories_slug', 'categories', ['slug'], unique=True)
    op.create_index('ix_categories_parent_id', 'categories', ['parent_id'])

    op.add_column('tests', sa.Column('selection_strategy', sa.String(length=32), nullable=False, server_default='by_test'))
    op.add_column('tests', sa.Column('filter_json', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")))

    op.add_column('questions', sa.Column('category_id', postgresql.UUID(as_uuid=True), nullable=True))
    op.add_column('questions', sa.Column('explanation', sa.Text(), nullable=True))
    op.add_column('questions', sa.Column('r2_key', sa.String(length=255), nullable=True))
    op.add_column('questions', sa.Column('bilet_number', sa.Integer(), nullable=True))
    op.add_column('questions', sa.Column('question_number', sa.Integer(), nullable=True))
    op.alter_column('questions', 'test_id', existing_type=postgresql.UUID(as_uuid=True), nullable=True)

    op.create_foreign_key('fk_questions_category_id', 'questions', 'categories', ['category_id'], ['id'])
    op.create_index('ix_questions_category_id', 'questions', ['category_id'])
    op.create_index('ix_questions_bilet_number', 'questions', ['bilet_number'])

    op.alter_column('tests', 'selection_strategy', server_default=None)
    op.alter_column('tests', 'filter_json', server_default=None)


def downgrade():
    op.drop_index('ix_questions_bilet_number', table_name='questions')
    op.drop_index('ix_questions_category_id', table_name='questions')
    op.drop_constraint('fk_questions_category_id', 'questions', type_='foreignkey')

    op.alter_column('questions', 'test_id', existing_type=postgresql.UUID(as_uuid=True), nullable=False)
    op.drop_column('questions', 'question_number')
    op.drop_column('questions', 'bilet_number')
    op.drop_column('questions', 'r2_key')
    op.drop_column('questions', 'explanation')
    op.drop_column('questions', 'category_id')

    op.drop_column('tests', 'filter_json')
    op.drop_column('tests', 'selection_strategy')

    op.drop_index('ix_categories_parent_id', table_name='categories')
    op.drop_index('ix_categories_slug', table_name='categories')
    op.drop_table('categories')
