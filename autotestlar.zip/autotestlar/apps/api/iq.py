"""
Import questions from JSON files in data/questions/ into the database.
Run after the seed: python import_questions.py
Or set DATA_DIR env var to point to your questions directory.
"""
import os
import json
import glob
from app.core.config import settings
from app.db.session import SessionLocal
from app.models.models import (
    Category, CorrectAnswer, Option, Question, Test, User
)
from sqlalchemy import select
import uuid


def _is_non_local_env(app_env: str) -> bool:
    return (app_env or "dev").lower() not in {"dev", "development", "local", "test"}


def ensure_import_allowed() -> None:
    if _is_non_local_env(settings.app_env) and os.getenv("ALLOW_PROD_SEED") != "1":
        raise RuntimeError(
            "Refusing to run import script outside local/test env. "
            "Set ALLOW_PROD_SEED=1 to override."
        )


def get_or_create_bilet_test(db, bilet_number: int) -> Test:
    candidates = db.scalars(
        select(Test).where(
            Test.selection_strategy == "bilet",
            Test.type == "ticket"
        )
    ).all()
    for t in candidates:
        filt = t.filter_json or {}
        if str(filt.get("bilet_number")) == str(bilet_number):
            return t

    test = Test(
        title=f"Bilet {bilet_number}",
        type="ticket",
        question_count=10,
        time_limit_seconds=1200,
        selection_strategy="bilet",
        filter_json={"bilet_number": bilet_number},
        is_active=True,
    )
    db.add(test)
    db.flush()
    return test


def normalize_r2_key(raw_key: str | None) -> str | None:
    """Accept keys like 'questions/b01/q04_xxx.webp'"""
    import re
    R2_KEY_PATTERN = re.compile(r"^questions/b\d{1,4}/q\d{1,4}_[a-zA-Z0-9._-]+$")
    key = (raw_key or "").strip().lstrip("/")
    if not key:
        return None
    # Normalize b01 -> b1 style if needed, try both
    if R2_KEY_PATTERN.match(key):
        return key
    return None


def import_json_file(db, filepath: str) -> int:
    with open(filepath, "r", encoding="utf-8") as f:
        rows = json.load(f)

    if not isinstance(rows, list):
        print(f"  Skipping {filepath}: root is not a list")
        return 0

    created = 0
    for row in rows:
        bilet_number = row.get("bilet_number")
        question_number = row.get("question_number")
        text = str(row.get("text") or row.get("question") or "").strip()

        if not text:
            print(f"  Skipping row with empty text in {filepath}")
            continue

        try:
            bilet_number = int(bilet_number) if bilet_number not in (None, "") else None
            question_number = int(question_number) if question_number not in (None, "") else None
        except (TypeError, ValueError):
            print(f"  Skipping row: invalid bilet/question number")
            continue

        # Get or create test for this bilet
        test = None
        if bilet_number is not None:
            test = get_or_create_bilet_test(db, bilet_number)

        # Handle r2_key - try r2_key first, then extract from r2_url
        raw_r2_key = row.get("r2_key")
        if not raw_r2_key and row.get("r2_url"):
            import urllib.parse
            parsed = urllib.parse.urlparse(str(row["r2_url"]))
            raw_r2_key = (parsed.path or "").lstrip("/")

        r2_key = normalize_r2_key(raw_r2_key)

        explanation = str(row.get("explanation") or "").strip() or None

        # Check for duplicate (same bilet_number + question_number)
        if bilet_number is not None and question_number is not None:
            existing = db.scalar(
                select(Question).where(
                    Question.bilet_number == bilet_number,
                    Question.question_number == question_number,
                )
            )
            if existing:
                print(f"  Skipping duplicate: bilet={bilet_number} q={question_number}")
                continue

        q = Question(
            test_id=test.id if test else None,
            text=text,
            r2_key=r2_key,
            explanation=explanation,
            bilet_number=bilet_number,
            question_number=question_number,
        )
        db.add(q)
        db.flush()

        options = row.get("options", [])
        if isinstance(options, str):
            try:
                options = json.loads(options)
            except json.JSONDecodeError:
                options = []

        if not options or len(options) < 2:
            print(f"  Warning: question {question_number} in bilet {bilet_number} has <2 options, skipping")
            db.expunge(q)
            continue

        try:
            correct_index = int(row.get("correct_index", 0))
        except (TypeError, ValueError):
            correct_index = 0

        if correct_index < 0 or correct_index >= len(options):
            print(f"  Warning: correct_index {correct_index} out of range, defaulting to 0")
            correct_index = 0

        option_ids = []
        for opt_text in options:
            o = Option(question_id=q.id, text=str(opt_text))
            db.add(o)
            db.flush()
            option_ids.append(o.id)

        db.add(CorrectAnswer(question_id=q.id, option_id=option_ids[correct_index]))
        created += 1

    return created


def run():
    ensure_import_allowed()

    # Find JSON files - look in data/questions/ relative to project root
    # Adjust DATA_DIR env var if your structure differs
    data_dir = os.getenv("DATA_DIR", "data/questions")
    pattern = os.path.join(data_dir, "*.json")
    files = sorted(glob.glob(pattern))

    if not files:
        print(f"No JSON files found in {data_dir}")
        print("Set DATA_DIR env var or place files in data/questions/")
        return

    print(f"Found {len(files)} JSON file(s) in {data_dir}")

    db = SessionLocal()
    try:
        total = 0
        for filepath in files:
            print(f"Importing {filepath}...")
            count = import_json_file(db, filepath)
            db.commit()
            print(f"  Created {count} questions")
            total += count

        print(f"\nDone. Total questions created: {total}")
    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    run()
