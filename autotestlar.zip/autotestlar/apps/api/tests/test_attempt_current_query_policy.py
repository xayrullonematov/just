import uuid

from app.api.routes import _next_unanswered_attempt_question_query


def test_next_unanswered_query_uses_not_exists_and_ordering():
    q = _next_unanswered_attempt_question_query(uuid.uuid4())
    sql = str(q)
    assert 'NOT (EXISTS' in sql
    assert 'ORDER BY attempt_questions.index ASC' in sql
