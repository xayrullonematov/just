from fastapi.testclient import TestClient

from app.main import app


def test_auth_csrf_reuses_existing_cookie_token():
    client = TestClient(app)

    first = client.get('/api/v1/auth/csrf')
    first_token = first.json()['csrf_token']

    second = client.get('/api/v1/auth/csrf')
    second_token = second.json()['csrf_token']

    assert first.status_code == 200
    assert second.status_code == 200
    assert second_token == first_token
