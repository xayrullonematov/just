import pytest

from app.api.routes import _ip
from app.core.config import settings
from scripts_seed import ensure_seed_allowed


class _ReqNoClient:
    client = None


def test_ip_helper_handles_none_request():
    assert _ip(None) == "unknown"
    assert _ip(_ReqNoClient()) == "unknown"


def test_seed_refuses_non_local_without_override(monkeypatch):
    monkeypatch.setattr(settings, "app_env", "staging")
    monkeypatch.delenv("ALLOW_PROD_SEED", raising=False)
    with pytest.raises(RuntimeError):
        ensure_seed_allowed()


def test_seed_allows_non_local_with_explicit_override(monkeypatch):
    monkeypatch.setattr(settings, "app_env", "prod")
    monkeypatch.setenv("ALLOW_PROD_SEED", "1")
    ensure_seed_allowed()
