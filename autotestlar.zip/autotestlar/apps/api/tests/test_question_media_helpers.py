from app.api.routes import _normalize_question_r2_key, _question_image_url
from app.core.config import settings


def test_normalize_question_r2_key_accepts_expected_pattern():
    assert _normalize_question_r2_key('questions/b12/q3_image.webp') == 'questions/b12/q3_image.webp'
    assert _normalize_question_r2_key('/questions/b1/q10_x.png') == 'questions/b1/q10_x.png'


def test_normalize_question_r2_key_rejects_invalid_values():
    assert _normalize_question_r2_key('http://example.com/x.webp') is None
    assert _normalize_question_r2_key('questions/x/q1_img.webp') is None


def test_question_image_url_uses_public_base():
    old = settings.r2_public_base_url
    settings.r2_public_base_url = 'https://cdn.example.test'
    try:
        assert _question_image_url('questions/b1/q1_img.webp') == 'https://cdn.example.test/questions/b1/q1_img.webp'
    finally:
        settings.r2_public_base_url = old
