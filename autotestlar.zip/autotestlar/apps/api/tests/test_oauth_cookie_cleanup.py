from app.api.routes import _google_redirect_with_cookie_cleanup


def test_google_error_redirect_clears_temp_oauth_cookies():
    res = _google_redirect_with_cookie_cleanup('https://frontend.example/login?error=google_state_invalid')
    set_cookie = '\n'.join(res.headers.getlist('set-cookie'))
    assert 'google_oauth_state=""' in set_cookie
    assert 'google_oauth_next=""' in set_cookie
