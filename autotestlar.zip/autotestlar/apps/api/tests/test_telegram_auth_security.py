import hashlib
import hmac
from datetime import datetime, timezone

from app.core.telegram_auth import verify_telegram_payload, validate_telegram_runtime_config


def _signed_payload(bot_token: str, payload: dict) -> dict:
    data_pairs = sorted((str(k), str(v)) for k, v in payload.items() if k != 'hash' and v is not None)
    data_check_string = "\n".join(f"{k}={v}" for k, v in data_pairs)
    secret_key = hashlib.sha256(bot_token.encode('utf-8')).digest()
    sig = hmac.new(secret_key, data_check_string.encode('utf-8'), hashlib.sha256).hexdigest()
    out = dict(payload)
    out['hash'] = sig
    return out


def test_verify_telegram_payload_rejects_empty_token():
    payload = {'id': '1', 'auth_date': str(int(datetime.now(timezone.utc).timestamp())), 'first_name': 'A', 'hash': 'x'}
    ok, msg, status = verify_telegram_payload(payload, '', 86400)
    assert not ok
    assert status == 500


def test_verify_telegram_payload_accepts_valid_signature():
    token = '123456:ABC-SECRET'
    payload = {
        'id': '42',
        'auth_date': str(int(datetime.now(timezone.utc).timestamp())),
        'first_name': 'Test',
        'username': 'tester',
    }
    signed = _signed_payload(token, payload)
    ok, _, status = verify_telegram_payload(signed, token, 86400)
    assert ok
    assert status == 200


def test_validate_telegram_runtime_config_fails_in_prod_when_username_without_token():
    try:
        validate_telegram_runtime_config('prod', '', 'autotestlar_bot')
    except RuntimeError:
        assert True
    else:
        assert False
