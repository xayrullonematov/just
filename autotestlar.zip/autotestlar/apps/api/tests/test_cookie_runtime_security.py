import pytest

from app.core.config import validate_cookie_runtime_config


def test_rejects_invalid_cookie_samesite_value():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('dev', False, 'invalid', 'http://localhost:3000', 'http://localhost:8000')


def test_rejects_none_samesite_without_secure_cookie():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('dev', False, 'none', 'http://localhost:3000', 'http://localhost:8000')


def test_rejects_insecure_cookie_in_prod():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('prod', False, 'lax', 'https://frontend.example', 'https://api.example')


def test_rejects_insecure_cookie_in_staging():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('staging', False, 'lax', 'https://frontend.example', 'https://api.example')


def test_rejects_non_https_frontend_in_prod():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('prod', True, 'lax', 'http://frontend.example', 'https://api.example')


def test_rejects_non_https_backend_in_prod():
    with pytest.raises(RuntimeError):
        validate_cookie_runtime_config('prod', True, 'lax', 'https://frontend.example', 'http://api.example')


def test_accepts_secure_cookie_and_https_urls_in_prod():
    validate_cookie_runtime_config('prod', True, 'lax', 'https://frontend.example', 'https://api.example')


def test_accepts_local_dev_defaults():
    validate_cookie_runtime_config('dev', False, 'lax', 'http://localhost:3000', 'http://localhost:8000')
