from fastapi.testclient import TestClient
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from app.main import app


@app.get('/__test_raise_integrity_error__')
def _raise_integrity_error_for_test():
    raise IntegrityError('insert into answers ...', {'attempt_id': 'x'}, Exception('duplicate key value violates unique constraint uq_answers_attempt_question'))


@app.get('/__test_raise_sqlalchemy_error__')
def _raise_sqlalchemy_error_for_test():
    raise SQLAlchemyError('database temporarily unavailable')


def test_integrity_error_returns_sanitized_409_response():
    client = TestClient(app, raise_server_exceptions=False)
    res = client.get('/__test_raise_integrity_error__')

    assert res.status_code == 409
    body = res.json()
    assert body['error']['code'] == 'DB_CONFLICT'
    assert 'duplicate key value' not in res.text
    assert 'uq_answers_attempt_question' not in res.text


def test_sqlalchemy_error_returns_sanitized_500_response():
    client = TestClient(app, raise_server_exceptions=False)
    res = client.get('/__test_raise_sqlalchemy_error__')

    assert res.status_code == 500
    body = res.json()
    assert body['error']['code'] == 'DB_ERROR'
    assert 'database temporarily unavailable' not in res.text
