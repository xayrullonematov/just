from app.api.routes import _sanitize_submit_answer_response


def test_submit_answer_response_hides_correctness_for_exam_mode():
    result = _sanitize_submit_answer_response('exam', {'ok': True, 'is_correct': False, 'next_index': 3})
    assert result == {'ok': True, 'next_index': 3}
    assert 'is_correct' not in result


def test_submit_answer_response_keeps_correctness_for_non_exam_mode():
    result = _sanitize_submit_answer_response('practice', {'ok': True, 'is_correct': False, 'next_index': 3})
    assert result['is_correct'] is False
