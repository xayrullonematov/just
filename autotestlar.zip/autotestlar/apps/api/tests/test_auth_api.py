from datetime import datetime, timedelta, timezone
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.db.base import Base
from app.db.session import get_db
from app.models.models import User, EmailVerification, SecurityAuditEvent, Session as UserSession, WebSession, Notification
from app.core.security import hash_password
from app.core.config import settings
from app.core.rate_limit import clear_buckets


def setup_client():
    engine = create_engine('sqlite+pysqlite:///:memory:', future=True, connect_args={"check_same_thread": False}, poolclass=StaticPool)
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    settings.app_env = "dev"
    clear_buckets()
    return TestClient(app), TestingSessionLocal


def csrf(client: TestClient):
    return client.get('/api/v1/auth/csrf').json()['csrf_token']


def test_signup_verify_login_and_me():
    client, _ = setup_client()
    r = client.post('/api/v1/auth/signup', json={'name': 'A', 'email': 'a@example.com', 'password': 'password123'})
    token = r.json()['verification_link'].split('token=')[1]

    r2 = client.post('/api/v1/auth/login', json={'email': 'a@example.com', 'password': 'password123'})
    assert r2.status_code == 403 and r2.json()['error']['code'] == 'EMAIL_NOT_VERIFIED'

    assert client.post('/api/v1/auth/verify-email', json={'token': token}).status_code == 200
    assert client.post('/api/v1/auth/login', json={'email': 'a@example.com', 'password': 'password123'}).status_code == 200
    assert client.get('/api/v1/me').status_code == 200


def test_verify_email_token_expires():
    client, DB = setup_client()
    r = client.post('/api/v1/auth/signup', json={'name': 'A', 'email': 'e@example.com', 'password': 'password123'})
    token = r.json()['verification_link'].split('token=')[1]
    db = DB()
    rec = db.scalar(select(EmailVerification).limit(1))
    rec.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)
    db.commit(); db.close()
    res = client.post('/api/v1/auth/verify-email', json={'token': token})
    assert res.status_code == 400


def test_refresh_rotates_tokens_and_logout_invalidates_session():
    client, DB = setup_client()
    db = DB()
    user = User(email='b@example.com', name='B', password_hash=hash_password('password123'), is_email_verified=True)
    db.add(user); db.commit(); db.close()

    login = client.post('/api/v1/auth/login', json={'email': 'b@example.com', 'password': 'password123'})
    old_refresh = login.cookies.get('refresh_token')

    rr = client.post('/api/v1/auth/refresh', headers={'X-CSRF-Token': csrf(client)})
    new_refresh = rr.cookies.get('refresh_token')
    assert rr.status_code == 200 and new_refresh and new_refresh != old_refresh

    lo = client.post('/api/v1/auth/logout', headers={'X-CSRF-Token': csrf(client)})
    assert lo.status_code == 200
    denied = client.post('/api/v1/auth/refresh', headers={'X-CSRF-Token': csrf(client)})
    assert denied.status_code == 401


def test_forgot_and_reset_invalidates_sessions():
    client, DB = setup_client()
    db = DB()
    user = User(email='c@example.com', name='C', password_hash=hash_password('password123'), is_email_verified=True)
    db.add(user); db.commit(); uid = user.id; db.close()

    client.post('/api/v1/auth/login', json={'email': 'c@example.com', 'password': 'password123'})
    fp = client.post('/api/v1/auth/forgot-password', json={'email': 'c@example.com'})
    reset_token = fp.json()['reset_link'].split('token=')[1]
    assert client.post('/api/v1/auth/reset-password', json={'token': reset_token, 'new_password': 'newpassword123'}).status_code == 200

    db = DB()
    active_refresh = db.scalar(select(UserSession).where(UserSession.user_id == uid, UserSession.revoked_at.is_(None)))
    active_web = db.scalar(select(WebSession).where(WebSession.user_id == uid, WebSession.expires_at > datetime.now(timezone.utc)))
    db.close()
    assert active_refresh is None
    assert active_web is None

    assert client.post('/api/v1/auth/login', json={'email': 'c@example.com', 'password': 'password123'}).status_code == 401
    assert client.post('/api/v1/auth/login', json={'email': 'c@example.com', 'password': 'newpassword123'}).status_code == 200


def test_rate_limits_enforced():
    client, _ = setup_client()
    for _ in range(3):
        client.post('/api/v1/auth/signup', json={'name':'R','email':f'r{_}@e.com','password':'password123'})
    limited = client.post('/api/v1/auth/signup', json={'name':'R','email':'rx@e.com','password':'password123'})
    assert limited.status_code == 429


def test_twofa_enable_and_login_with_code():
    client, _ = setup_client()
    r = client.post('/api/v1/auth/signup', json={'name':'T','email':'t@example.com','password':'password123'})
    token = r.json()['verification_link'].split('token=')[1]
    client.post('/api/v1/auth/verify-email', json={'token': token})
    client.post('/api/v1/auth/login', json={'email':'t@example.com','password':'password123'})

    setup = client.post('/api/v1/auth/2fa/setup', headers={'X-CSRF-Token': csrf(client)})
    secret = setup.json()['secret']

    import pyotp
    code = pyotp.TOTP(secret).now()
    en = client.post('/api/v1/auth/2fa/enable', json={'code': code}, headers={'X-CSRF-Token': csrf(client)})
    assert en.status_code == 200

    login2 = client.post('/api/v1/auth/login', json={'email':'t@example.com','password':'password123'})
    assert login2.status_code == 401 and login2.json()['error']['code'] == 'TWO_FA_REQUIRED'
    challenge = login2.json()['error']['details']['challenge_token']
    verify = client.post('/api/v1/auth/2fa/verify', json={'challenge_token': challenge, 'code': pyotp.TOTP(secret).now()})
    assert verify.status_code == 200


def test_twofa_verify_invalid_code_audited_and_rate_limited():
    client, DB = setup_client()
    r = client.post('/api/v1/auth/signup', json={'name':'T2','email':'t2@example.com','password':'password123'})
    token = r.json()['verification_link'].split('token=')[1]
    client.post('/api/v1/auth/verify-email', json={'token': token})
    client.post('/api/v1/auth/login', json={'email':'t2@example.com','password':'password123'})

    setup = client.post('/api/v1/auth/2fa/setup', headers={'X-CSRF-Token': csrf(client)})
    secret = setup.json()['secret']

    import pyotp
    code = pyotp.TOTP(secret).now()
    assert client.post('/api/v1/auth/2fa/enable', json={'code': code}, headers={'X-CSRF-Token': csrf(client)}).status_code == 200

    challenge = client.post('/api/v1/auth/login', json={'email':'t2@example.com','password':'password123'}).json()['error']['details']['challenge_token']
    bad = client.post('/api/v1/auth/2fa/verify', json={'challenge_token': challenge, 'code': '000000'})
    assert bad.status_code == 401

    db = DB()
    user = db.scalar(select(User).where(User.email == 't2@example.com'))
    ev = db.scalar(select(SecurityAuditEvent).where(SecurityAuditEvent.user_id == user.id, SecurityAuditEvent.event_type == 'twofa_verify_failed'))
    db.close()
    assert ev is not None

    for _ in range(5):
        client.post('/api/v1/auth/2fa/verify', json={'challenge_token': challenge, 'code': '000000'})
    limited = client.post('/api/v1/auth/2fa/verify', json={'challenge_token': challenge, 'code': '000000'})
    assert limited.status_code == 429


def test_logout_all_and_audit_events_exist():
    client, DB = setup_client()
    db = DB()
    user = User(email='d@example.com', name='D', password_hash=hash_password('password123'), is_email_verified=True)
    db.add(user); db.commit(); uid = user.id; db.close()

    client.post('/api/v1/auth/login', json={'email':'d@example.com','password':'password123'})
    out = client.post('/api/v1/auth/logout-all', headers={'X-CSRF-Token': csrf(client)})
    assert out.status_code == 200

    db = DB()
    active = db.scalar(select(UserSession).where(UserSession.user_id == uid, UserSession.revoked_at.is_(None)))
    ev = db.scalar(select(SecurityAuditEvent).where(SecurityAuditEvent.user_id == uid))
    db.close()
    assert active is None
    assert ev is not None


def test_phase3_page_map_endpoints():
    client, DB = setup_client()
    db = DB()
    user = User(email='phase3@example.com', name='P3', password_hash=hash_password('password123'), is_email_verified=True)
    db.add(user); db.commit(); db.close()

    assert client.get('/api/v1/public/metrics').status_code == 200
    assert client.post('/api/v1/auth/login', json={'email':'phase3@example.com','password':'password123'}).status_code == 200

    assert client.get('/api/v1/me/dashboard').status_code == 200

    token = csrf(client)
    av = client.post('/api/v1/me/avatar', json={'avatar_url':'https://img.example/a.png'}, headers={'X-CSRF-Token': token})
    assert av.status_code == 200 and av.json()['avatar_url']

    ds = client.post('/api/v1/daily/start', headers={'X-CSRF-Token': csrf(client)})
    if ds.status_code == 404:
        pass
    else:
        assert ds.status_code == 200 and ds.json().get('attempt_id')

    assert client.get('/api/v1/me/mistakes').status_code == 200

    db = DB()
    u = db.scalar(select(User).where(User.email == 'phase3@example.com'))
    n = Notification(user_id=u.id, title='T', body='B', is_read=False)
    db.add(n); db.commit(); nid = n.id; db.close()
    rd = client.post(f'/api/v1/me/notifications/{nid}/read', headers={'X-CSRF-Token': csrf(client)})
    assert rd.status_code == 200

