from types import SimpleNamespace

from app.api.routes import _normalize_avatar_r2_key, _user_avatar_url
from app.core.config import settings


def test_normalize_avatar_r2_key():
    assert _normalize_avatar_r2_key('avatars/user-1.webp') == 'avatars/user-1.webp'
    assert _normalize_avatar_r2_key('/avatars/folder/u.png') == 'avatars/folder/u.png'
    assert _normalize_avatar_r2_key('http://example.com/x.png') is None
    assert _normalize_avatar_r2_key('questions/b1/q1_x.webp') is None


def test_user_avatar_url_prefers_r2_key():
    old_base = settings.r2_public_base_url
    settings.r2_public_base_url = 'https://cdn.example.test'
    try:
        user = SimpleNamespace(avatar_r2_key='avatars/user-1.webp', avatar_url='https://legacy.example/u.png')
        assert _user_avatar_url(user) == 'https://cdn.example.test/avatars/user-1.webp'
    finally:
        settings.r2_public_base_url = old_base
