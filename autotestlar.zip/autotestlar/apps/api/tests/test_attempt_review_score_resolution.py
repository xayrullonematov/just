from types import SimpleNamespace

from app.api.routes import _resolved_attempt_metrics


def test_review_score_uses_persisted_attempt_score_when_present():
    attempt = SimpleNamespace(score_percent=67, answered_count=10, correct_answers=7)
    score, answered_count, correct_answers = _resolved_attempt_metrics(attempt, total=20, answered=3, correct=2)

    assert score == 67
    assert answered_count == 10
    assert correct_answers == 7


def test_review_score_falls_back_to_computed_values_when_missing():
    attempt = SimpleNamespace(score_percent=None, answered_count=None, correct_answers=None)
    score, answered_count, correct_answers = _resolved_attempt_metrics(attempt, total=20, answered=3, correct=2)

    assert score == 10
    assert answered_count == 3
    assert correct_answers == 2


def test_review_score_keeps_zero_values_instead_of_overwriting_them():
    attempt = SimpleNamespace(score_percent=0, answered_count=0, correct_answers=0)
    score, answered_count, correct_answers = _resolved_attempt_metrics(attempt, total=20, answered=8, correct=5)

    assert score == 0
    assert answered_count == 0
    assert correct_answers == 0
