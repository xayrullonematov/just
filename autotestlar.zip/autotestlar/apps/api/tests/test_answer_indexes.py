from app.models.models import Answer


def test_answers_table_has_attempt_question_index():
    index_names = {idx.name for idx in Answer.__table__.indexes}
    assert 'idx_answers_attempt_question' in index_names
