from app.db.session import _build_engine_kwargs


def test_build_engine_kwargs_applies_pooling_for_postgres():
    kwargs = _build_engine_kwargs('postgresql+psycopg://u:p@localhost:5432/db')

    assert kwargs['future'] is True
    assert kwargs['pool_size'] > 0
    assert kwargs['max_overflow'] >= 0
    assert kwargs['pool_timeout'] > 0
    assert kwargs['pool_recycle'] > 0
    assert kwargs['pool_pre_ping'] is True


def test_build_engine_kwargs_skips_queuepool_args_for_sqlite():
    kwargs = _build_engine_kwargs('sqlite+pysqlite:///:memory:')

    assert kwargs == {'future': True}
