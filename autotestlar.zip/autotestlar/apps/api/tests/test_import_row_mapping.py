from app.api.routes import _row_question_text


def test_row_question_text_supports_text_and_question_fields():
    assert _row_question_text({'text': ' A '}) == 'A'
    assert _row_question_text({'question': ' B '}) == 'B'
    assert _row_question_text({'text': '', 'question': ' C '}) == 'C'
