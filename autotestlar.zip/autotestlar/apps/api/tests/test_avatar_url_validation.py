from app.api.routes import _normalize_avatar_url


def test_avatar_url_allows_https_only():
    assert _normalize_avatar_url('https://example.com/a.png') == 'https://example.com/a.png'
    assert _normalize_avatar_url('http://example.com/a.png') is None
    assert _normalize_avatar_url('javascript:alert(1)') is None
    assert _normalize_avatar_url('') is None


def test_avatar_url_rejects_missing_host_and_credentials():
    assert _normalize_avatar_url('https:///x.png') is None
    assert _normalize_avatar_url('https://user:pass@example.com/a.png') is None
