import io
import json

from app.api.routes import _parse_admin_import_payload
from app.core.config import settings


class DummyUpload:
    def __init__(self, filename: str, content_type: str, content: bytes):
        self.filename = filename
        self.content_type = content_type
        self.file = io.BytesIO(content)


def test_parse_admin_import_rejects_large_file():
    settings.admin_import_max_file_bytes = 16
    upload = DummyUpload('questions.json', 'application/json', b'{' + b'a' * 40 + b'}')
    payload, err = _parse_admin_import_payload(upload)
    assert payload is None
    assert err.status_code == 413


def test_parse_admin_import_rejects_deep_json():
    settings.admin_import_max_file_bytes = 1_000_000
    settings.admin_import_max_json_depth = 5
    settings.admin_import_max_json_nodes = 10_000

    nested = [1]
    for _ in range(8):
        nested = [nested]

    upload = DummyUpload('questions.json', 'application/json', json.dumps(nested).encode('utf-8'))
    payload, err = _parse_admin_import_payload(upload)
    assert payload is None
    assert err.status_code == 400


def test_parse_admin_import_accepts_normal_json():
    settings.admin_import_max_file_bytes = 1_000_000
    settings.admin_import_max_json_depth = 20
    settings.admin_import_max_json_nodes = 100_000
    settings.admin_import_max_rows = 5000

    data = [{"test_id": "00000000-0000-0000-0000-000000000001", "text": "Savol", "options": ["A", "B"], "correct_index": 0}]
    upload = DummyUpload('questions.json', 'application/json', json.dumps(data).encode('utf-8'))
    payload, err = _parse_admin_import_payload(upload)
    assert err is None
    assert isinstance(payload, list)
    assert len(payload) == 1
