from app.api.routes import _current_allowed_for_status


def test_current_allowed_only_for_in_progress_attempts():
    assert _current_allowed_for_status('in_progress') is True
    assert _current_allowed_for_status('finished') is False
    assert _current_allowed_for_status('timed_out') is False
