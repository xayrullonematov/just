from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from app.services.attempts import submit_answer


class FakeDB:
    def __init__(self, locked_attempt):
        self.locked_attempt = locked_attempt
        self.scalar_calls = 0
        self.commit_calls = 0

    def scalar(self, _query):
        self.scalar_calls += 1
        if self.scalar_calls == 1:
            return self.locked_attempt
        raise AssertionError('submit_answer should not query answers/questions after timeout is detected')

    def commit(self):
        self.commit_calls += 1



def test_submit_answer_rejects_expired_attempt_before_answer_flow():
    expired_attempt = SimpleNamespace(
        id='attempt-1',
        status='in_progress',
        expires_at=datetime.now(timezone.utc) - timedelta(seconds=1),
    )
    db = FakeDB(expired_attempt)
    attempt_ref = SimpleNamespace(id='attempt-1')

    res = submit_answer(db, attempt_ref, question_id='q1', option_id='o1')

    assert res['error']['code'] == 'TIME_EXPIRED'
    assert expired_attempt.status == 'timed_out'
    assert db.commit_calls == 1
    assert db.scalar_calls == 1
