from datetime import datetime, timedelta, timezone

from app.api.routes import _build_weekly_correct_answers, _compute_ranking_percent


def test_compute_ranking_percent_from_real_position():
    assert _compute_ranking_percent(1, 10) == 10
    assert _compute_ranking_percent(5, 10) == 50
    assert _compute_ranking_percent(0, 10) is None


def test_build_weekly_correct_answers_buckets_by_day():
    now = datetime(2026, 1, 8, 12, 0, tzinfo=timezone.utc)
    rows = [
        (now - timedelta(days=1), None, 3),
        (now - timedelta(days=1, hours=2), None, 2),
        (None, now - timedelta(days=3), 4),
        (now - timedelta(days=10), None, 9),
    ]

    weekly = _build_weekly_correct_answers(rows, now)

    assert len(weekly) == 7
    # now-3d and now-1d should be aggregated in their buckets
    assert sum(weekly) == 9
    assert weekly[-2] == 5
