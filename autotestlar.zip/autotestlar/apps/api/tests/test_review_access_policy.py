from app.api.routes import _review_allowed_for_status


def test_review_allowed_only_for_finished_or_timed_out_attempts():
    assert _review_allowed_for_status('finished') is True
    assert _review_allowed_for_status('timed_out') is True
    assert _review_allowed_for_status('in_progress') is False
    assert _review_allowed_for_status('unknown') is False
