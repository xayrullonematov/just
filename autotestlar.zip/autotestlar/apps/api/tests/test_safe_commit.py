from app.api.routes import _safe_commit


class _OkDB:
    def __init__(self):
        self.committed = False
        self.rolled_back = False

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True


class _FailDB:
    def __init__(self):
        self.committed = False
        self.rolled_back = False

    def commit(self):
        self.committed = True
        raise RuntimeError('broken transaction')

    def rollback(self):
        self.rolled_back = True


def test_safe_commit_returns_true_on_success():
    db = _OkDB()
    assert _safe_commit(db) is True
    assert db.committed is True
    assert db.rolled_back is False


def test_safe_commit_rolls_back_and_returns_false_on_failure():
    db = _FailDB()
    assert _safe_commit(db) is False
    assert db.committed is True
    assert db.rolled_back is True
