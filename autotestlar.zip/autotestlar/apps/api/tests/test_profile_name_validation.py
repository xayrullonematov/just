from app.api.routes import _validate_profile_name


def test_validate_profile_name_accepts_trimmed_name():
    name, err = _validate_profile_name('  Ali Valiyev  ')
    assert err is None
    assert name == 'Ali Valiyev'


def test_validate_profile_name_rejects_empty_name():
    name, err = _validate_profile_name('   ')
    assert name is None
    assert err is not None
    assert err.status_code == 400


def test_validate_profile_name_rejects_too_long_name():
    name, err = _validate_profile_name('a' * 121)
    assert name is None
    assert err is not None
    assert err.status_code == 400
