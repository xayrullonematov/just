from app.core import rate_limit


def test_memory_limiter_prunes_expired_keys(monkeypatch):
    rate_limit.clear_buckets()

    now = {"t": 1_000.0}

    def fake_time():
        return now["t"]

    monkeypatch.setattr(rate_limit, "time", fake_time)

    assert rate_limit._memory_hit("ip:1", limit=5, window_s=10) is True
    assert "ip:1" in rate_limit._buckets

    now["t"] = 1_020.0
    assert rate_limit._memory_hit("ip:2", limit=5, window_s=10) is True

    # Trigger cleanup path for stale key and ensure it does not linger forever.
    assert rate_limit._memory_hit("ip:1", limit=5, window_s=10) is True
    assert len(rate_limit._buckets["ip:1"]) == 1

    rate_limit.clear_buckets()
