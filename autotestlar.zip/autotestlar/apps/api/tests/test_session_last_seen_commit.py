from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from app.api import deps


class FakeDB:
    def __init__(self, rec, user):
        self.rec = rec
        self.user = user
        self.commits = 0
        self.rollbacks = 0
        self.calls = 0

    def scalar(self, _query):
        self.calls += 1
        return self.rec if self.calls == 1 else self.user

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1


class FailingCommitDB(FakeDB):
    def commit(self):
        raise RuntimeError('db down')


def test_session_auth_commits_last_seen_update():
    rec = SimpleNamespace(
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        last_seen_at=None,
        user_id='u-1',
    )
    user = object()
    db = FakeDB(rec, user)

    got = deps.get_current_user_from_session(db, 'sid')

    assert got is user
    assert rec.last_seen_at is not None
    assert db.commits == 1
    assert db.rollbacks == 0


def test_session_auth_rolls_back_when_commit_fails():
    rec = SimpleNamespace(
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        last_seen_at=None,
        user_id='u-2',
    )
    user = object()
    db = FailingCommitDB(rec, user)

    got = deps.get_current_user_from_session(db, 'sid')

    assert got is user
    assert rec.last_seen_at is not None
    assert db.rollbacks == 1
