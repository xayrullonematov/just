from app.core.config import settings
from app.core import email_service


class _BrokenExecutor:
    def submit(self, *args, **kwargs):
        raise RuntimeError("queue down")


def test_send_email_dev_log_returns_true(monkeypatch):
    monkeypatch.setattr(settings, "email_provider", "dev_log")
    assert email_service.send_email("u@example.com", "Subject", "Body") is True


def test_send_email_enqueue_failure_is_swallowed(monkeypatch):
    monkeypatch.setattr(settings, "email_provider", "smtp")
    monkeypatch.setattr(email_service, "_email_executor", _BrokenExecutor())
    assert email_service.send_email("u@example.com", "Subject", "Body") is False
