from datetime import datetime, timedelta, timezone
import uuid
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.models.models import User, Test, Question, Option, CorrectAnswer, Attempt, AttemptQuestion, Answer
from app.services.attempts import submit_answer, guard_active_time, start_attempt


def setup_db():
    engine = create_engine('sqlite+pysqlite:///:memory:', future=True)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, autocommit=False)()


def seed(db):
    u = User(email='u@e.com', name='u', password_hash='x')
    t = Test(title='T1', type='ticket', question_count=1, time_limit_seconds=60)
    db.add_all([u,t]); db.flush()
    q = Question(test_id=t.id, text='q')
    db.add(q); db.flush()
    o1 = Option(question_id=q.id, text='A'); o2 = Option(question_id=q.id, text='B')
    db.add_all([o1,o2]); db.flush()
    db.add(CorrectAnswer(question_id=q.id, option_id=o1.id)); db.commit()
    return u,t,q,o1,o2


def test_timer_expiry_enforced():
    db = setup_db(); u,t,q,o1,_ = seed(db)
    a = Attempt(user_id=u.id, test_id=t.id, mode='exam', status='in_progress', started_at=datetime.now(timezone.utc), expires_at=datetime.now(timezone.utc)-timedelta(seconds=1))
    db.add(a); db.flush(); db.add(AttemptQuestion(attempt_id=a.id, index=1, question_id=q.id)); db.commit()
    err = guard_active_time(db, a)
    assert err['error']['code'] == 'TIME_EXPIRED'


def test_duplicate_answer_rejected():
    db = setup_db(); u,t,q,o1,_ = seed(db)
    a = Attempt(user_id=u.id, test_id=t.id, mode='exam', status='in_progress', started_at=datetime.now(timezone.utc), expires_at=datetime.now(timezone.utc)+timedelta(seconds=30))
    db.add(a); db.flush(); db.add(AttemptQuestion(attempt_id=a.id, index=1, question_id=q.id)); db.flush()
    db.add(Answer(attempt_id=a.id, question_id=q.id, option_id=o1.id, is_correct=True)); db.commit()
    res = submit_answer(db, a, q.id, o1.id)
    assert res['error']['code'] in ('INVALID_SEQUENCE', 'DUPLICATE_ANSWER')


def test_concurrent_attempt_prevention_idempotent_start():
    db = setup_db(); u,t,_,_,_ = seed(db)
    a1 = start_attempt(db, u.id, t.id, 'exam')
    a2 = start_attempt(db, u.id, t.id, 'exam')
    assert str(a1.id) == str(a2.id)


def test_sequence_uses_first_unanswered_question():
    db = setup_db()
    u = User(email='u2@e.com', name='u2', password_hash='x')
    t = Test(title='T2', type='ticket', question_count=2, time_limit_seconds=60)
    db.add_all([u, t]); db.flush()

    q1 = Question(test_id=t.id, text='q1')
    q2 = Question(test_id=t.id, text='q2')
    db.add_all([q1, q2]); db.flush()

    o11 = Option(question_id=q1.id, text='A1'); o12 = Option(question_id=q1.id, text='B1')
    o21 = Option(question_id=q2.id, text='A2'); o22 = Option(question_id=q2.id, text='B2')
    db.add_all([o11, o12, o21, o22]); db.flush()

    db.add_all([
        CorrectAnswer(question_id=q1.id, option_id=o11.id),
        CorrectAnswer(question_id=q2.id, option_id=o21.id),
    ])

    a = Attempt(user_id=u.id, test_id=t.id, mode='exam', status='in_progress', started_at=datetime.now(timezone.utc), expires_at=datetime.now(timezone.utc)+timedelta(seconds=30))
    db.add(a); db.flush()
    db.add_all([
        AttemptQuestion(attempt_id=a.id, index=1, question_id=q1.id),
        AttemptQuestion(attempt_id=a.id, index=2, question_id=q2.id),
    ])
    db.flush()

    # First question already answered; next valid is q2
    db.add(Answer(attempt_id=a.id, question_id=q1.id, option_id=o11.id, is_correct=True))
    db.commit()

    res = submit_answer(db, a, q2.id, o21.id)
    assert res.get('ok') is True
    assert res.get('next_index') == 3
