'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { csrf, getJSON, postJSON } from '../../../lib/api';
import styles from './review.module.css';

type OptionVM = { id: string; text: string };

type ReviewItem = {
  question_id: string;
  text: string;
  image_url: string | null;
  options: OptionVM[];
  chosen_option_id: string | null;
  correct_option_id: string | null;
  explanation: string;
};

type ReviewAttempt = {
  id: string;
  test_title: string;
  score_percent: number;
  answered_count: number;
  correct_answers: number;
  total_questions: number;
  status: string;
};

type ReviewResponse = {
  attempt: ReviewAttempt;
  score_percent: number;
  items: ReviewItem[];
  error?: { message?: string };
};

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function safeInt(v: unknown, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function isCorrect(item: ReviewItem) {
  if (!item.chosen_option_id || !item.correct_option_id) return false;
  return item.chosen_option_id === item.correct_option_id;
}

function optionKind(item: ReviewItem, optId: string): 'correct' | 'wrong' | 'chosen' | 'neutral' {
  const chosen = item.chosen_option_id;
  const correct = item.correct_option_id;

  if (correct && optId === correct) return 'correct';
  if (chosen && correct && chosen !== correct && optId === chosen) return 'wrong';
  if (chosen && optId === chosen) return 'chosen';
  return 'neutral';
}

export default function ReviewPage() {
  const params = useParams<{ attempt_id: string }>();
  const attemptId = params?.attempt_id;

  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [attempt, setAttempt] = useState<ReviewAttempt | null>(null);
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [index, setIndex] = useState(0);

  const [navOpen, setNavOpen] = useState(false);
  const [resolving, setResolving] = useState(false);

  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  useEffect(() => {
    if (!attemptId) return;

    (async () => {
      try {
        setLoading(true);
        setError('');
        const res = (await getJSON(`/attempts/${attemptId}/review`)) as ReviewResponse;

        if (res?.error) {
          setError(res.error.message || "Review yuklab bo‘lmadi.");
          setLoading(false);
          return;
        }

        setAttempt(res.attempt);
        setItems(res.items || []);
        setIndex(0);
        setLoading(false);
      } catch {
        setError('Kutilmagan xatolik yuz berdi.');
        setLoading(false);
      }
    })();
  }, [attemptId]);

  // Keyboard navigation (desktop)
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'ArrowLeft') prev();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'Escape') setNavOpen(false);
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, items.length]);

  const total = items.length;

  const current = useMemo(() => items[index] ?? null, [items, index]);

  const wrongCount = useMemo(() => {
    return items.reduce((acc, it) => acc + (isCorrect(it) ? 0 : 1), 0);
  }, [items]);

  const progressPct = useMemo(() => {
    if (!total) return 0;
    return clamp(((index + 1) / total) * 100, 0, 100);
  }, [index, total]);

  function go(i: number) {
    if (!total) return;
    setIndex(clamp(i, 0, total - 1));
    setNavOpen(false);
  }

  function prev() {
    if (!total) return;
    setIndex((i) => clamp(i - 1, 0, total - 1));
  }

  function next() {
    if (!total) return;
    setIndex((i) => clamp(i + 1, 0, total - 1));
  }

  async function markDoneCurrent() {
    if (!current) return;

    try {
      setResolving(true);
      await csrf();
      const res = await postJSON('/me/mistakes/resolve', {
        question_id: current.question_id,
        source_attempt_id: attemptId,
        note: null,
      });
      if (res?.error) {
        alert(res?.error?.message || "Belgilab bo‘lmadi.");
        setResolving(false);
        return;
      }
      // UX: move forward automatically
      if (!mounted.current) return;
      setResolving(false);
      if (index < total - 1) next();
      else router.push('/mistakes');
    } catch {
      setResolving(false);
      alert('Kutilmagan xatolik yuz berdi.');
    }
  }

  if (loading) {
    return (
      <main className={styles.page}>
        <div className={styles.loading}>Yuklanmoqda…</div>
      </main>
    );
  }

  if (error) {
    return (
      <main className={styles.page}>
        <div className={styles.errorCard}>
          <div className={styles.errorTitle}>⚠️ Xatolik</div>
          <div className={styles.errorText}>{error}</div>
          <div className={styles.errorActions}>
            <Link href="/mistakes" className={styles.btnSecondary}>
              ← Xatolarim
            </Link>
            <Link href="/app" className={styles.btnPrimary}>
              Dashboard →
            </Link>
          </div>
        </div>
      </main>
    );
  }

  if (!current || !attempt) {
    return (
      <main className={styles.page}>
        <div className={styles.errorCard}>
          <div className={styles.errorTitle}>Hech narsa topilmadi</div>
          <Link href="/mistakes" className={styles.btnPrimary}>
            ← Xatolarim
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className={styles.page}>
      {/* Top bar */}
      <header className={styles.header}>
        <Link href="/mistakes" className={styles.brand} aria-label="Mistakes">
          <span className={styles.brandIcon}>🧠</span>
          <span className={styles.brandText}>REVIEW</span>
        </Link>

        <div className={styles.headerMid}>
          <div className={styles.title}>{attempt.test_title}</div>
          <div className={styles.sub}>
            {attempt.correct_answers}/{attempt.total_questions} to‘g‘ri · {wrongCount} xato · {attempt.score_percent}% natija
          </div>
        </div>

        <div className={styles.headerRight}>
          <button className={styles.iconBtn} type="button" onClick={() => setNavOpen((v) => !v)}>
            ☰
          </button>
          <Link href="/app" className={styles.iconBtn} aria-label="Close">
            ✕
          </Link>
        </div>
      </header>

      {/* Progress */}
      <div className={styles.progressWrap}>
        <div className={styles.progressBar}>
          <div className={styles.progressFill} style={{ width: `${progressPct}%` }} />
        </div>
        <div className={styles.progressMeta}>
          <span>
            Savol <b>{index + 1}</b> / {total}
          </span>
          <span className={styles.muted}>←/→ tugmalar bilan o‘ting</span>
        </div>
      </div>

      <div className={styles.layout}>
        {/* Side navigator (desktop) */}
        <aside className={styles.sidebar}>
          <div className={styles.sideTitle}>Navigatsiya</div>
          <div className={styles.gridNav}>
            {items.map((it, i) => {
              const ok = isCorrect(it);
              const active = i === index;
              return (
                <button
                  key={it.question_id}
                  type="button"
                  className={`${styles.navCell} ${ok ? styles.navOk : styles.navBad} ${active ? styles.navActive : ''}`}
                  onClick={() => go(i)}
                  title={ok ? 'To‘g‘ri' : 'Xato'}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          <div className={styles.sideActions}>
            <button className={styles.btnSecondary} type="button" onClick={() => setIndex(0)}>
              Boshiga
            </button>
            <Link className={styles.btnGhost} href="/mistakes">
              Xatolarim
            </Link>
          </div>
        </aside>

        {/* Main question */}
        <section className={styles.main}>
          <article className={styles.card}>
            <div className={styles.cardTop}>
              <div className={styles.qBadge}>
                {isCorrect(current) ? (
                  <span className={styles.good}>✅ To‘g‘ri</span>
                ) : (
                  <span className={styles.bad}>❌ Xato</span>
                )}
              </div>

              <div className={styles.qActions}>
                <button className={styles.btnSecondary} type="button" onClick={prev} disabled={index === 0}>
                  ← Oldingi
                </button>
                <button className={styles.btnSecondary} type="button" onClick={next} disabled={index === total - 1}>
                  Keyingi →
                </button>
              </div>
            </div>

            <div className={styles.qText}>{current.text}</div>

            {current.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className={styles.qImage} src={current.image_url} alt="Savol rasmi" />
            ) : null}

            <div className={styles.options}>
              {current.options.map((o, i) => {
                const k = optionKind(current, o.id);
                const letter = String.fromCharCode(65 + i); // A B C D
                return (
                  <div key={o.id} className={`${styles.option} ${styles[`opt_${k}`]}`}>
                    <div className={styles.optLeft}>
                      <div className={styles.optLetter}>{letter}</div>
                      <div className={styles.optText}>{o.text}</div>
                    </div>

                    <div className={styles.optRight}>
                      {k === 'correct' ? <span className={styles.pillOk}>To‘g‘ri</span> : null}
                      {k === 'wrong' ? <span className={styles.pillBad}>Siz tanlagan</span> : null}
                      {k === 'chosen' ? <span className={styles.pillChosen}>Tanlangan</span> : null}
                    </div>
                  </div>
                );
              })}
            </div>

            <details className={styles.explBox} open>
              <summary className={styles.explSum}>Izoh</summary>
              <div className={styles.explText}>{current.explanation || 'Izoh mavjud emas.'}</div>
            </details>

            <div className={styles.bottomActions}>
              <button className={styles.btnGhost} type="button" onClick={() => setNavOpen(true)}>
                Navigatsiya
              </button>

              <button className={styles.btnPrimary} type="button" onClick={markDoneCurrent} disabled={resolving}>
                {resolving ? 'Saqlanmoqda…' : 'Bajarildi ✓'}
              </button>
            </div>
          </article>
        </section>
      </div>

      {/* Mobile drawer nav */}
      {navOpen ? (
        <div className={styles.drawerOverlay} onClick={() => setNavOpen(false)} role="presentation">
          <div className={styles.drawer} onClick={(e) => e.stopPropagation()} role="presentation">
            <div className={styles.drawerTop}>
              <div className={styles.drawerTitle}>Savollar</div>
              <button className={styles.iconBtn} type="button" onClick={() => setNavOpen(false)}>
                ✕
              </button>
            </div>

            <div className={styles.gridNavDrawer}>
              {items.map((it, i) => {
                const ok = isCorrect(it);
                const active = i === index;
                return (
                  <button
                    key={it.question_id}
                    type="button"
                    className={`${styles.navCell} ${ok ? styles.navOk : styles.navBad} ${active ? styles.navActive : ''}`}
                    onClick={() => go(i)}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>

            <div className={styles.drawerActions}>
              <button className={styles.btnSecondary} type="button" onClick={prev} disabled={index === 0}>
                ← Oldingi
              </button>
              <button className={styles.btnSecondary} type="button" onClick={next} disabled={index === total - 1}>
                Keyingi →
              </button>
              <Link className={styles.btnGhost} href="/mistakes">
                Xatolarim
              </Link>
            </div>
          </div>
        </div>
      ) : null}

      {/* Mobile sticky nav */}
      <footer className={styles.mobileBar}>
        <button className={styles.mobileBtn} type="button" onClick={prev} disabled={index === 0}>
          ←
        </button>
        <button className={styles.mobileBtn} type="button" onClick={() => setNavOpen(true)}>
          ☰ {index + 1}/{total}
        </button>
        <button className={styles.mobileBtn} type="button" onClick={next} disabled={index === total - 1}>
          →
        </button>
      </footer>
    </main>
  );
}
