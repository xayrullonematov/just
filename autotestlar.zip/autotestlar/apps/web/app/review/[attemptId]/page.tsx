'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getJSON } from '../../../lib/api';

export default function ReviewPage({ params }: any) {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      const res = await getJSON(`/attempts/${params.attemptId}/review`);
      if (res?.error) return setError(res.error.message);
      setData(res);
    })();
  }, [params.attemptId]);

  if (error) return <main><h1>Review</h1><p>{error}</p><p><Link href="/mistakes">← Xatolarim</Link></p></main>;
  if (!data) return <main><h1>Review</h1><p>Yuklanmoqda...</p></main>;

  return (
    <main>
      <h1>Review</h1>
      {(data.items || []).map((it: any, idx: number) => {
        const chosen = (it.options || []).find((o: any) => o.id === it.chosen_option_id);
        const correct = (it.options || []).find((o: any) => o.id === it.correct_option_id);
        return (
          <div key={it.question_id} style={{ marginBottom: 12 }}>
            <b>{idx + 1}. {it.text}</b>
            <div>Tanlangan: {chosen?.text || '—'}</div>
            <div>To‘g‘ri: {correct?.text || '—'}</div>
            {it.explanation ? <div>Izoh: {it.explanation}</div> : null}
          </div>
        );
      })}
      <p><Link href="/mistakes">← Xatolarim</Link></p>
    </main>
  );
}
