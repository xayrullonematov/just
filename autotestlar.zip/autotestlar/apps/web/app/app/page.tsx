'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { csrf, getJSON, postJSON } from '../../lib/api';
import { useRouter, usePathname } from 'next/navigation';
import styles from './page.module.css';

type DashboardState = 'loading' | 'error' | 'data';

type DashboardData = {
  user_name: string;
  subtitle: string;
  daily_limit: number | null;
  daily_done: number | null;
  plan_name: string | null;
  plan_note: string | null;
  ranking_percent: number | null;
  weekly_correct_answers: number[];
  daily_tasks: Array<{ title: string; questions: number; time_minutes: number; level: string }>;
};

const baseData: DashboardData = {
  user_name: 'Foydalanuvchi',
  subtitle: "Dashboard ma'lumotlari mavjud emas",
  daily_limit: null,
  daily_done: null,
  plan_name: null,
  plan_note: null,
  ranking_percent: null,
  weekly_correct_answers: [0, 0, 0, 0, 0, 0, 0],
  daily_tasks: [],
};

const FEATURE_CARDS = [
  { icon: '\u{1F4DA}', title: 'Biletlar', text: "Bilimingizni YHQ biletlari bilan sinang. Progressni kuzatib boring.", href: '/tickets', action: 'Biletlarni ochish', cls: styles.f1 },
  { icon: '\u270D\uFE0F', title: 'Mashq', text: "20 ta tasodifiy savolga javob bering. Barcha savollarga javob bering.", href: '/practice', action: 'Mashqni boshlash', cls: styles.f2 },
  { icon: '\u{1F6E1}\uFE0F', title: 'Imtihon', text: "20 ta savol, 2 ta xatogacha ruxsat. 3-xatoda to\u02BCxtatiladi.", href: '/exam', action: "Imtihonga o\u02BCtish", cls: styles.f3 },
  { icon: '\u{1F3AF}', title: 'Xatolarim', text: "Xato javob berilgan savollar ustida qayta ishlang.", href: '/mistakes', action: "Xatolarni ko\u02BCrish", cls: styles.f4 },
];

const WEEKLY_LABELS = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'];

const BOTTOM_TABS = [
  { href: '/app', icon: '\u{1F3E0}', label: 'Bosh' },
  { href: '/tickets', icon: '\u{1F4DA}', label: 'Biletlar' },
  { href: '/practice', icon: '\u270D\uFE0F', label: 'Mashq' },
  { href: '/exam', icon: '\u{1F6E1}\uFE0F', label: 'Imtihon' },
  { href: '/daily', icon: '\u{1F4CB}', label: 'Vazifa' },
  { href: '/profile', icon: '\u{1F464}', label: 'Profil' },
];

export default function AppPage() {
  const [state, setState] = useState<DashboardState>('loading');
  const [err, setErr] = useState('');
  const [me, setMe] = useState<any>(null);
  const [dashboard, setDashboard] = useState<DashboardData>(baseData);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    (async () => {
      try {
        const authRes = await getJSON('/auth/me');
        if (authRes?.error) { router.push('/login'); return; }

        const meRes = await getJSON('/me');
        if (meRes?.error) { setErr(meRes.error.message || 'Kirish talab qilinadi.'); setState('error'); return; }
        setMe(meRes);

        const dashRes = await getJSON('/me/dashboard');
        if (dashRes?.error) { setErr(dashRes.error.message || "Dashboard ma'lumotlarini olib bo'lmadi."); setState('error'); return; }

        setDashboard({ ...baseData, ...dashRes });
        await new Promise(r => setTimeout(r, 120));
        setState('data');
      } catch {
        setErr("Dashboard ma'lumotlarini olib bo'lmadi.");
        setState('error');
      }
    })();
  }, [router]);

  const d = useMemo<DashboardData>(() => ({
    ...dashboard,
    user_name: me?.name || dashboard.user_name,
    daily_tasks: dashboard.daily_tasks || [],
    weekly_correct_answers: dashboard.weekly_correct_answers?.length
      ? dashboard.weekly_correct_answers
      : baseData.weekly_correct_answers,
  }), [dashboard, me]);

  const weeklyMax = Math.max(...d.weekly_correct_answers, 1);

  const initials = (me?.name || 'HJ')
    .split(' ').slice(0, 2)
    .map((s: string) => s[0]?.toUpperCase() || '')
    .join('');

  async function handleLogout() {
    await csrf();
    const res = await postJSON('/auth/logout', {});
    if (!res.error) router.push('/login');
  }

  return (
    <>
      <nav className={styles.navbar}>
        <div className={styles.navInner}>
          <Link href="/app" className={styles.logo}>
            <div className={styles.logoIcon}>🎯</div>
            <span className={styles.logoText}>AUTO TESTLAR</span>
          </Link>

          <div className={styles.navRight}>
            <Link href="/profile" className={[styles.btn, styles.btnPremium].join(' ')}>
              <span>👑</span><span>Profil</span>
            </Link>
            <Link href="/notifications" className={[styles.btn, styles.btnIcon].join(' ')} aria-label="Bildirishnomalar">
              🔔
            </Link>
            <div className={styles.avatar}>{initials}</div>
            <button className={[styles.btn, styles.btnSecondary].join(' ')} onClick={handleLogout}>
              <span className={styles.logoutLabel}>Chiqish</span>
              <span>⏻</span>
            </button>
          </div>
        </div>
      </nav>

      <div className={styles.pageWrapper}>
        <div className={[styles.panel, styles.panelHome].join(' ')}>
          <div className={styles.greetingCard}>
            <h1>Salom, {d.user_name} 👋</h1>
            <p>{d.subtitle}</p>
            <div className={styles.greetingBtns}>
              <Link href="/practice" className={[styles.btn, styles.btnPrimary].join(' ')}>Testni boshlash</Link>
              {/* FIX: "Imtihon rejimi" should go to exam */}
              <Link href="/exam" className={[styles.btn, styles.btnSecondary].join(' ')}>Imtihon rejimi</Link>
            </div>
          </div>

          {(state === 'loading' || err) && (
            <div className={[styles.statusBanner, err ? styles.statusError : ''].join(' ')}>
              {state === 'loading' ? "Dashboard yuklanmoqda..." : err}
            </div>
          )}

          <div className={styles.statsStrip}>
            <div className={[styles.statCard, styles.statBasic].join(' ')}>
              <div className={[styles.statBadge, styles.badgeBasic].join(' ')}>Kunlik limit</div>
              <div className={styles.statValue}>
                {d.daily_limit === null ? '—' : `${d.daily_limit} ta test`}
              </div>
              <div className={styles.statDesc}>
                Bugun ishlangan: {d.daily_done === null ? '—' : d.daily_done}
              </div>
            </div>

            <div className={[styles.statCard, styles.statPremium].join(' ')}>
              <div className={[styles.statBadge, styles.badgePremium].join(' ')}>Premium</div>
              <div className={styles.statValue}>{d.plan_name || '—'}</div>
              <div className={styles.statDesc}>{d.plan_note || "Reja ma'lumoti mavjud emas"}</div>
            </div>

            <div className={[styles.statCard, styles.statRanking].join(' ')}>
              <div className={[styles.statBadge, styles.badgeRanking].join(' ')}>Reyting</div>
              <div className={styles.statValue}>
                {d.ranking_percent === null ? '—' : `Top ${d.ranking_percent}%`}
              </div>
              <div className={styles.statDesc}>
                {d.ranking_percent === null ? "Reyting uchun yetarli urinish yo'q" : "So'nggi 7 kun natijasi"}
              </div>
            </div>
          </div>

          <div className={styles.chartCard}>
            <div className={styles.cardTitle}>Statistika</div>
            <div className={styles.cardSubtitle}>Haftalik to&apos;g&apos;ri javoblar</div>
            <div className={styles.chartBars}>
              {WEEKLY_LABELS.map((label, idx) => {
                const count = d.weekly_correct_answers[idx] || 0;
                const height = Math.round((count / weeklyMax) * 100);
                return (
                  <div className={styles.barCol} key={label}>
                    <div className={styles.barLabel}>{label}</div>
                    <div className={styles.barTrack}>
                      <div className={styles.barFill} style={{ height: `${height}%` }} />
                    </div>
                    <div className={styles.barCount}>{count}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className={[styles.panel, styles.panelRight].join(' ')}>
          <div>
            <div className={styles.secHeader}>
              <div className={styles.secTitle}>Asosiy imkoniyatlar</div>
              <div className={styles.secSub}>Professional imtihonga onlayn tayyorgarlik</div>
            </div>

            <div className={styles.featuresGrid}>
              {FEATURE_CARDS.map((f) => (
                <Link href={f.href} key={f.title} className={[styles.featureCard, f.cls].join(' ')}>
                  <div className={styles.featureIcon}>{f.icon}</div>
                  <div className={styles.featureTitle}>{f.title}</div>
                  <div className={styles.featureDesc}>{f.text}</div>
                  <span className={styles.farrow}><span>{f.action}</span><span>→</span></span>
                </Link>
              ))}
            </div>
          </div>

          <div className={styles.tasksCard}>
            <div className={styles.secHeader} style={{ marginBottom: 0 }}>
              <div className={styles.secTitle}>Kunlik vazifa</div>
              <div className={styles.secSub}>Har kuni 10 savol bilan imtihonga tayyor bo&apos;ling</div>
            </div>

            <div className={styles.taskTabs}>
              <Link href="/tickets" className={[styles.ttab, styles.ttabActive].join(' ')}>Kategoriyalar</Link>
              <Link href="/daily" className={styles.ttab}>Testni boshlash</Link>
            </div>

            <div className={styles.taskList}>
              {d.daily_tasks.length === 0 ? (
                <div className={styles.emptyTasks}>
                  Bugungi vazifa uchun testlar hozircha mavjud emas.
                </div>
              ) : (
                d.daily_tasks.map((task, i) => (
                  <Link href="/daily" key={task.title} className={styles.taskItem}>
                    <div className={styles.taskNum}>{i + 1}</div>
                    <div className={styles.taskInfo}>
                      <div className={styles.taskTitle}>{task.title}</div>
                      <div className={styles.taskMeta}>
                        <span>📝 {task.questions} savol</span>
                        <span>⏱️ {task.time_minutes} daqiqa</span>
                        <span>🎯 {task.level}</span>
                      </div>
                    </div>
                    <span className={styles.taskGo}>Boshlash</span>
                  </Link>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <nav className={styles.mobileBottomNav}>
        {BOTTOM_TABS.map((t) => {
          const active = pathname === t.href;
          return (
            <Link
              key={t.href}
              href={t.href}
              aria-current={active ? 'page' : undefined}
              className={[styles.bottomTab, active ? styles.bottomTabActive : ''].join(' ')}
            >
              <span className={styles.tabIcon}>{t.icon}</span>
              <span>{t.label}</span>
            </Link>
          );
        })}
      </nav>
    </>
  );
}
