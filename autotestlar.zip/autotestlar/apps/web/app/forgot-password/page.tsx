'use client';
import { FormEvent, useState } from 'react';
import { csrf, postJSON } from '../../lib/api';

export default function ForgotPasswordPage(){
  const [email,setEmail]=useState('');
  const [msg,setMsg]=useState('');
  async function onSubmit(e:FormEvent){
    e.preventDefault();
    await csrf();
    const res=await postJSON('/auth/forgot-password',{email});
    setMsg(res.reset_link ? `DEV reset link: ${res.reset_link}` : 'Agar email mavjud bo‘lsa xabar yuborildi.');
  }
  return <main><h1>Forgot password</h1><form onSubmit={onSubmit}><input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email' /><button type='submit'>Send</button></form><p>{msg}</p></main>
}
