'use client';

import Link from 'next/link';
import { useState } from 'react';
import { csrf, postJSON, readCookie } from '../../lib/api';

export default function SecurityPage() {
  const [secret, setSecret] = useState('');
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([]);
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState('');

  async function setup2FA() {
    await csrf();
    const res = await postJSON('/auth/2fa/setup', {});
    if (res?.error) return setMsg(res.error.message);
    setSecret(res.secret || '');
    setRecoveryCodes(res.recovery_codes || []);
    setMsg('2FA sozlandi. Endi authenticator kodini tasdiqlang.');
  }

  async function enable2FA() {
    await csrf();
    const res = await postJSON('/auth/2fa/enable', { code });
    setMsg(res?.error ? res.error.message : '2FA yoqildi ✅');
  }

  async function refreshSession() {
    await csrf();
    const res = await postJSON('/auth/refresh', {});
    setMsg(res?.error ? res.error.message : 'Sessiya yangilandi.');
  }

  return (
    <main className="page">
      <section className="card hero">
        <h1>Xavfsizlik markazi</h1>
        <p>2FA, recovery code va sessiya boshqaruvi.</p>
        <div className="links">
          <Link href="/profile" className="linkBtn">← Profil</Link>
          <Link href="/app" className="linkBtn">Dashboard</Link>
        </div>
      </section>

      <section className="grid">
        <article className="card">
          <h2>2FA sozlash</h2>
          <p>Authenticator ilova bilan bog'lang va himoyani yoqing.</p>
          <button className="btnPrimary" onClick={setup2FA}>2FA Setup</button>
          {secret && <p className="secret"><b>Secret:</b> {secret}</p>}
        </article>

        <article className="card">
          <h2>2FA yoqish</h2>
          <p>Ilovadagi 6 xonali kodni kiriting.</p>
          <div className="row">
            <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Authenticator code" />
            <button className="btnPrimary" onClick={enable2FA}>2FA Enable</button>
          </div>
        </article>

        <article className="card">
          <h2>Sessiya</h2>
          <p>Access token yangilash uchun refresh endpoint.</p>
          <button className="btnSecondary" onClick={refreshSession}>Refresh session</button>
        </article>
      </section>

      {!!recoveryCodes.length && (
        <section className="card">
          <h2>Recovery kodlar</h2>
          <p>Ularni xavfsiz joyda saqlang (bir martalik ishlatiladi).</p>
          <div className="codes">
            {recoveryCodes.map((c) => <span key={c} className="codeItem">{c}</span>)}
          </div>
        </section>
      )}

      {msg && <section className="card msg">{msg}</section>}

      <style jsx>{`
        .page { max-width: 1100px; margin: 0 auto; padding: 28px 16px 40px; background: #f8f8fa; min-height: 100vh; }
        .grid { display: grid; gap: 16px; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); margin-top: 16px; }
        .card { background: #fff; border: 1px solid #e8e8ec; border-radius: 18px; padding: 20px; box-shadow: 0 4px 18px rgba(0,0,0,.04); }
        .hero h1 { font-size: 28px; margin: 0 0 6px; color: #0a0a0f; }
        .hero p { margin: 0; color: #525266; }
        h2 { margin: 0 0 8px; color: #0a0a0f; font-size: 18px; }
        p { color: #525266; margin: 0 0 12px; }
        .row { display: flex; gap: 8px; align-items: center; }
        input { flex: 1; border: 1px solid #e8e8ec; border-radius: 10px; padding: 10px 12px; font-size: 14px; }
        .btnPrimary, .btnSecondary, .linkBtn { border: none; border-radius: 999px; padding: 10px 16px; cursor: pointer; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; }
        .btnPrimary { background: linear-gradient(135deg,#ff6b35 0%,#ff8555 100%); color: #fff; }
        .btnSecondary { background: #f3f3f6; color: #0a0a0f; border: 1px solid #e8e8ec; }
        .links { display: flex; gap: 10px; margin-top: 12px; }
        .linkBtn { background: #fff; color: #0a0a0f; border: 1px solid #e8e8ec; }
        .codes { display: grid; grid-template-columns: repeat(auto-fill,minmax(120px,1fr)); gap: 8px; }
        .codeItem { background: #0a0a0f; color: #fff; border-radius: 8px; padding: 8px 10px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
        .msg { margin-top: 16px; border-left: 4px solid #00d4aa; }
        .secret { word-break: break-all; }
      `}</style>
    </main>
  );
}
