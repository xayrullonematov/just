'use client';

import Link from 'next/link';
import { useState } from 'react';
import { csrf, deleteJSON, readCookie } from '../../../lib/api';
import { useRouter } from 'next/navigation';

export default function DeleteAccountPage() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const router = useRouter();

  async function remove() {
    setLoading(true);
    await csrf();
    const res = await deleteJSON('/me');
    if (res?.error) {
      setMsg(res.error.message);
      setLoading(false);
      return;
    }
    setMsg('Akkaunt o‘chirildi.');
    setTimeout(() => router.push('/signup'), 500);
  }

  return (
    <main>
      <h1>Akkauntni o‘chirish</h1>
      <p>Bu amal qaytarilmaydi.</p>
      <button disabled={loading} onClick={remove}>{loading ? 'Kutilmoqda...' : 'Ha, o‘chirish'}</button>
      {msg && <p>{msg}</p>}
      <p><Link href="/profile">← Profilga qaytish</Link></p>
    </main>
  );
}
