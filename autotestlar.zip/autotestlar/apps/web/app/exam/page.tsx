import { Suspense } from 'react';
import ExamClient from './ExamClient';

export const dynamic = 'force-dynamic';

export default function ExamPage() {
  return (
    <Suspense fallback={<main style={{ padding: 24 }}>Imtihon yuklanmoqda...</main>}>
      <ExamClient />
    </Suspense>
  );
}
