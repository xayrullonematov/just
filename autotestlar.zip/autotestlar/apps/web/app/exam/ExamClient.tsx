'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { csrf, getJSON, postJSON, readCookie } from '../../lib/api';
import styles from './exam.module.css';

type OptionVM = { id: string; text: string };
type QuestionVM = { id: string; text: string; image_url: string | null; options: OptionVM[] };

type AnswerStatus = 'unanswered' | 'answered';

type Snapshot = {
  question: QuestionVM;
  selectedOptionId: string | null;
  selectedIndex: number | null;
  status: AnswerStatus;
};

// strict UUID v1-v5
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

const EXAM_TEST_ID = '0d4bb0ee-a8d4-4024-883f-80bd5d00086b';

export default function ExamClient() {
  const searchParams = useSearchParams();
  const requestedMode = searchParams.get('mode') === 'practice' ? 'practice' : 'exam';

  const qpTestId = searchParams.get('testId') || '';
  const testIdParam = UUID_RE.test(qpTestId) ? qpTestId : EXAM_TEST_ID;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [attemptId, setAttemptId] = useState('');
  const [testId, setTestId] = useState('');
  const [totalQuestions, setTotalQuestions] = useState(20);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentServerIndex, setCurrentServerIndex] = useState(1);
  const [testFinished, setTestFinished] = useState(false);

  const [timeRemaining, setTimeRemaining] = useState(1500);

  const [snapshots, setSnapshots] = useState<Record<number, Snapshot>>({});
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(Array(20).fill(null));
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);

  const [modalActive, setModalActive] = useState(false);
  const [modalIcon, setModalIcon] = useState('🎉');
  const [modalTitle, setModalTitle] = useState('Imtihon yakunlandi!');
  const [modalSubtitle, setModalSubtitle] = useState('');
  const [modalFailClass, setModalFailClass] = useState(false);

  // ✅ race condition va duplicate click oldini olish
  const [loadingNext, setLoadingNext] = useState(false);
  const nextReqIdRef = useRef(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const viewed = snapshots[currentQuestionIndex];
  const currentQuestion = viewed?.question || null;

  const questionAnswered = Boolean(viewed && viewed.status === 'answered');

  const answeredCount = userAnswers.filter((a) => a !== null).length;
  const unansweredCount = Math.max(totalQuestions - answeredCount, 0);

  const timeDisplay = useMemo(() => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }, [timeRemaining]);

  // Bootstrap: CSRF -> get test -> start attempt -> load current question
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError('');

        if (!UUID_RE.test(testIdParam || '')) {
          setError("Test ID noto'g'ri yoki topilmadi (URL yoki .env xato).");
          setLoading(false);
          return;
        }

        await csrf();

        const selected = await getJSON(`/tests/${testIdParam}`);
        if (selected?.error) {
          setError(selected.error.message || 'Test topilmadi.');
          setLoading(false);
          return;
        }

        const start = await postJSON(
          '/attempts/start',
          { test_id: selected.id, mode: requestedMode },
        );

        if (start?.error) {
          setError(start.error.message || 'Imtihonni boshlashda xatolik.');
          setLoading(false);
          return;
        }

        setAttemptId(start.attempt_id);
        setTestId(selected.id);

        if (requestedMode === 'exam') {
          const tl = Number(selected.time_limit_seconds || 0);
          setTimeRemaining(tl > 0 ? tl : 1500);
        } else {
          setTimeRemaining(1500);
        }

        const current = await getJSON(`/attempts/${start.attempt_id}/current`);
        if (current?.error) {
          setError(current.error.message || "Savolni yuklab bo'lmadi.");
          setLoading(false);
          return;
        }

        const total = Number(current.total || 20);
        setTotalQuestions(total);
        setUserAnswers(Array(total).fill(null));

        setSnapshots({
          0: {
            question: current.question,
            selectedOptionId: null,
            selectedIndex: null,
            status: 'unanswered',
          },
        });

        setCurrentQuestionIndex(0);
        setCurrentServerIndex(Number(current.index || 1));
        setLoading(false);
      } catch {
        setError('Imtihonni yuklashda kutilmagan xatolik.');
        setLoading(false);
      }
    })();
  }, [testIdParam, requestedMode]);

  // Timer (exam only)
  useEffect(() => {
    if (loading || testFinished) return;
    if (requestedMode !== 'exam') return;

    timerRef.current = setInterval(() => {
      setTimeRemaining((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          if (timerRef.current) clearInterval(timerRef.current);
          finishTest();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [loading, testFinished, requestedMode]);

  function getQuestionStatus(i: number): 'active' | 'answered' | '' {
    if (i === currentQuestionIndex) return 'active';
    const snap = snapshots[i];
    if (!snap || snap.status === 'unanswered') return '';
    return 'answered';
  }

  async function selectAnswer(index: number) {
    if (testFinished) return;

    const snap = snapshots[currentQuestionIndex];
    if (!snap || snap.status !== 'unanswered') return;

    const option = snap.question.options[index];
    if (!option) return;

    const res = await postJSON(
      `/attempts/${attemptId}/answer`,
      { question_id: snap.question.id, option_id: option.id },
    );

    if (res?.error) {
      setError(res.error.message || 'Javob yuborishda xatolik.');
      return;
    }

    setSnapshots((prev) => ({
      ...prev,
      [currentQuestionIndex]: {
        ...prev[currentQuestionIndex],
        selectedOptionId: option.id,
        selectedIndex: index,
        status: 'answered',
      },
    }));

    setUserAnswers((prev) => {
      const next = [...prev];
      next[currentQuestionIndex] = index;
      return next;
    });

    setCorrectAnswers(Number(res.correct_total || 0));
    setWrongAnswers(Number(res.wrong_total || 0));

    // ✅ next savolni answer response'dan cache qilish
    const next = (res as any)?.next;
    if (next?.question?.id && next?.index) {
      const nextUiIndex = Number(next.index) - 1;
      setSnapshots((prev) => ({
        ...prev,
        [nextUiIndex]: {
          question: next.question,
          selectedOptionId: null,
          selectedIndex: null,
          status: 'unanswered',
        },
      }));
    }

    // exam rule: 3-xato bo'lsa to'xtatish
    if (requestedMode === 'exam' && Number(res.wrong_total || 0) >= 3) {
      setModalIcon('❌');
      setModalTitle("Imtihon to'xtatildi!");
      setModalSubtitle('3 ta xato qilindi. Imtihon yakunlandi.');
      setModalFailClass(true);
      setModalActive(true);
      finishTest();
      return;
    }
  }

  function previousQuestion() {
    if (currentQuestionIndex > 0) setCurrentQuestionIndex((v) => v - 1);
  }

  // ✅ nextQuestion — ishonchli va race-condition-free
  async function nextQuestion() {
    if (testFinished) return;

    const nextIndex = currentQuestionIndex + 1;

    if (nextIndex >= totalQuestions) {
      await finishTest();
      return;
    }

    // agar allaqachon cache bo'lsa — instant
    if (snapshots[nextIndex]) {
      setCurrentQuestionIndex(nextIndex);
      return;
    }

    // javob berilmagan bo'lsa — o'tkazmaymiz
    if (!questionAnswered) return;

    // parallel click / race ni to'xtatamiz
    if (loadingNext) return;
    setLoadingNext(true);
    const reqId = ++nextReqIdRef.current;

    try {
      const cur = await getJSON(`/attempts/${attemptId}/current`);
      if (reqId !== nextReqIdRef.current) return;

      if (cur?.error) {
        if (
          cur.error.code === 'ATTEMPT_COMPLETE' ||
          cur.error.code === 'ATTEMPT_NOT_ACTIVE' ||
          cur.error.code === 'TIME_EXPIRED'
        ) {
          await finishTest();
        } else {
          setError(cur.error.message || "Keyingi savolni yuklab bo'lmadi.");
        }
        return;
      }

      const uiIndex = Math.max(Number(cur.index || 1) - 1, 0);

      setSnapshots((prev) => ({
        ...prev,
        [uiIndex]: {
          question: cur.question,
          selectedOptionId: null,
          selectedIndex: null,
          status: 'unanswered',
        },
      }));

      setCurrentQuestionIndex(uiIndex);
      setCurrentServerIndex(Number(cur.index || uiIndex + 1));
    } finally {
      setLoadingNext(false);
    }
  }

  function goToQuestion(index: number) {
    if (index < 0 || index >= totalQuestions) return;
    if (!snapshots[index]) return;
    setCurrentQuestionIndex(index);
  }

  async function finishTest() {
    if (testFinished) return;

    setTestFinished(true);
    if (timerRef.current) clearInterval(timerRef.current);

    const fin = await postJSON(`/attempts/${attemptId}/finish`, {});

    const correct = Number(fin?.correct_answers ?? 0);
    const answered = Number(fin?.answered_count ?? userAnswers.filter((v) => v !== null).length);
    const wrong = Math.max(answered - correct, 0);

    const percentage = Number(fin?.score_percent ?? Math.round((correct / Math.max(totalQuestions, 1)) * 100));
    const passed = Boolean(fin?.passed ?? percentage >= 70);

    setCorrectAnswers(correct);
    setWrongAnswers(wrong);

    if (passed) {
      setModalIcon('🎉');
      setModalTitle('Imtihon topshirildi!');
      setModalSubtitle("Tabriklaymiz! Siz imtihondan muvaffaqiyatli o'tdingiz.");
      setModalFailClass(false);
    } else {
      setModalIcon('😔');
      setModalTitle('Imtihon topshirilmadi');
      setModalSubtitle("Kamida 70% ball to'plash kerak edi.");
      setModalFailClass(true);
    }
    setModalActive(true);
  }

  function restartTest() {
    window.location.reload();
  }

  function confirmExit() {
    if (window.confirm("Imtihonni tark etmoqchimisiz? Barcha natijalar yo'qoladi.")) {
      window.location.href = '/app';
    }
  }

  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (!testFinished) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [testFinished]);

  const letters = ['A', 'B', 'C', 'D'];

  if (loading) return <main className={styles.loading}>Imtihon yuklanmoqda...</main>;

  if (!currentQuestion && error) {
    return (
      <main className={styles.loading}>
        <div style={{ maxWidth: 520 }}>
          <div style={{ fontSize: 18, marginBottom: 8 }}>Xatolik</div>
          <div style={{ marginBottom: 16 }}>{error}</div>
          <Link href="/app">← Bosh sahifa</Link>
        </div>
      </main>
    );
  }

  const hasImage = Boolean(currentQuestion?.image_url);

  return (
    <>
      <nav className={styles.navbar}>
        <div className={styles.navContainer}>
          <Link href="/app" className={styles.logo}>
            <div className={styles.logoIcon}>🎯</div>
            AUTO TESTLAR
          </Link>

          <div className={styles.navActions}>
            <div className={`${styles.timer} ${timeRemaining <= 300 ? styles.timerWarning : ''}`}>
              <span>⏱️</span>
              <span>{timeDisplay}</span>
            </div>
            <button className={`${styles.btn} ${styles.btnIcon}`} onClick={confirmExit} aria-label="Exit">
              ✕
            </button>
          </div>
        </div>
      </nav>

      <div className={styles.mainContainer}>
        <div className={styles.examBanner}>
          <div className={styles.examBannerIcon}>🛡️</div>
          <div className={styles.examBannerContent}>
            <h3>{requestedMode === 'practice' ? 'Mashq Rejimi' : 'Imtihon Rejimi'}</h3>
            <p>
              {requestedMode === 'practice'
                ? 'Mashq rejimi: javoblarni mashq qilish uchun.'
                : "Haqiqiy imtihon kabi. 2 ta xatogacha ruxsat, 3-xatoda test to'xtatiladi."}
            </p>
          </div>
        </div>

        <div className={styles.progressSection}>
          <div className={styles.progressHeader}>
            <div className={styles.progressInfo}>
              Savol <span>{currentQuestionIndex + 1}</span> / {totalQuestions}
            </div>
            <div className={styles.progressStats}>
              <span className={styles.statAnswered}>✓ {answeredCount}</span>
              <span className={styles.statUnanswered}>○ {unansweredCount}</span>
            </div>
          </div>

          <div className={styles.progressBar}>
            <div
              className={styles.progressFill}
              style={{ width: `${Math.round(((currentQuestionIndex + 1) / totalQuestions) * 100)}%` }}
            />
          </div>

          <div className={styles.questionDots}>
            {Array.from({ length: totalQuestions }).map((_, i) => (
              <div
                key={i}
                className={`${styles.questionDot} ${
                  getQuestionStatus(i) === 'active'
                    ? styles.dotActive
                    : getQuestionStatus(i) === 'answered'
                      ? styles.dotAnswered
                      : ''
                }`}
                onClick={() => goToQuestion(i)}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>

        <div className={styles.questionCard}>
          <div className={styles.questionHeader}>
            <div className={styles.questionNumber}>Savol {currentQuestionIndex + 1}</div>
            <div className={styles.questionCategory}>Yo'l harakati qoidalari</div>
          </div>

          {/* ✅ LAYOUT: rasm chap (katta), variantlar o'ng. Rasm yo'q bo'lsa — to'liq kenglik */}
          <div className={`${styles.questionContent} ${!hasImage ? styles.questionContentNoImage : ''}`}>

            {/* Rasm — chap tomonda (order: 1) */}
            {hasImage && (
              <div className={styles.questionImageContainer}>
                <img
                  src={currentQuestion!.image_url!}
                  alt="Savol rasmi"
                  className={styles.questionImage}
                  loading="eager"
                  fetchPriority="high"
                />
              </div>
            )}

            {/* Savol matni + variantlar — o'ng tomonda (order: 2) */}
            <div className={styles.questionLeft}>
              <div className={styles.questionText}>
                {currentQuestion?.text || error || 'Savol topilmadi.'}
              </div>

              <div className={styles.answerOptions}>
                {currentQuestion?.options?.map((o, idx) => {
                  const snap = snapshots[currentQuestionIndex];
                  const selected = snap?.selectedIndex === idx;
                  const disabled = Boolean(snap && snap.status !== 'unanswered');

                  return (
                    <div
                      key={o.id}
                      className={`${styles.answerOption} ${selected ? styles.selected : ''} ${
                        disabled ? styles.disabled : ''
                      }`}
                      onClick={() => !disabled && selectAnswer(idx)}
                    >
                      <div className={styles.optionLetter}>{letters[idx] || String(idx + 1)}</div>
                      <div className={styles.optionText}>{o.text}</div>
                      <div className={styles.optionIcon}>{selected ? '•' : ''}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className={styles.questionNav}>
          <button
            className={`${styles.btn} ${styles.btnSecondary}`}
            onClick={previousQuestion}
            disabled={currentQuestionIndex === 0}
          >
            ← Oldingi
          </button>

          <button
            className={`${styles.btn} ${styles.btnPrimary}`}
            onClick={nextQuestion}
            disabled={loadingNext || (!questionAnswered && currentQuestionIndex < totalQuestions - 1)}
          >
            {loadingNext
              ? 'Yuklanmoqda...'
              : currentQuestionIndex >= totalQuestions - 1
                ? 'Yakunlash'
                : 'Keyingi →'}
          </button>
        </div>
      </div>

      <div className={`${styles.modal} ${modalActive ? styles.modalActive : ''}`}>
        <div className={styles.modalContent}>
          <div className={styles.modalIcon}>{modalIcon}</div>
          <div className={styles.modalTitle}>{modalTitle}</div>
          <div className={styles.modalSubtitle}>{modalSubtitle}</div>
          <div className={`${styles.modalScore} ${modalFailClass ? styles.modalScoreFail : ''}`}>
            {correctAnswers}/{totalQuestions}
          </div>

          <div className={styles.modalStats}>
            <div className={styles.modalStat}>
              <div className={styles.modalStatValueSuccess}>{correctAnswers}</div>
              <div className={styles.modalStatLabel}>To'g'ri</div>
            </div>
            <div className={styles.modalStat}>
              <div className={styles.modalStatValueDanger}>{wrongAnswers}</div>
              <div className={styles.modalStatLabel}>Xato</div>
            </div>
            <div className={styles.modalStat}>
              <div className={styles.modalStatValueInfo}>
                {Math.round((correctAnswers / Math.max(totalQuestions, 1)) * 100)}%
              </div>
              <div className={styles.modalStatLabel}>Natija</div>
            </div>
          </div>

          <div className={styles.modalActions}>
            <button className={`${styles.btn} ${styles.btnSecondary}`} onClick={() => (window.location.href = '/app')}>
              Bosh sahifa
            </button>
            <button className={`${styles.btn} ${styles.btnPrimary}`} onClick={restartTest}>
              Qayta urinish
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

