import Link from 'next/link';

export default function VerifySuccess(){
  return (
    <main>
      <h1>Email tasdiqlandi ✅</h1>
      <p>Endi akkauntingizga kirishingiz mumkin.</p>
      <p><Link href='/login'>Login</Link></p>
      <p><Link href='/app'>Dashboard</Link></p>
    </main>
  );
}
