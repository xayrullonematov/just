"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { csrf, getJSON, postJSON, readCookie } from "../../lib/api";
import styles from "./tickets.module.css";

type TicketStatus = "new" | "in_progress" | "completed";

function mapTicketStatus(lastAttemptStatus: string | null | undefined): TicketStatus {
  if (!lastAttemptStatus) return "new";
  if (lastAttemptStatus === "in_progress") return "in_progress";
  return "completed";
}

function mapTicketProgress(status: TicketStatus, answeredCount: number, questionCount: number): number {
  if (status === "new") return 0;
  if (status === "completed") return 100;
  const total = Math.max(questionCount, 1);
  const normalised = Math.max(0, Math.min(answeredCount, total));
  return Math.round((normalised / total) * 100);
}

function mapTicketScore(status: TicketStatus, scorePercent: number | null): number | null {
  if (status !== "completed" || scorePercent == null) return null;
  return Math.round(scorePercent / 10);
}

type TicketVM = {
  id: string;
  number: number;
  title: string;
  question_count: number;
  status: TicketStatus;
  progress: number;
  score: number | null;
  lastAttemptId: string | null;
};

export default function TicketsList() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [tickets, setTickets] = useState<TicketVM[]>([]);
  const [filter, setFilter] = useState<"all" | TicketStatus>("all");

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError("");
        await csrf();

        const res = await getJSON("/tests?type=ticket&include_progress=1");
        if (res?.error) {
          setError(res.error.message || "Biletlarni yuklab bo'lmadi.");
          setLoading(false);
          return;
        }

        const items: any[] = Array.isArray(res) ? res : res.items ?? [];
        const list: TicketVM[] = items.map((t: any, idx: number) => {
          const status = mapTicketStatus(t.last_attempt_status);
          const progress = mapTicketProgress(status, Number(t.last_answered_count || 0), Number(t.question_count || 10));
          const score = mapTicketScore(status, t.last_score_percent == null ? null : Number(t.last_score_percent));

          return {
            id: String(t.id),
            number: idx + 1,
            title: t.title || `Bilet ${idx + 1}`,
            question_count: Number(t.question_count || 10),
            status,
            progress,
            score,
            lastAttemptId: t.last_attempt_id || null,
          };
        });

        setTickets(list);
        setLoading(false);
      } catch {
        setError("Biletlarni yuklashda kutilmagan xatolik.");
        setLoading(false);
      }
    })();
  }, []);

  const filteredTickets = useMemo(() => (filter === "all" ? tickets : tickets.filter((t) => t.status === filter)), [tickets, filter]);

  const completedCount = useMemo(() => tickets.filter((t) => t.status === "completed").length, [tickets]);
  const inProgressCount = useMemo(() => tickets.filter((t) => t.status === "in_progress").length, [tickets]);

  const avg = useMemo(() => {
    if (!tickets.length) return 0;
    const sum = tickets.reduce((acc, t) => acc + Number(t.score ?? 0), 0);
    return Math.round(sum / tickets.length);
  }, [tickets]);

  async function startTicket(bilet: TicketVM) {
    try {
      await csrf();
      const res = await postJSON("/attempts/start", { test_id: bilet.id, mode: "ticket" });
      if (res?.error) {
        setError(res.error.message || "Boshlashda xatolik.");
        return;
      }
      router.push(`/tickets?ticketId=${bilet.id}`);
    } catch {
      setError("Boshlashda kutilmagan xatolik.");
    }
  }

  async function continueTicket(bilet: TicketVM) {
    if (!bilet.lastAttemptId) return startTicket(bilet);
    try {
      const cur = await getJSON(`/attempts/${bilet.lastAttemptId}/current`);
      if (cur?.error) {
        setError(cur.error.message || "Davom ettirishda xatolik.");
        return;
      }
      router.push(`/tickets?ticketId=${bilet.id}`);
    } catch {
      setError("Davom ettirishda kutilmagan xatolik.");
    }
  }

  function reviewTicket(bilet: TicketVM) {
    if (!bilet.lastAttemptId) {
      setError("Ko‘rib chiqish uchun urinish topilmadi.");
      return;
    }
    router.push(`/review/${bilet.lastAttemptId}`);
  }

  async function retakeTicket(bilet: TicketVM) {
    if (!window.confirm("Biletni qayta topshirishni xohlaysizmi? Oldingi natija o'chiriladi.")) return;
    await startTicket(bilet);
  }

  if (loading) return <main className={styles.loading}>Biletlar yuklanmoqda...</main>;
  if (error) return <main className={styles.loading}>Xatolik: {error}</main>;

  return (
    <main className={styles.page}>
      <header className={styles.header}>
        <Link href="/app" className={styles.brand}>
          <span className={styles.brandIcon}>🎯</span>
          <span className={styles.brandText}>AUTO TESTLAR</span>
        </Link>
        <div className={styles.headerRight}>
          <div className={styles.pill}>
            <span className={styles.pillDot} />
            <div>
              <div className={styles.pillTitle}>Bilet rejimi</div>
              <div className={styles.pillSub}>Timer yo‘q · Izoh bor</div>
            </div>
          </div>
        </div>
      </header>

      <section className={styles.hero}>
        <h1 className={styles.h1}>Biletlar</h1>
        <p className={styles.p}>Har bir bilet 10 ta savoldan iborat. Barcha biletlarni tugatish orqali imtihonga tayyorlaning.</p>

        <div className={styles.statsRow}>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>✅</div>
            <div>
              <div className={styles.statValue}>{completedCount}/{tickets.length}</div>
              <div className={styles.statLabel}>Tugatlangan</div>
            </div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>⏳</div>
            <div>
              <div className={styles.statValue}>{inProgressCount}</div>
              <div className={styles.statLabel}>Jarayonda</div>
            </div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>📊</div>
            <div>
              <div className={styles.statValue}>{avg}%</div>
              <div className={styles.statLabel}>O‘rtacha ball</div>
            </div>
          </div>
        </div>

        <div className={styles.filters}>
          <button className={`${styles.filterBtn} ${filter === "all" ? styles.filterActive : ""}`} onClick={() => setFilter("all")}>Barchasi</button>
          <button className={`${styles.filterBtn} ${filter === "new" ? styles.filterActive : ""}`} onClick={() => setFilter("new")}>Yangi</button>
          <button className={`${styles.filterBtn} ${filter === "in_progress" ? styles.filterActive : ""}`} onClick={() => setFilter("in_progress")}>Jarayonda</button>
          <button className={`${styles.filterBtn} ${filter === "completed" ? styles.filterActive : ""}`} onClick={() => setFilter("completed")}>Tugatilgan</button>
        </div>

        <div className={styles.countRow}>{filteredTickets.length} ta bilet topildi.</div>
      </section>

      <section className={styles.grid}>
        {filteredTickets.map((bilet) => {
          const status = bilet.status;
          const badgeLabel = status === "completed" ? "Tugatilgan" : status === "in_progress" ? "Jarayonda" : "Yangi";

          return (
            <div key={bilet.id} className={styles.ticketCard}>
              <div className={styles.ticketTop}>
                <div className={styles.ticketNum}>{bilet.number}</div>
                <div className={styles.ticketBadge}>{badgeLabel}</div>
              </div>

              <div className={styles.ticketTitle}>{bilet.title}</div>

              <div className={styles.ticketMeta}>
                <span>🧾 {bilet.question_count} savol</span>
                <span>📘 Izoh</span>
              </div>

              <div className={styles.ticketActions}>
                {status === "completed" ? (
                  <>
                    <button className={styles.btnSecondary} onClick={() => reviewTicket(bilet)}>Ko‘rib chiqish</button>
                    <button className={styles.btnPrimary} onClick={() => retakeTicket(bilet)}>Qayta topshirish</button>
                  </>
                ) : status === "in_progress" ? (
                  <button className={styles.btnPrimary} onClick={() => continueTicket(bilet)}>Davom ettirish →</button>
                ) : (
                  <button className={styles.btnPrimary} onClick={() => startTicket(bilet)}>Boshlash ▶</button>
                )}
              </div>
            </div>
          );
        })}
      </section>
    </main>
  );
}
