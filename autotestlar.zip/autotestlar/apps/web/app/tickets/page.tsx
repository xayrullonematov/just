import { Suspense } from "react";
import TicketsShell from "./tickets-shell";

export default function TicketsPage() {
  return (
    <Suspense fallback={<div>Yuklanmoqda...</div>}>
      <TicketsShell />
    </Suspense>
  );
}
