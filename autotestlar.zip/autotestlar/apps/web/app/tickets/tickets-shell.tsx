"use client";

import { useSearchParams } from "next/navigation";
import TicketsList from "./tickets-list";
import TicketTestClient from "./ticket-test-client";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export default function TicketsShell() {
  const searchParams = useSearchParams();
  const rawTicketId = (searchParams.get("ticketId") || "").trim();

  if (UUID_RE.test(rawTicketId)) {
    return <TicketTestClient ticketId={rawTicketId} />;
  }

  return <TicketsList />;
}
