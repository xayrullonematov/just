"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { csrf, getJSON, postJSON, readCookie } from "../../lib/api";
import styles from "./ticket-test.module.css";

/* =======================
   Types
======================= */
type OptionVM = { id: string; text: string };

type QuestionVM = {
  id: string;
  text: string;
  image_url: string | null;
  options: OptionVM[];
};

type Snapshot = {
  question: QuestionVM;
  selectedOptionId: string | null;
  status: "unanswered" | "answered";
  isCorrect: boolean | null;
  correctOptionId: string | null;
  explanation: string | null;
};

const LETTERS = ["A", "B", "C", "D"];

/* =======================
   Component
======================= */
export default function TicketTestClient({ ticketId }: { ticketId: string }) {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [attemptId, setAttemptId] = useState("");
  const [total, setTotal] = useState(10);
  const [uiIndex, setUiIndex] = useState(0);
  const [snapshots, setSnapshots] = useState<Record<number, Snapshot>>({});

  const [loadingNext, setLoadingNext] = useState(false);
  const nextReqIdRef = useRef(0);

  const snap = snapshots[uiIndex];
  const current = snap?.question ?? null;
  const answered = snap?.status === "answered";

  const answeredCount = useMemo(
    () => Object.values(snapshots).filter((s) => s.status === "answered").length,
    [snapshots]
  );

  const correctCount = useMemo(
    () => Object.values(snapshots).filter((s) => s.isCorrect).length,
    [snapshots]
  );

  /* =======================
     Init ticket attempt
  ======================= */
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError("");

        await csrf();

        // 1️⃣ load test
        const test = await getJSON(`/tests/${ticketId}`);
        if (test?.error) {
          setError(test.error.message || "Bilet topilmadi.");
          setLoading(false);
          return;
        }

        // 2️⃣ start attempt (ticket mode)
        const start = await postJSON(
          "/attempts/start",
          { test_id: test.id, mode: "ticket" },
        );

        if (start?.error) {
          setError(start.error.message || "Biletni boshlashda xatolik.");
          setLoading(false);
          return;
        }

        setAttemptId(start.attempt_id);

        // 3️⃣ load first question
        const cur = await getJSON(`/attempts/${start.attempt_id}/current`);
        if (cur?.error) {
          setError(cur.error.message || "Savolni yuklab bo‘lmadi.");
          setLoading(false);
          return;
        }

        setTotal(Number(cur.total || test.question_count || 10));
        setSnapshots({
          0: {
            question: cur.question,
            selectedOptionId: null,
            status: "unanswered",
            isCorrect: null,
            correctOptionId: null,
            explanation: null,
          },
        });
        setUiIndex(0);
        setLoading(false);
      } catch {
        setError("Biletni yuklashda kutilmagan xatolik.");
        setLoading(false);
      }
    })();
  }, [ticketId]);

  /* =======================
     Answer
  ======================= */
  async function selectAnswer(optIndex: number) {
    if (!attemptId || !current || answered) return;

    const option = current.options[optIndex];
    if (!option) return;

    const res: any = await postJSON(
      `/attempts/${attemptId}/answer`,
      { question_id: current.id, option_id: option.id },
    );

    if (res?.error) {
      setError(res.error.message || "Javob yuborishda xatolik.");
      return;
    }

    const isCorrect = Boolean(res.is_correct);
    const correctOptionId = res.correct_option_id ?? null;
    const explanation = res.explanation ?? null;

    setSnapshots((prev) => ({
      ...prev,
      [uiIndex]: {
        question: current,
        selectedOptionId: option.id,
        status: "answered",
        isCorrect,
        correctOptionId,
        explanation,
      },
    }));

    // pre-cache next question
    if (res?.next?.question && res?.next?.index) {
      const nextUi = Number(res.next.index) - 1;
      setSnapshots((prev) => ({
        ...prev,
        [nextUi]: {
          question: res.next.question,
          selectedOptionId: null,
          status: "unanswered",
          isCorrect: null,
          correctOptionId: null,
          explanation: null,
        },
      }));
    }
  }

  /* =======================
     Navigation
  ======================= */
  async function nextQuestion() {
    if (!attemptId) return;

    const next = uiIndex + 1;

    if (next >= total) {
      await postJSON(`/attempts/${attemptId}/finish`, {});
      router.push("/tickets");
      return;
    }

    if (snapshots[next]) {
      setUiIndex(next);
      return;
    }

    if (!answered || loadingNext) return;

    setLoadingNext(true);
    const reqId = ++nextReqIdRef.current;

    try {
      const cur: any = await getJSON(`/attempts/${attemptId}/current`);
      if (reqId !== nextReqIdRef.current) return;

      if (cur?.error) {
        setError(cur.error.message || "Keyingi savolni yuklab bo‘lmadi.");
        return;
      }

      const idx = Math.max(Number(cur.index || 1) - 1, 0);
      setSnapshots((prev) => ({
        ...prev,
        [idx]: {
          question: cur.question,
          selectedOptionId: null,
          status: "unanswered",
          isCorrect: null,
          correctOptionId: null,
          explanation: null,
        },
      }));
      setUiIndex(idx);
    } finally {
      setLoadingNext(false);
    }
  }

  function prevQuestion() {
    if (uiIndex > 0) setUiIndex((v) => v - 1);
  }

  /* =======================
     Render
  ======================= */
  if (loading) {
    return <main className={styles.loading}>Bilet yuklanmoqda...</main>;
  }

  if (!current && error) {
    return (
      <main className={styles.loading}>
        <div>
          <div>Xatolik</div>
          <div>{error}</div>
          <Link href="/tickets">← Biletlar</Link>
        </div>
      </main>
    );
  }

  return (
    <>
      <header className={styles.header}>
        <Link href="/tickets" className={styles.brand}>🎯 AUTO TESTLAR</Link>
        <div className={styles.score}>
          ✅ {correctCount}/{answeredCount}
        </div>
      </header>

      <main className={styles.wrap}>
        <h1 className={styles.h1}>
          Bilet · Savol {uiIndex + 1}/{total}
        </h1>

        <div className={styles.card}>
          {current.image_url && (
            <img src={current.image_url} alt="Savol rasmi" className={styles.image} />
          )}

          <div className={styles.question}>{current.text}</div>

          <div className={styles.answers}>
            {current.options.map((o, i) => {
              const selected = snap?.selectedOptionId === o.id;
              const correct = answered && snap?.correctOptionId === o.id;
              const wrong = answered && selected && !correct;

              return (
                <button
                  key={o.id}
                  disabled={answered}
                  onClick={() => selectAnswer(i)}
                  className={`${styles.option} ${
                    selected ? styles.selected : ""
                  } ${correct ? styles.correct : ""} ${wrong ? styles.wrong : ""}`}
                >
                  <span className={styles.letter}>{LETTERS[i]}</span>
                  {o.text}
                </button>
              );
            })}
          </div>

          {answered && (
            <div className={styles.explanation}>
              <div className={snap?.isCorrect ? styles.ok : styles.bad}>
                {snap?.isCorrect ? "✅ To‘g‘ri" : "❌ Xato"}
              </div>
              <div>{snap?.explanation || "Izoh mavjud emas."}</div>
            </div>
          )}

          <div className={styles.nav}>
            <button onClick={prevQuestion} disabled={uiIndex === 0}>
              ← Oldingi
            </button>
            <button onClick={nextQuestion}>
              {uiIndex + 1 >= total ? "Yakunlash" : "Keyingi →"}
            </button>
          </div>
        </div>
      </main>
    </>
  );
}
