'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { csrf, getJSON, postJSON, readCookie } from '../../lib/api';
import styles from './page.module.css';

type OptionVM = { id: string; text: string };
type QuestionVM = { id: string; text: string; image_url: string | null; options: OptionVM[] };

type Snapshot = {
  question: QuestionVM;
  selectedIndex: number | null;
  selectedOptionId: string | null;
};

const LETTERS = ['A', 'B', 'C', 'D'];

export default function DailyPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [attemptId, setAttemptId] = useState('');
  const [totalQuestions, setTotalQuestions] = useState(10);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentServerIndex, setCurrentServerIndex] = useState(1);
  const [testFinished, setTestFinished] = useState(false);

  const [snapshots, setSnapshots] = useState<Record<number, Snapshot>>({});
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(Array(10).fill(null));

  const [timeRemaining, setTimeRemaining] = useState(600);
  const [modalActive, setModalActive] = useState(false);
  const [resultIcon, setResultIcon] = useState('🎉');
  const [resultTitle, setResultTitle] = useState('Yaxshi natija!');
  const [modalCorrect, setModalCorrect] = useState(0);
  const [modalWrong, setModalWrong] = useState(0);
  const [modalPercentage, setModalPercentage] = useState(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const unansweredCount = useMemo(() => userAnswers.filter((a) => a === null).length, [userAnswers]);
  const currentQuestion = snapshots[currentQuestionIndex]?.question ?? null;

  // ── Init ──
  useEffect(() => {
    (async () => {
      try {
        await csrf();
        const start = await postJSON('/daily/start', {});
        if (start?.error) {
          setError(start.error.message || 'Kunlik testni boshlashda xatolik.');
          setLoading(false);
          return;
        }

        setAttemptId(start.attempt_id);

        const current = await getJSON(`/attempts/${start.attempt_id}/current`);
        if (current?.error) {
          setError(current.error.message || 'Savolni yuklashda xatolik.');
          setLoading(false);
          return;
        }

        const total = Number(current.total || 10);
        setTotalQuestions(total);
        setUserAnswers(Array(total).fill(null));
        setSnapshots({ 0: { question: current.question, selectedIndex: null, selectedOptionId: null } });
        setCurrentQuestionIndex(0);
        setCurrentServerIndex(Number(current.index || 1));

        if (start.expires_at) {
          const left = Math.max(Math.floor((new Date(start.expires_at).getTime() - Date.now()) / 1000), 0);
          setTimeRemaining(left);
        }

        setLoading(false);
      } catch {
        setError("Kunlik test yuklanmadi. Qaytadan urinib ko'ring.");
        setLoading(false);
      }
    })();
  }, []);

  // ── Timer ──
  useEffect(() => {
    if (loading || testFinished) return;
    timerRef.current = setInterval(() => {
      setTimeRemaining((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          clearInterval(timerRef.current!);
          finishTest(true);
          return 0;
        }
        return next;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [loading, testFinished]);

  // ── Warn on leave ──
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!testFinished) { e.preventDefault(); e.returnValue = ''; }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [testFinished]);

  const timeDisplay = useMemo(() => {
    const m = Math.floor(timeRemaining / 60);
    const s = timeRemaining % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }, [timeRemaining]);

  // ── Result modal ──
  function updateResultModal(correct: number, wrong: number) {
    const pct = Math.round((correct / Math.max(totalQuestions, 1)) * 100);
    setModalCorrect(correct);
    setModalWrong(wrong);
    setModalPercentage(pct);

    if (pct >= 90)      { setResultIcon('🏆'); setResultTitle('Ajoyib natija!'); }
    else if (pct >= 70) { setResultIcon('🎉'); setResultTitle('Yaxshi natija!'); }
    else if (pct >= 50) { setResultIcon('👍'); setResultTitle('Yaxshi harakat!'); }
    else                { setResultIcon('📚'); setResultTitle("Ko'proq mashq qiling"); }
  }

  // ── Answer ──
  async function selectAnswer(index: number) {
    if (loading || testFinished || !currentQuestion || !attemptId) return;
    if (userAnswers[currentQuestionIndex] !== null) return;

    const option = currentQuestion.options[index];
    if (!option) return;

    const res = await postJSON(
      `/attempts/${attemptId}/answer`,
      { question_id: currentQuestion.id, option_id: option.id },
    );
    if (res?.error) { setError(res.error.message || 'Javob yuborishda xatolik.'); return; }

    setSnapshots((prev) => ({
      ...prev,
      [currentQuestionIndex]: { ...prev[currentQuestionIndex], selectedIndex: index, selectedOptionId: option.id },
    }));
    setUserAnswers((prev) => { const n = [...prev]; n[currentQuestionIndex] = index; return n; });
  }

  // ── Navigation helpers ──
  async function ensureQuestionLoaded(index: number): Promise<boolean> {
    if (snapshots[index]) return true;
    if (index + 1 !== currentServerIndex) return false;

    const current = await getJSON(`/attempts/${attemptId}/current`);
    if (current?.error) {
      const fatal = ['ATTEMPT_COMPLETE', 'ATTEMPT_NOT_ACTIVE', 'TIME_EXPIRED'];
      if (fatal.includes(current.error.code)) await finishTest(true);
      else setError(current.error.message || 'Savolni yuklab bo\'lmadi.');
      return false;
    }

    setSnapshots((prev) => ({
      ...prev,
      [index]: { question: current.question, selectedIndex: null, selectedOptionId: null },
    }));
    setCurrentServerIndex(Number(current.index || currentServerIndex + 1));
    return true;
  }

  async function previousQuestion() {
    if (currentQuestionIndex > 0) setCurrentQuestionIndex((v) => v - 1);
  }

  async function nextQuestion() {
    if (currentQuestionIndex >= totalQuestions - 1) return;
    const next = currentQuestionIndex + 1;
    const ok = await ensureQuestionLoaded(next);
    if (ok || snapshots[next]) setCurrentQuestionIndex(next);
  }

  async function goToQuestion(index: number) {
    if (index < 0 || index >= totalQuestions) return;
    if (snapshots[index]) { setCurrentQuestionIndex(index); return; }
    const ok = await ensureQuestionLoaded(index);
    if (ok) setCurrentQuestionIndex(index);
  }

  // ── Finish ──
  async function finishTest(skipConfirm = false) {
    if (testFinished || !attemptId) return;

    if (!skipConfirm) {
      const unanswered = userAnswers.filter((a) => a === null).length;
      if (unanswered > 0) {
        const ok = window.confirm(`${unanswered} ta savolga javob bermadingiz. Testni yakunlashni xohlaysizmi?`);
        if (!ok) return;
      }
    }

    setTestFinished(true);
    if (timerRef.current) clearInterval(timerRef.current);

    const fin = await postJSON(`/attempts/${attemptId}/finish`, {});
    if (fin?.error) setError(fin.error.message || 'Testni yakunlashda xatolik.');

    const review = await getJSON(`/attempts/${attemptId}/review`);
    if (review?.error) { setError(review.error.message || 'Natijani yuklashda xatolik.'); return; }

    let correct = 0, wrong = 0;
    (review.items || []).forEach((it: any) => {
      if (it.chosen_option_id) {
        if (it.chosen_option_id === it.correct_option_id) correct++;
        else wrong++;
      }
    });

    updateResultModal(correct, wrong);
    setModalActive(true);
  }

  function confirmExit() {
    if (window.confirm("Testni tark etmoqchimisiz? Barcha natijalar yo'qoladi.")) {
      window.location.href = '/app';
    }
  }

  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;

  return (
    <>
      {/* ── Navbar ── */}
      <nav className={styles.navbar}>
        <div className={styles.navContainer}>
          <Link href="/app" className={styles.logo}>
            <div className={styles.logoIcon}>🚗</div>
            <span>AUTO TEST</span>
          </Link>
          <div className={styles.navActions}>
            <div className={`${styles.timer} ${timeRemaining <= 180 ? styles.timerWarning : ''}`}>
              <span>⏱️</span>
              <span>{timeDisplay}</span>
            </div>
            <button className={styles.btnIcon} onClick={confirmExit} title="Chiqish">✕</button>
          </div>
        </div>
      </nav>

      {/* ── Main ── */}
      <div className={styles.mainContainer}>

        {/* Progress */}
        <div className={styles.progressSection}>
          <div className={styles.progressHeader}>
            <div className={styles.progressInfo}>
              Savol <strong>{currentQuestionIndex + 1}</strong> / {totalQuestions}
            </div>
            <div className={styles.progressStats}>
              <span className={styles.statUnanswered}>{unansweredCount} javobsiz</span>
            </div>
          </div>
          <div className={styles.progressBar}>
            <div
              className={styles.progressFill}
              style={{ width: `${Math.round(((currentQuestionIndex + 1) / totalQuestions) * 100)}%` }}
            />
          </div>
          <div className={styles.questionDots}>
            {Array.from({ length: totalQuestions }).map((_, i) => (
              <div
                key={i}
                className={[
                  styles.questionDot,
                  i === currentQuestionIndex ? styles.questionDotActive : '',
                  userAnswers[i] !== null && i !== currentQuestionIndex ? styles.questionDotAnswered : '',
                ].join(' ')}
                onClick={() => goToQuestion(i)}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>

        {/* Question card */}
        <div className={styles.questionCard}>
          <div className={styles.questionHeader}>
            <div className={styles.questionNumberBadge}>
              <div className={styles.questionNum}>Savol {currentQuestionIndex + 1}</div>
              <div className={styles.questionCategoryBadge}>Yo&apos;l harakati qoidalari</div>
            </div>
          </div>

          <div className={`${styles.questionContent} ${currentQuestion?.image_url ? styles.hasImage : ''}`}>
            <div className={styles.questionText}>
              {loading ? 'Yuklanmoqda...' : currentQuestion?.text || error || 'Savol topilmadi.'}
            </div>
            {currentQuestion?.image_url && (
              <div className={styles.questionImageWrapper}>
                <img src={currentQuestion.image_url} alt="Savol rasmi" className={styles.questionImage} />
                <div className={styles.imageLabel}>📷 Rasm</div>
              </div>
            )}
          </div>

          <div className={styles.answerOptions}>
            {currentQuestion?.options.map((option, index) => {
              const selected = userAnswers[currentQuestionIndex] === index;
              return (
                <div
                  key={option.id}
                  className={`${styles.answerOption} ${selected ? styles.answerOptionSelected : ''}`}
                  onClick={() => selectAnswer(index)}
                >
                  <div className={styles.optionLetter}>{LETTERS[index] ?? index + 1}</div>
                  <div className={styles.optionText}>{option.text}</div>
                  <div className={styles.optionIcon} />
                </div>
              );
            })}
          </div>

          <div className={styles.questionNav}>
            <button
              className={`${styles.btnNav} ${styles.btnPrevious}`}
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
            >
              ← Oldingi
            </button>

            {!isLastQuestion && (
              <button
                className={`${styles.btnNav} ${styles.btnNext}`}
                onClick={nextQuestion}
              >
                Keyingi →
              </button>
            )}

            {isLastQuestion && (
              <button
                className={`${styles.btnNav} ${styles.btnFinish}`}
                onClick={() => finishTest(false)}
              >
                ✓ Yakunlash
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Result Modal ── */}
      <div className={`${styles.modal} ${modalActive ? styles.modalActive : ''}`}>
        <div className={styles.modalContent}>
          <div className={styles.resultIcon}>{resultIcon}</div>
          <h2 className={styles.resultTitle}>{resultTitle}</h2>
          <div className={styles.resultScore}>{modalCorrect}/{totalQuestions}</div>

          <div className={styles.resultStats}>
            <div className={styles.resultStat}>
              <div className={`${styles.resultStatValue} ${styles.statCorrect}`}>{modalCorrect}</div>
              <div className={styles.resultStatLabel}>To&apos;g&apos;ri</div>
            </div>
            <div className={styles.resultStat}>
              <div className={`${styles.resultStatValue} ${styles.statWrong}`}>{modalWrong}</div>
              <div className={styles.resultStatLabel}>Xato</div>
            </div>
            <div className={styles.resultStat}>
              <div className={styles.resultStatValue}>{modalPercentage}%</div>
              <div className={styles.resultStatLabel}>Natija</div>
            </div>
          </div>

          <div className={styles.modalActions}>
            <button className={`${styles.btn} ${styles.btnOutline}`} onClick={() => (window.location.href = '/app')}>
              Bosh sahifa
            </button>
            <button className={`${styles.btn} ${styles.btnPrimary}`} onClick={() => window.location.reload()}>
              Qayta boshlash
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
