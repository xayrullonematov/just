'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { csrf, getJSON, postJSON } from '../../lib/api';
import styles from './mistakes.module.css';

type Mode = 'ticket' | 'exam' | 'daily' | string;

type MistakeAttemptItem = {
  test_id: string;
  title?: string | null;
  attempt_id: string;
  wrong_count?: number | null;
  last_wrong_at?: string | null;

  mode?: Mode | null;
  started_at?: string | null;
  finished_at?: string | null;
};

type OverallMistakeItem = {
  question_id: string;
  text?: string | null;
  explanation?: string | null;
  image_url?: string | null;

  bilet_number?: number | null;
  question_number?: number | null;

  wrong_times?: number | null;
  last_wrong_at?: string | null;
};

type ApiErr = { error?: { message?: string } } | null | undefined;

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function safeInt(v: unknown, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function badgeKind(wrong: number): 'ok' | 'mid' | 'hot' {
  if (wrong >= 6) return 'hot';
  if (wrong >= 2) return 'mid';
  return 'ok';
}

function badgeLabel(wrong: number): string {
  if (wrong >= 6) return "Ko‘p xato";
  if (wrong >= 2) return "O‘rtacha";
  return "Kam";
}

function modeLabel(mode?: Mode | null) {
  if (mode === 'ticket') return 'Bilet';
  if (mode === 'exam') return 'Imtihon';
  if (mode === 'daily') return 'Kunlik';
  return 'Test';
}

function formatTimeIso(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  // Uzbek-friendly but still readable
  return new Intl.DateTimeFormat('uz-UZ', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
}

function relativeTime(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Hozir';
  if (mins < 60) return `${mins} daqiqa oldin`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} soat oldin`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'Kecha';
  if (days < 7) return `${days} kun oldin`;
  return formatTimeIso(iso);
}

type SectionKey = 'ticket' | 'exam' | 'daily' | 'overall';

export default function MistakesPage() {
  const [attemptItems, setAttemptItems] = useState<MistakeAttemptItem[]>([]);
  const [overallItems, setOverallItems] = useState<OverallMistakeItem[]>([]);

  const [loading, setLoading] = useState(true);
  const [loadingOverall, setLoadingOverall] = useState(false);
  const [error, setError] = useState('');

  const [active, setActive] = useState<SectionKey>('ticket');
  const [query, setQuery] = useState('');

  const [overallPage, setOverallPage] = useState(1);
  const [overallTotal, setOverallTotal] = useState<number | null>(null);
  const overallHasMore = useMemo(() => {
    if (overallTotal == null) return true;
    return overallItems.length < overallTotal;
  }, [overallItems.length, overallTotal]);

  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  async function loadBase() {
    try {
      setLoading(true);
      setError('');
      const res = await getJSON('/me/mistakes');
      if ((res as ApiErr)?.error) {
        setError((res as any)?.error?.message || "Xatolarni yuklab bo‘lmadi.");
        setAttemptItems([]);
        setLoading(false);
        return;
      }
      setAttemptItems((res?.items || []) as MistakeAttemptItem[]);
      setLoading(false);
    } catch {
      setError('Kutilmagan xatolik yuz berdi.');
      setAttemptItems([]);
      setLoading(false);
    }
  }

  async function loadOverall(page: number, append: boolean) {
    try {
      setLoadingOverall(true);
      setError('');
      const res = await getJSON(`/me/mistakes/overall?page=${page}&page_size=50`);
      if ((res as ApiErr)?.error) {
        setError((res as any)?.error?.message || "Umumiy xatolarni yuklab bo‘lmadi.");
        if (!append) setOverallItems([]);
        setLoadingOverall(false);
        return;
      }
      const items = (res?.items || []) as OverallMistakeItem[];
      const total = safeInt(res?.total, 0);

      if (!mounted.current) return;

      setOverallTotal(total);
      setOverallItems((prev) => (append ? [...prev, ...items] : items));
      setLoadingOverall(false);
    } catch {
      if (!mounted.current) return;
      setError('Kutilmagan xatolik yuz berdi.');
      setLoadingOverall(false);
    }
  }

  useEffect(() => {
    (async () => {
      await loadBase();
      // We prefetch overall in background (still client-side)
      await loadOverall(1, false);
      setOverallPage(1);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const byMode = useMemo(() => {
    const ticket: MistakeAttemptItem[] = [];
    const exam: MistakeAttemptItem[] = [];
    const daily: MistakeAttemptItem[] = [];
    const other: MistakeAttemptItem[] = [];
    for (const it of attemptItems) {
      const m = (it.mode || 'ticket') as Mode;
      if (m === 'ticket') ticket.push(it);
      else if (m === 'exam') exam.push(it);
      else if (m === 'daily') daily.push(it);
      else other.push(it);
    }
    return { ticket, exam, daily, other };
  }, [attemptItems]);

  const totalWrongAttempts = useMemo(
    () => attemptItems.reduce((acc, it) => acc + safeInt(it.wrong_count, 0), 0),
    [attemptItems]
  );

  const totalOverall = overallTotal ?? overallItems.length;

  const statusText = useMemo(() => {
    const sessions = attemptItems.length;
    if (sessions === 0 && overallItems.length === 0) return 'Hozircha xatolar yo‘q ✅';
    if (totalWrongAttempts <= 3) return 'Zo‘r! Juda kam xato 👏';
    if (totalWrongAttempts <= 10) return 'Yaxshi. Ozgina mashq kerak 💪';
    return 'Mashqni kuchaytiramiz 🔥';
  }, [attemptItems.length, overallItems.length, totalWrongAttempts]);

  const filteredAttemptList = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list =
      active === 'ticket'
        ? byMode.ticket
        : active === 'exam'
          ? byMode.exam
          : active === 'daily'
            ? byMode.daily
            : [];

    if (!q) return list;
    return list.filter((it) => (it.title || '').toLowerCase().includes(q));
  }, [active, byMode.daily, byMode.exam, byMode.ticket, query]);

  const filteredOverall = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return overallItems;
    return overallItems.filter((it) => {
      const t = (it.text || '').toLowerCase();
      const b = it.bilet_number != null ? String(it.bilet_number) : '';
      return t.includes(q) || b.includes(q);
    });
  }, [overallItems, query]);

  async function hideAttempt(attempt_id: string) {
    const ok = confirm("Bu urinishni ro‘yxatdan olib tashlaysizmi? (Ma’lumotlar o‘chmaydi)");
    if (!ok) return;

    try {
      await csrf(); // ensure CSRF cookie/header is ready
      const res = await postJSON('/me/mistakes/hide-attempt', { attempt_id });
      if ((res as ApiErr)?.error) {
        alert((res as any)?.error?.message || "Urinishni yashirib bo‘lmadi.");
        return;
      }
      // Optimistic UI:
      setAttemptItems((prev) => prev.filter((x) => x.attempt_id !== attempt_id));
    } catch {
      alert('Kutilmagan xatolik yuz berdi.');
    }
  }

  async function resolveQuestion(question_id: string) {
    try {
      await csrf();
      const res = await postJSON('/me/mistakes/resolve', {
        question_id,
        source_attempt_id: null,
        note: null,
      });
      if ((res as ApiErr)?.error) {
        alert((res as any)?.error?.message || "Belgilab bo‘lmadi.");
        return;
      }
      setOverallItems((prev) => prev.filter((x) => x.question_id !== question_id));
      if (overallTotal != null) setOverallTotal(Math.max(0, overallTotal - 1));
    } catch {
      alert('Kutilmagan xatolik yuz berdi.');
    }
  }

  function SectionTabs() {
    const items = [
      { key: 'ticket' as const, label: 'Biletlar', count: byMode.ticket.length },
      { key: 'exam' as const, label: 'Imtihon', count: byMode.exam.length },
      { key: 'daily' as const, label: 'Kunlik', count: byMode.daily.length },
      { key: 'overall' as const, label: 'Umumiy', count: totalOverall },
    ];

    return (
      <div className={styles.tabs}>
        {items.map((t) => (
          <button
            key={t.key}
            type="button"
            className={`${styles.tab} ${active === t.key ? styles.tabActive : ''}`}
            onClick={() => setActive(t.key)}
          >
            <span className={styles.tabLabel}>{t.label}</span>
            <span className={styles.tabCount}>{t.count}</span>
          </button>
        ))}
      </div>
    );
  }

  const showingEmpty =
    (!loading && active !== 'overall' && filteredAttemptList.length === 0) ||
    (!loading && active === 'overall' && filteredOverall.length === 0);

  return (
    <main className={styles.page}>
      {/* Header */}
      <header className={styles.header}>
        <Link href="/app" className={styles.brand} aria-label="Dashboard">
          <span className={styles.brandIcon}>🎯</span>
          <span className={styles.brandText}>AUTO TESTLAR</span>
        </Link>

        <div className={styles.headerRight}>
          <div className={styles.pill}>
            <span className={styles.pillDot} />
            <div>
              <div className={styles.pillTitle}>Xatolarim</div>
              <div className={styles.pillSub}>Tahlil + Takrorlash</div>
            </div>
          </div>

          <Link href="/app" className={styles.iconBtn} aria-label="Close">
            ✕
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.heroTop}>
          <div>
            <h1 className={styles.h1}>Xatolarim</h1>
            <p className={styles.p}>
              Bilet/imtihon/kunlik urinishlaringiz va <b>umumiy</b> (takrorlangan savollar bir marta sanaladigan) xatolar.
              Xatoni ko‘rib chiqing, so‘ng “Bajarildi” deb belgilang.
            </p>
          </div>

          <div className={styles.searchWrap}>
            <input
              className={styles.search}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Qidirish: bilet, nom, savol..."
              aria-label="Search mistakes"
            />
            {query ? (
              <button className={styles.clearBtn} type="button" onClick={() => setQuery('')}>
                Tozalash
              </button>
            ) : null}
          </div>
        </div>

        <div className={styles.statsRow}>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>🧾</div>
            <div>
              <div className={styles.statValue}>{attemptItems.length}</div>
              <div className={styles.statLabel}>Urinishlar (jami)</div>
            </div>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statIcon}>❌</div>
            <div>
              <div className={styles.statValue}>{totalWrongAttempts}</div>
              <div className={styles.statLabel}>Jami xato (urinishlar)</div>
            </div>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statIcon}>📌</div>
            <div>
              <div className={styles.statValue}>{statusText}</div>
              <div className={styles.statLabel}>Holat</div>
            </div>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statIcon}>🧠</div>
            <div>
              <div className={styles.statValue}>{totalOverall}</div>
              <div className={styles.statLabel}>Umumiy xato (savollar)</div>
            </div>
          </div>
        </div>

        {error && <div className={styles.alert}>⚠️ {error}</div>}

        <SectionTabs />
      </section>

      {/* Content */}
      <section className={styles.grid}>
        {loading ? (
          <div className={styles.loading}>Yuklanmoqda...</div>
        ) : showingEmpty ? (
          <div className={styles.empty}>
            <div className={styles.emptyIcon}>✅</div>
            <div className={styles.emptyTitle}>Hozircha xatolar yo‘q</div>
            <div className={styles.emptyText}>
              Bilet yoki imtihon ishlang — xatolar shu yerda ko‘rinadi.
            </div>
            <div className={styles.emptyActions}>
              <Link className={styles.btnPrimary} href="/tickets">
                Biletlar →
              </Link>
              <Link className={styles.btnGhost} href="/exam">
                Imtihon →
              </Link>
            </div>
          </div>
        ) : active === 'overall' ? (
          <>
            <div className={styles.sectionHead}>
              <div>
                <div className={styles.sectionTitle}>Umumiy xatolar</div>
                <div className={styles.sectionSub}>
                  Takrorlangan savollar bir marta sanaladi. “Bajarildi” bosilsa ro‘yxatdan chiqadi.
                </div>
              </div>
              <div className={styles.sectionMeta}>
                {loadingOverall ? <span className={styles.miniTag}>Yuklanmoqda…</span> : null}
                <span className={styles.miniTag}>Jami: {totalOverall}</span>
              </div>
            </div>

            {filteredOverall.map((it, idx) => {
              const wrongTimes = safeInt(it.wrong_times, 0);
              const bar = clamp(wrongTimes * 18, 12, 100);
              const kind = badgeKind(wrongTimes);

              const title =
                it.bilet_number != null && it.question_number != null
                  ? `Bilet ${it.bilet_number} · Savol ${it.question_number}`
                  : it.bilet_number != null
                    ? `Bilet ${it.bilet_number}`
                    : `Savol #${idx + 1}`;

              return (
                <article key={it.question_id} className={styles.card}>
                  <div className={styles.cardTop}>
                    <div className={styles.num}>{idx + 1}</div>
                    <div className={`${styles.badge} ${styles[`badge_${kind}`]}`}>
                      {wrongTimes > 0 ? `${wrongTimes}×` : ''} {badgeLabel(wrongTimes)}
                    </div>
                  </div>

                  <div className={styles.title}>{title}</div>

                  <div className={styles.qText}>{it.text || 'Savol matni mavjud emas.'}</div>

                  <div className={styles.meta}>
                    <span>🕒 {relativeTime(it.last_wrong_at)}</span>
                    <span className={styles.metaDim}>{it.last_wrong_at ? formatTimeIso(it.last_wrong_at) : ''}</span>
                  </div>

                  <div className={styles.bar}>
                    <div className={styles.fill} style={{ width: `${bar}%` }} />
                  </div>

                  <div className={styles.actions}>
                    {/* Optional: jump to a question-based review page later */}
                    <button className={styles.btnSecondary} type="button" onClick={() => resolveQuestion(it.question_id)}>
                      Bajarildi ✓
                    </button>

                    <button className={styles.btnPrimary} type="button" onClick={() => resolveQuestion(it.question_id)}>
                      Yopish →
                    </button>
                  </div>

                  {it.explanation ? (
                    <details className={styles.details}>
                      <summary className={styles.summary}>Izohni ko‘rish</summary>
                      <div className={styles.expl}>{it.explanation}</div>
                    </details>
                  ) : null}
                </article>
              );
            })}

            <div className={styles.loadMoreRow}>
              <button
                type="button"
                className={styles.btnGhostWide}
                disabled={!overallHasMore || loadingOverall}
                onClick={async () => {
                  const next = overallPage + 1;
                  await loadOverall(next, true);
                  setOverallPage(next);
                }}
              >
                {overallHasMore ? (loadingOverall ? 'Yuklanmoqda…' : 'Yana yuklash') : 'Hammasi yuklandi'}
              </button>
            </div>
          </>
        ) : (
          <>
            <div className={styles.sectionHead}>
              <div>
                <div className={styles.sectionTitle}>{modeLabel(active)}</div>
                <div className={styles.sectionSub}>
                  Har bir urinish alohida ko‘rsatiladi. Ko‘rib chiqing yoki ro‘yxatdan yashiring.
                </div>
              </div>

              <div className={styles.sectionMeta}>
                <span className={styles.miniTag}>Soni: {filteredAttemptList.length}</span>
              </div>
            </div>

            {filteredAttemptList.map((it, idx) => {
              const wrong = safeInt(it.wrong_count, 0);
              const title = (it.title || `Urinish ${idx + 1}`).trim();
              const kind = badgeKind(wrong);
              const bar = clamp(wrong * 12, 8, 100);

              const when = it.finished_at || it.started_at || it.last_wrong_at;
              const whenLabel = when ? relativeTime(when) : '';

              return (
                <article key={it.attempt_id} className={styles.card}>
                  <div className={styles.cardTop}>
                    <div className={styles.num}>{idx + 1}</div>
                    <div className={`${styles.badge} ${styles[`badge_${kind}`]}`}>
                      {badgeLabel(wrong)}
                    </div>
                  </div>

                  <div className={styles.title}>{title}</div>

                  <div className={styles.meta}>
                    <span>❌ {wrong} xato</span>
                    <span>🕒 {whenLabel}</span>
                    <span className={styles.metaDim}>{when ? formatTimeIso(when) : ''}</span>
                  </div>

                  <div className={styles.bar}>
                    <div className={styles.fill} style={{ width: `${bar}%` }} />
                  </div>

                  <div className={styles.actions}>
                    {/* Fix: not /mistakes (black hole), but actual review page */}
                    <Link className={styles.btnSecondary} href={`/review/${it.attempt_id}`}>
                      Ko‘rib chiqish
                    </Link>

                    <button className={styles.btnGhost} type="button" onClick={() => hideAttempt(it.attempt_id)}>
                      Ro‘yxatdan olib tashlash
                    </button>

                    <Link className={styles.btnPrimary} href={`/review/${it.attempt_id}`}>
                      Review →
                    </Link>
                  </div>
                </article>
              );
            })}
          </>
        )}
      </section>

      <div className={styles.footer}>
        <Link href="/app" className={styles.footerLink}>
          ← Dashboard
        </Link>
      </div>
    </main>
  );
}
