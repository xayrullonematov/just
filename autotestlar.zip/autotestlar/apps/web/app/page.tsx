'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getJSON } from '../lib/api';
import styles from './page.module.css';

export default function Home() {
  const [m, setM] = useState<any>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    (async () => setM(await getJSON('/public/metrics')))();
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 100);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      {/* ── Navbar ── */}
      <nav className={`${styles.navbar} ${scrolled ? styles.navbarScrolled : ''}`}>
        <div className={styles.navContainer}>
          <Link href="/" className={styles.logo}>
            <div className={styles.logoIcon}>🎯</div>
            AUTO TESTLAR
          </Link>

          <div className={styles.navLinks}>
            <a href="#features" className={styles.navLink}>Imkoniyatlar</a>
            <a href="#pricing" className={styles.navLink}>Narxlar</a>
            <a href="#cta" className={styles.navLink}>Haqida</a>
            <a href="#contact" className={styles.navLink}>Aloqa</a>
          </div>

          <div className={styles.navActions}>
            <Link href="/login" className={`${styles.btn} ${styles.btnGhost}`}>
              <span>Kirish</span>
            </Link>
            <Link href="/app" className={`${styles.btn} ${styles.btnPrimary}`}>
              <span>Bepul boshlash</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section className={styles.hero}>
        <div className={styles.heroBackground}>
          <div className={styles.heroGradient} />
          <div className={styles.heroGrid} />
        </div>

        <div className={styles.heroContainer}>
          <div className={styles.heroContent}>
            <div className={styles.heroBadge}>
              <span className={styles.badgeDot} />
              {m && !m.error ? `${m.users?.toLocaleString()}+ foydalanuvchi` : '10,000+ foydalanuvchi'}
            </div>

            <h1 className={styles.heroTitle}>
              IMTIHONGA
              <span className={styles.heroTitleHighlight}>PROFESSIONAL</span>
              TAYYORGARLIK
            </h1>

            <p className={styles.heroDescription}>
              Telegram Web App uchun moslashgan tezkor va samarali tayyorgarlik platformasi.
              Har kuni yangi testlar, professional tizim va batafsil statistika.
            </p>

            <div className={styles.heroActions}>
              <Link href="/app" className={`${styles.btn} ${styles.btnPrimary} ${styles.btnLarge}`}>
                <span>Bepul boshlash</span>
              </Link>
              <a href="#cta" className={`${styles.btn} ${styles.btnGhost} ${styles.btnLarge}`}>
                <span>Batafsil ma&apos;lumot</span>
              </a>
            </div>

            <div className={styles.heroStats}>
              <div className={styles.stat}>
                <div className={styles.statNumber}>
                  {m && !m.error ? `${m.questions?.toLocaleString()}+` : '5000+'}
                </div>
                <div className={styles.statLabel}>Testlar</div>
              </div>
              <div className={styles.stat}>
                <div className={styles.statNumber}>98%</div>
                <div className={styles.statLabel}>Muvaffaqiyat</div>
              </div>
              <div className={styles.stat}>
                <div className={styles.statNumber}>24/7</div>
                <div className={styles.statLabel}>Qo&apos;llab-quvvatlash</div>
              </div>
            </div>
          </div>

          <div className={styles.heroVisual}>
            <div className={styles.visualCard}>
              <div className={styles.visualHeader}>
                <h3 className={styles.visualTitle}>Bugungi test</h3>
                <div className={styles.visualBadge}>Faol</div>
              </div>
              <div className={styles.questionList}>
                {[
                  'YHQ qoidalari asosida',
                  "Yo'l belgilari",
                  'Favqulota vaziyatlar',
                ].map((q, i) => (
                  <div key={i} className={styles.questionItem}>
                    <div className={styles.questionNumber}>{i + 1}</div>
                    <div className={styles.questionText}>{q}</div>
                    <div className={styles.questionStatus}>✓</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section className={styles.features} id="features">
        <div className={styles.featuresContainer}>
          <div className={styles.sectionHeader}>
            <div className={styles.sectionSubtitle}>Imkoniyatlar</div>
            <h2 className={styles.sectionTitle}>NIMA UCHUN BIZNI TANLAYSIZ</h2>
            <p className={styles.sectionDescription}>
              Professional tayyorgarlik uchun zarur bo&apos;lgan barcha vositalar bir joyda
            </p>
          </div>

          <div className={styles.featuresGrid}>
            {[
              {
                icon: '/tests-icon.webp',
                title: '5000+ Test savollari',
                desc: "Barcha fanlardan professional tuzilgan test savollari. Har kuni yangi testlar qo'shiladi.",
              },
              {
                icon: '/statistics-icon.webp',
                title: 'Batafsil statistika',
                desc: "O'z tayyorgarligingizni kuzatib boring. Grafik va diagrammalar orqali tahlil qiling.",
              },
              {
                icon: '/education-icon.webp',
                title: 'Shaxsiy tayyorgarlik',
                desc: 'Sizning natijalaringizga qarab moslashtirilgan testlar va tavsiyalar.',
              },
            ].map((f, i) => (
              <div key={i} className={styles.featureCard}>
                <div className={styles.featureIcon}>
                  <img src={f.icon} alt={f.title} width={48} height={48} />
                </div>
                <h3 className={styles.featureTitle}>{f.title}</h3>
                <p className={styles.featureDescription}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section className={styles.pricing} id="pricing">
        <div className={styles.pricingContainer}>
          <div className={styles.sectionHeader}>
            <div className={`${styles.sectionSubtitle} ${styles.accentText}`}>Narxlar</div>
            <h2 className={`${styles.sectionTitle} ${styles.darkTitle}`}>O&apos;ZINGIZGA MOS REJANI TANLANG</h2>
            <p className={`${styles.sectionDescription} ${styles.darkDesc}`}>
              Bepul versiya bilan boshlang yoki premium imkoniyatlardan foydalaning
            </p>
          </div>

          <div className={styles.pricingGrid}>
            <div className={styles.pricingCard}>
              <div className={styles.pricingLabel}>Bepul</div>
              <h3 className={styles.pricingName}>Standart</h3>
              <div className={styles.pricingPrice}>0 so&apos;m</div>
              <div className={styles.pricingPeriod}>Doimiy bepul</div>
              <ul className={styles.pricingFeatures}>
                {["Kuniga 5 ta test", "Asosiy statistika", "1000+ savol bazasi", "Telegram qo'llab-quvvatlash"].map(f => <li key={f}>{f}</li>)}
              </ul>
              <Link href="/app" className={`${styles.btn} ${styles.btnGhost} ${styles.btnBlock}`}>
                <span>Boshlash</span>
              </Link>
            </div>

            <div className={`${styles.pricingCard} ${styles.pricingFeatured}`}>
              <div className={`${styles.pricingLabel} ${styles.accentText}`}>Ommabop</div>
              <h3 className={styles.pricingName}>Premium</h3>
              <div className={styles.pricingPrice}>49,000 so&apos;m</div>
              <div className={styles.pricingPeriod}>Oyiga</div>
              <ul className={styles.pricingFeatures}>
                {["Cheksiz testlar", "Batafsil statistika va tahlil", "5000+ savol bazasi", "Shaxsiy tavsiyalar", "24/7 qo'llab-quvvatlash", "Offline rejim"].map(f => <li key={f}>{f}</li>)}
              </ul>
              <Link href="/signup" className={`${styles.btn} ${styles.btnPrimary} ${styles.btnBlock}`}>
                <span>Premium olish</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className={styles.cta} id="cta">
        <div className={styles.ctaContainer}>
          <h2 className={styles.ctaTitle}>BUGUN TAYYORGARLIKNI BOSHLANG</h2>
          <p className={styles.ctaDescription}>
            Minglab talabalar bizning platformamiz orqali muvaffaqiyatga erishdi.
            Siz ham ularga qo&apos;shiling!
          </p>
          <div className={styles.ctaActions}>
            <Link href="/app" className={`${styles.btn} ${styles.btnWhite}`}>
              <span>Bepul boshlash</span>
            </Link>
            <a href="#pricing" className={`${styles.btn} ${styles.btnOutline}`}>
              <span>Premium olish</span>
            </a>
          </div>
        </div>
      </section>

      {/* ── Contact ── */}
      <section className={styles.contactSection} id="contact">
        <div className={styles.contactContainer}>
          <div className={styles.contactHeader}>
            <div className={`${styles.sectionSubtitle} ${styles.accentText}`}>Aloqa</div>
            <h2 className={`${styles.sectionTitle} ${styles.darkTitle}`}>BIZ BILAN BOG&apos;LANING</h2>
            <p className={`${styles.sectionDescription} ${styles.darkDesc}`}>
              Tezkor savollar uchun Telegram, yangiliklar uchun Instagram, rasmiy murojaat uchun email yoki qo&apos;ng&apos;iroq.
            </p>
          </div>

          <div className={styles.contactGrid}>
            <div className={styles.contactCard}>
              <div className={styles.contactIcon}>
                <img src="/telegram-icon.webp" alt="Telegram" width={40} height={40} />
              </div>
              <div className={styles.contactTitle}>Telegram</div>
              <div className={styles.contactSub}>Tezkor aloqa</div>
              <a className={styles.contactLink} href="https://t.me/autotestlar" target="_blank" rel="noreferrer">
                <span>@autotestlar</span>
              </a>
            </div>

            <div className={styles.contactCard}>
              <div className={styles.contactIcon}>
                <img src="/instagram-icon.webp" alt="Instagram" width={40} height={40} />
              </div>
              <div className={styles.contactTitle}>Instagram</div>
              <div className={styles.contactSub}>Yangiliklar va e&apos;lonlar</div>
              <a className={styles.contactLink} href="https://instagram.com/autotestlar" target="_blank" rel="noreferrer">
                <span>@autotestlar</span>
              </a>
            </div>

            <div className={styles.contactCard}>
              <div className={styles.contactIcon}>
                <img src="/phone-icon.webp" alt="Phone" width={40} height={40} />
              </div>
              <div className={styles.contactTitle}>Qo&apos;ng&apos;iroq</div>
              <div className={styles.contactSub}>Telefon orqali</div>
              <a className={styles.contactLink} href="tel:+998770003349">
                <span>+998 77 000 33 49</span>
              </a>
            </div>

            <div className={styles.contactCard}>
              <div className={styles.contactIcon}>
                <img src="/email-icon.webp" alt="Email" width={40} height={40} />
              </div>
              <div className={styles.contactTitle}>Email</div>
              <div className={styles.contactSub}>Xatlar uchun</div>
              <a className={styles.contactLink} href="mailto:info@autotestlar.uz">
                <span>info@autotestlar.uz</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className={styles.footer}>
        <div className={styles.footerContainer}>
          <div className={styles.footerContent}>
            <div className={styles.footerBrand}>
              <div className={styles.footerLogo}>AUTO TESTLAR</div>
              <p className={styles.footerDescription}>
                Professional imtihon tayyorgarlik platformasi.
                Telegram Web App uchun moslashtirilgan tezkor va samarali yechim.
              </p>
            </div>
            <div className={styles.footerSection}>
              <h4>Platform</h4>
              <ul className={styles.footerLinks}>
                <li><a href="#features">Imkoniyatlar</a></li>
                <li><a href="#pricing">Narxlar</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Blog</a></li>
              </ul>
            </div>
            <div className={styles.footerSection}>
              <h4>Kompaniya</h4>
              <ul className={styles.footerLinks}>
                <li><a href="#">Biz haqimizda</a></li>
                <li><a href="#">Jamoa</a></li>
                <li><a href="#">Karyera</a></li>
                <li><a href="#contact">Aloqa</a></li>
              </ul>
            </div>
            <div className={styles.footerSection}>
              <h4>Qo&apos;llab-quvvatlash</h4>
              <ul className={styles.footerLinks}>
                <li><a href="#">Yordam markazi</a></li>
                <li><a href="#">Foydalanish shartlari</a></li>
                <li><a href="#">Maxfiylik siyosati</a></li>
                <li><a href="https://t.me/autotestlar" target="_blank" rel="noreferrer">Telegram</a></li>
              </ul>
            </div>
          </div>
          <div className={styles.footerBottom}>
            © 2025 Auto Testlar. Barcha huquqlar himoyalangan.
          </div>
        </div>
      </footer>
    </>
  );
}
