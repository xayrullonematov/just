'use client';
import { useEffect, useState } from 'react';
import { postJSON } from '../../lib/api';
import { useRouter } from 'next/navigation';

export default function VerifyEmailPage(){
  const [msg,setMsg]=useState('Verifying...');
  const router=useRouter();
  useEffect(()=>{(async()=>{
    const token = typeof window !== 'undefined' ? (new URLSearchParams(window.location.search).get('token') || '') : '';
    const res=await postJSON('/auth/verify-email',{token});
    if(res.error){setMsg(res.error.message);return;}
    setMsg('Email tasdiqlandi');
    setTimeout(()=>router.push('/verify-success'),500);
  })()},[router]);
  return <main><h1>Verify email</h1><p>{msg}</p></main>;
}
