'use client';

import Link from 'next/link';
import { useRef, useState } from 'react';
import { csrf, postJSON } from '../../lib/api';
import styles from './page.module.css';

const MAX_MB = 5;
const ACCEPT = 'image/png,image/jpeg,image/webp,image/gif';

type UploadState = 'idle' | 'uploading' | 'success' | 'error';

export default function AvatarPage() {
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState('');
  const [uploadState, setUploadState] = useState<UploadState>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  function handleFile(file: File | null) {
    if (!file) return;

    setErrorMsg('');
    setUploadState('idle');

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Faqat rasm fayllari qabul qilinadi (PNG, JPG, WEBP).');
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      setErrorMsg(`Fayl hajmi ${MAX_MB} MB dan oshmasligi kerak.`);
      return;
    }

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }

  function onInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    handleFile(e.target.files?.[0] ?? null);
    e.target.value = '';
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    handleFile(e.dataTransfer.files?.[0] ?? null);
  }

  function onDragOver(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(true);
  }
  function onDragLeave() {
    setIsDragging(false);
  }

  async function handleUpload() {
    if (!inputRef.current?.files?.[0] && !preview) return;

    let blob: Blob;
    const file = inputRef.current?.files?.[0];
    if (file) {
      blob = file;
    } else {
      const res = await fetch(preview!);
      blob = await res.blob();
    }

    setUploadState('uploading');
    setErrorMsg('');

    try {
      await csrf();

      // Step 1 — get a presigned upload URL from the backend (CSRF-protected)
      const urlData = await postJSON('/me/avatar/upload-url', { content_type: blob.type });

      if (urlData?.error) {
        setErrorMsg(urlData?.error?.message || "Upload URL olib bo'lmadi.");
        setUploadState('error');
        return;
      }

      // Step 2 — PUT the file directly to R2 via the presigned URL (NO CSRF needed)
      const putRes = await fetch(urlData.upload_url, {
        method: 'PUT',
        headers: { 'Content-Type': blob.type },
        body: blob,
      });

      if (!putRes.ok) {
        setErrorMsg('Fayl yuklashda xatolik yuz berdi.');
        setUploadState('error');
        return;
      }

      // Step 3 — confirm the R2 key with the backend (CSRF-protected)
      const confirmData = await postJSON('/me/avatar', { avatar_r2_key: urlData.r2_key });

      if (confirmData?.error) {
        setErrorMsg(confirmData?.error?.message || 'Avatar saqlashda xatolik.');
        setUploadState('error');
        return;
      }

      setUploadState('success');
    } catch {
      setErrorMsg('Kutilmagan xatolik yuz berdi.');
      setUploadState('error');
    }
  }

  function handleReset() {
    setPreview(null);
    setFileName('');
    setUploadState('idle');
    setErrorMsg('');
    if (inputRef.current) inputRef.current.value = '';
  }

  const isUploading = uploadState === 'uploading';

  return (
    <div className={styles.body}>
      <div className={styles.background}>
        <div className={styles.gradientOrb} />
        <div className={styles.gradientOrb} />
        <div className={styles.gradientOrb} />
      </div>

      <div className={styles.card}>
        <div className={styles.branding}>
          <div className={styles.logoRow}>
            <div className={styles.logoIcon}>🎯</div>
            <div>
              <div className={styles.logoText}>AUTO TESTLAR</div>
              <div className={styles.logoTagline}>Profil rasmi sozlamasi</div>
            </div>
          </div>
        </div>

        <div className={styles.formSection}>
          <h1 className={styles.loginTitle}>Profil rasmini yuklash</h1>

          {errorMsg && (
            <div className={styles.errorBox} role="alert">
              {errorMsg}
            </div>
          )}

          {uploadState === 'success' && (
            <div className={styles.successBox}>✅ Profil rasmi muvaffaqiyatli saqlandi!</div>
          )}

          <div
            className={`${styles.dropZone} ${isDragging ? styles.dropZoneDragging : ''} ${
              preview ? styles.dropZoneHasPreview : ''
            }`}
            onClick={() => !preview && inputRef.current?.click()}
            onDrop={onDrop}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && !preview && inputRef.current?.click()}
            aria-label="Rasm yuklash maydoni"
          >
            {preview ? (
              <div className={styles.previewWrapper}>
                <img src={preview} alt="Tanlangan rasm" className={styles.previewImage} />
                <div className={styles.previewOverlay}>
                  <button
                    type="button"
                    className={styles.changeBtn}
                    onClick={(e) => {
                      e.stopPropagation();
                      inputRef.current?.click();
                    }}
                  >
                    🖼️ Rasmni almashtirish
                  </button>
                </div>
              </div>
            ) : (
              <div className={styles.dropContent}>
                <div className={styles.dropIcon}>📸</div>
                <p className={styles.dropTitle}>Rasmni bu yerga tashlang</p>
                <p className={styles.dropSubtitle}>yoki bosib tanlang</p>
                <p className={styles.dropHint}>PNG, JPG, WEBP · Maks {MAX_MB} MB</p>
              </div>
            )}
          </div>

          <input
            ref={inputRef}
            type="file"
            accept={ACCEPT}
            onChange={onInputChange}
            style={{ display: 'none' }}
            aria-hidden
          />

          {preview && uploadState !== 'success' && (
            <div className={styles.actions}>
              <button type="button" className={styles.btnReset} onClick={handleReset} disabled={isUploading}>
                Bekor qilish
              </button>
              <button
                type="button"
                className={`${styles.btnSubmit} ${isUploading ? styles.btnLoading : ''}`}
                onClick={handleUpload}
                disabled={isUploading}
              >
                {!isUploading && '⬆️ Saqlash'}
              </button>
            </div>
          )}

          {uploadState === 'success' && (
            <button type="button" className={styles.btnSubmit} onClick={handleReset} style={{ marginTop: 12 }}>
              Boshqa rasm yuklash
            </button>
          )}

          <div className={styles.footer}>
            <p className={styles.footerText}>
              <Link href="/profile" className={styles.footerLink}>
                ← Profilga qaytish
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
