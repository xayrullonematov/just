'use client';

import Link from 'next/link';
import { useState } from 'react';
import { API } from '../../../lib/api';

export default function AdminImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState('');

  async function submit() {
    if (!file) return setMsg('Fayl tanlang.');
    const form = new FormData();
    form.append('file', file);

    const res = await fetch(`${API}/admin/import/questions`, {
      method: 'POST',
      credentials: 'include',
      body: form,
    }).then((r) => r.json());

    setMsg(res?.error ? res.error.message : `Import yakunlandi. Created: ${res.created}`);
  }

  return (
    <main className="page">
      <section className="card">
        <h1>Admin import</h1>
        <p>JSON/CSV orqali savollarni tizimga yuklang.</p>
        <input type="file" accept=".json,.csv,text/csv,application/json" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        <button onClick={submit}>Import qilish</button>
        {msg && <p className="msg">{msg}</p>}
        <div className="links">
          <Link href="/profile">← Profil</Link>
          <Link href="/app">Dashboard</Link>
        </div>
      </section>

      <style jsx>{`
        .page { min-height: 100vh; background: #f8f8fa; padding: 28px 16px; display: grid; place-items: start center; }
        .card { width: min(720px, 100%); background: #fff; border: 1px solid #e8e8ec; border-radius: 18px; padding: 22px; box-shadow: 0 4px 18px rgba(0,0,0,.04); }
        h1 { margin: 0 0 8px; font-size: 28px; color: #0a0a0f; }
        p { color: #525266; margin: 0 0 12px; }
        input[type=file] { width: 100%; margin: 6px 0 12px; padding: 10px; border: 1px solid #e8e8ec; border-radius: 10px; background: #fff; }
        button { border: none; border-radius: 999px; padding: 10px 16px; cursor: pointer; font-weight: 600; color: #fff; background: linear-gradient(135deg,#ff6b35 0%,#ff8555 100%); }
        .msg { margin-top: 12px; }
        .links { display: flex; gap: 12px; margin-top: 12px; }
        .links a { color: #0a0a0f; text-decoration: none; border: 1px solid #e8e8ec; border-radius: 999px; padding: 8px 12px; }
      `}</style>
    </main>
  );
}
