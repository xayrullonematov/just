'use client';

import { FormEvent, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { csrf, postJSON } from '../../lib/api';

export default function TwoFaPage() {
  const router = useRouter();
  const [challengeToken, setChallengeToken] = useState('');

  const [code, setCode] = useState('');
  const [recoveryCode, setRecoveryCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const url = new URL(window.location.href);
    setChallengeToken(url.searchParams.get('challenge_token') || '');
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!challengeToken) {
      setError('Challenge token topilmadi. Qayta login qiling.');
      return;
    }
    if (!code.trim() && !recoveryCode.trim()) {
      setError('2FA kod yoki recovery code kiriting.');
      return;
    }

    setLoading(true);
    try {
      await csrf();
      const res = await postJSON('/auth/2fa/verify', {
        challenge_token: challengeToken,
        code: code.trim() || undefined,
        recovery_code: recoveryCode.trim() || undefined,
      });
      if (res?.error) {
        setError(res.error.message || '2FA tasdiqlashda xatolik yuz berdi.');
        setLoading(false);
        return;
      }
      router.push('/app');
    } catch {
      setError('2FA tasdiqlashda kutilmagan xatolik yuz berdi.');
    }
    setLoading(false);
  }

  return (
    <main>
      <h1>2FA tasdiqlash</h1>
      <form onSubmit={onSubmit}>
        <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="6 xonali kod" />
        <input value={recoveryCode} onChange={(e) => setRecoveryCode(e.target.value)} placeholder="Recovery code (ixtiyoriy)" />
        <button type="submit" disabled={loading}>{loading ? 'Tekshirilmoqda...' : 'Tasdiqlash'}</button>
      </form>
      {error && <p>{error}</p>}
    </main>
  );
}
