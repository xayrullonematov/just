'use client';
import { FormEvent, useState } from 'react';
import { csrf, postJSON } from '../../lib/api';
import { useRouter } from 'next/navigation';

export default function ResetPasswordPage(){
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');
  const [err,setErr]=useState('');
  const router=useRouter();
  async function onSubmit(e:FormEvent){
    e.preventDefault();
    await csrf();
    const token = typeof window !== 'undefined' ? (new URLSearchParams(window.location.search).get('token') || '') : '';
    const res=await postJSON('/auth/reset-password',{token,new_password:password});
    if(res.error){setErr(res.error.message);return;}
    setMsg('Parol yangilandi');
    setTimeout(()=>router.push('/login'),600);
  }
  return <main><h1>Reset password</h1><form onSubmit={onSubmit}><input type='password' value={password} onChange={e=>setPassword(e.target.value)} /><button>Reset</button></form><p>{msg||err}</p></main>
}
