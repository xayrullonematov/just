'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getJSON } from '../../lib/api';
import { useRouter } from 'next/navigation';

export default function PracticePage() {
  const [tests, setTests] = useState<any[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    (async () => {
      const res = await getJSON('/tests?type=ticket&include_progress=1');
      if (res?.error) setError(res.error.message);
      else setTests(res.items || []);
      setLoading(false);
    })();
  }, []);

  function startPractice(testId: string) {
    router.push(`/exam/${testId}?mode=practice`);
  }

  if (loading) return <main><h1>Mashq</h1><p>Yuklanmoqda...</p></main>;

  return (
    <main>
      <h1>Mashq</h1>
      <p>Amaliy testni boshlang.</p>
      {error && <p>{error}</p>}
      {!tests.length ? <p>Testlar topilmadi.</p> : tests.map((t) => (
        <div key={t.id} style={{ marginBottom: 12 }}>
          <b>{t.title}</b> ({t.question_count} savol)
          <button onClick={() => startPractice(t.id)} style={{ marginLeft: 8 }}>Boshlash</button>
        </div>
      ))}
      <p><Link href="/app">← Dashboard</Link></p>
    </main>
  );
}
