'use client';
import { useEffect, useState } from 'react';
import { csrf, getJSON, postJSON, readCookie } from '../../lib/api';

export default function Notifications(){
  const [state,setState]=useState<any>({loading:true,items:[]});

  async function load() {
    const d=await getJSON('/me/notifications');
    if(d.error){setState({loading:false,error:d.error.message,items:[]});return;}
    setState({loading:false,items:d.items||[]});
  }

  useEffect(()=>{load()},[]);

  async function markRead(id: string){
    await csrf();
    const res = await postJSON(`/me/notifications/${id}/read`, {});
    if (!res?.error) await load();
  }

  if(state.loading) return <div>Loading...</div>;
  if(state.error) return <div>Error notifications: {state.error}</div>;
  if(!state.items.length) return <div>Empty notifications</div>;
  return <div>{state.items.map((n:any)=><div key={n.id}><b>{n.title}</b><p>{n.body}</p><button disabled={n.is_read} onClick={()=>markRead(n.id)}>{n.is_read ? 'Read' : 'Mark as read'}</button></div>)}</div>;
}
