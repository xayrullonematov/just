'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { csrf, getJSON, postJSON, readCookie } from '../../lib/api';
import styles from './page.module.css';

type Me = {
  id: string;
  email: string;
  name: string;
  is_email_verified: boolean;
  twofa_enabled: boolean;
  avatar_url: string | null;
  avatar_r2_key?: string | null;
};

type Dashboard = {
  daily_done?: number;
  ranking_percent?: number | null;
};

/* ── Dark mode helper (persisted in localStorage) ── */
function applyDark(on: boolean) {
  document.documentElement.setAttribute('data-theme', on ? 'dark' : 'light');
  try { localStorage.setItem('darkMode', on ? '1' : '0'); } catch {}
}

export default function ProfilePage() {
  const router = useRouter();

  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState('');
  const [success,  setSuccess]  = useState('');
  const [me,       setMe]       = useState<Me | null>(null);
  const [dashboard,setDashboard]= useState<Dashboard | null>(null);

  const [isEditing, setIsEditing] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [lastName,  setLastName]  = useState('');
  const [email,     setEmail]     = useState('');
  const [saving,    setSaving]    = useState(false);

  /* ── Settings state ── */
  const [emailNotif, setEmailNotif] = useState(true);
  const [pushNotif,  setPushNotif]  = useState(true);
  const [twoFA,      setTwoFA]      = useState(false);
  const [darkMode,   setDarkMode]   = useState(false);
  const [savingNotif,setSavingNotif]= useState(false);

  /* ── 2FA confirm modal ── */
  const [showDisable2FA, setShowDisable2FA] = useState(false);

  /* ── Load ── */
  useEffect(() => {
    // Restore dark mode from localStorage immediately
    try {
      const stored = localStorage.getItem('darkMode');
      const on = stored === '1';
      setDarkMode(on);
      applyDark(on);
    } catch {}

    (async () => {
      try {
        const meRes = await getJSON('/me');
        if (meRes?.error) { setError(meRes.error.message || 'Profilni yuklab bo\'lmadi.'); setLoading(false); return; }

        const dashRes = await getJSON('/me/dashboard');
        if (dashRes?.error) { setError(dashRes.error.message || 'Statistikani yuklab bo\'lmadi.'); setLoading(false); return; }

        setMe(meRes);
        setDashboard(dashRes);

        const parts = String(meRes.name || '').trim().split(/\s+/).filter(Boolean);
        setFirstName(parts[0] || '');
        setLastName(parts.slice(1).join(' '));
        setEmail(meRes.email || '');
        setTwoFA(Boolean(meRes.twofa_enabled));

        // Load notification prefs if backend exposes them
        const prefsRes = await getJSON('/me/notification-prefs').catch(() => null);
        if (prefsRes && !prefsRes.error) {
          setEmailNotif(prefsRes.email_notifications ?? true);
          setPushNotif(prefsRes.push_notifications   ?? true);
        }

        setLoading(false);
      } catch {
        setError('Profilni yuklashda kutilmagan xatolik.');
        setLoading(false);
      }
    })();
  }, []);

  const initials = useMemo(() => {
    const src = `${firstName} ${lastName}`.trim() || me?.name || '';
    const p = src.split(/\s+/).filter(Boolean);
    if (!p.length) return 'AT';
    if (p.length === 1) return p[0].slice(0, 2).toUpperCase();
    return `${p[0][0] || ''}${p[1][0] || ''}`.toUpperCase();
  }, [firstName, lastName, me?.name]);

  const totalTests  = Number(dashboard?.daily_done   || 0);
  const rankingText = dashboard?.ranking_percent ? `Top ${dashboard.ranking_percent}%` : 'Top —';

  /* ── Save profile ── */
  async function saveProfile() {
    if (!me) return;
    setSaving(true); setError(''); setSuccess('');
    try {
      const name = `${firstName} ${lastName}`.trim() || me.name;
      await csrf();
      const res = await postJSON('/me/profile', { name });
      if (res?.error) { setError(res.error.message || 'Saqlab bo\'lmadi.'); setSaving(false); return; }
      setMe(prev => prev ? { ...prev, name: res.name || name } : prev);
      setIsEditing(false);
      setSuccess('O\'zgarishlar saqlandi.');
    } catch { setError('Saqlashda xatolik.'); }
    setSaving(false);
  }

  /* ── Save notification prefs ── */
  async function saveNotifPrefs(emailVal: boolean, pushVal: boolean) {
    setSavingNotif(true);
    try {
      await csrf();
      await postJSON('/me/notification-prefs',
        { email_notifications: emailVal, push_notifications: pushVal },
      );
    } catch {}
    setSavingNotif(false);
  }

  function handleEmailNotif(val: boolean) {
    setEmailNotif(val);
    saveNotifPrefs(val, pushNotif);
  }
  function handlePushNotif(val: boolean) {
    setPushNotif(val);
    saveNotifPrefs(emailNotif, val);
  }

  /* ── Dark mode toggle ── */
  function handleDarkMode(val: boolean) {
    setDarkMode(val);
    applyDark(val);
  }

  /* ── 2FA toggle ── */
  function handle2FAToggle(val: boolean) {
    if (val) {
      // Enable: go to setup page
      router.push('/security/2fa');
    } else {
      // Disable: show confirmation modal
      setShowDisable2FA(true);
    }
  }
  async function confirmDisable2FA() {
    setShowDisable2FA(false);
    try {
      await csrf();
      const res = await postJSON('/me/2fa/disable', {});
      if (res?.error) { setError(res.error.message || '2FA o\'chirilmadi.'); return; }
      setTwoFA(false);
      setSuccess('Ikki bosqichli tekshiruv o\'chirildi.');
    } catch { setError('2FA o\'chirishda xatolik.'); }
  }

  return (
    <>
      {/* ── Navbar ── */}
      <nav className={styles.navbar}>
        <div className={styles.navInner}>
          <Link href="/app" className={styles.logo}>
            <div className={styles.logoIcon}>🎯</div>
            <span className={styles.logoText}>AUTO TESTLAR</span>
          </Link>
          <div className={styles.navRight}>
            <Link href="/app"           className={styles.btnIcon} title="Bosh sahifa">🏠</Link>
            <Link href="/notifications" className={styles.btnIcon} title="Bildirishnomalar">🔔</Link>
          </div>
        </div>
      </nav>

      {/* ── Main ── */}
      <div className={styles.main}>

        {/* ── Profile header ── */}
        <div className={styles.profileHeader}>
          <div className={styles.avatarSection}>
            <div className={styles.avatar}>
              {me?.avatar_url
                ? <img src={me.avatar_url} alt="Avatar" className={styles.avatarImg} />
                : initials}
              <div className={styles.avatarBadge}>✓</div>
            </div>
            <button className={styles.changeAvatar} onClick={() => router.push('/avatar')}>
              Rasmni o'zgartirish
            </button>
          </div>
          <div className={styles.profileInfo}>
            <h1 className={styles.profileName}>
              {loading ? 'Yuklanmoqda...'
                : firstName || lastName
                  ? `${firstName} ${lastName}`.trim()
                  : me?.name || '—'}
            </h1>
            <p className={styles.profileEmail}>
              {loading ? '...' : error
                ? <span className={styles.errorText}>{error}</span>
                : success
                  ? <span className={styles.successText}>{success}</span>
                  : (email || me?.email || '—')}
            </p>
            <div className={styles.profileStats}>
              <div className={styles.statItem}>
                <div className={styles.statVal}>{loading ? '…' : totalTests}</div>
                <div className={styles.statLbl}>Testlar</div>
              </div>
              <div className={styles.statItem}>
                <div className={styles.statVal}>{loading ? '…' : '0%'}</div>
                <div className={styles.statLbl}>To'g'ri</div>
              </div>
              <div className={styles.statItem}>
                <div className={styles.statVal}>{loading ? '…' : 0}</div>
                <div className={styles.statLbl}>Kun ketma-ket</div>
              </div>
              <div className={styles.statItem}>
                <div className={styles.statVal}>{loading ? '…' : rankingText}</div>
                <div className={styles.statLbl}>Reyting</div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Two-column layout on desktop ── */}
        <div className={styles.grid}>

          {/* LEFT */}
          <div className={styles.col}>

            {/* Personal info */}
            <section className={styles.section}>
              <div className={styles.sectionHead}>
                <h2 className={styles.sectionTitle}>Shaxsiy ma'lumotlar</h2>
                <button className={styles.sectionAction} onClick={() => setIsEditing(v => !v)}>
                  {isEditing ? 'Bekor qilish' : 'Tahrirlash'}
                </button>
              </div>
              <div className={styles.formGrid}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Ism</label>
                  <input className={styles.formInput} value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    disabled={!isEditing || loading} />
                </div>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Familiya</label>
                  <input className={styles.formInput} value={lastName}
                    onChange={e => setLastName(e.target.value)}
                    disabled={!isEditing || loading} />
                </div>
                <div className={`${styles.formGroup} ${styles.fullWidth}`}>
                  <label className={styles.formLabel}>Email</label>
                  <input className={styles.formInput} type="email" value={email} disabled />
                </div>
              </div>
              {isEditing && (
                <button className={`${styles.btn} ${styles.btnPrimary}`}
                  style={{ marginTop: 16 }}
                  onClick={saveProfile} disabled={saving || loading}>
                  {saving ? 'Saqlanmoqda...' : 'O\'zgarishlarni saqlash'}
                </button>
              )}
            </section>

            {/* Achievements */}
            <section className={styles.section}>
              <div className={styles.sectionHead}>
                <h2 className={styles.sectionTitle}>Yutuqlar</h2>
              </div>
              <div className={styles.achieveGrid}>
                {[
                  { icon:'🎯', name:'Birinchi test',    desc:'Birinchi testni tugatdingiz',    done: totalTests >= 1 },
                  { icon:'🔥', name:'7 kun ketma-ket',  desc:'Har kuni test ishlading',         done: false },
                  { icon:'💯', name:'Mukammal natija',  desc:'10/10 ball oldingiz',             done: false },
                  { icon:'📚', name:'100 test',         desc:'100 ta test yechdingiz',           done: totalTests >= 100 },
                  { icon:'🏆', name:'Top 10%',          desc:'Eng yaxshilar orasida',            done: (dashboard?.ranking_percent ?? 100) <= 10 },
                  { icon:'⚡', name:'30 kun ketma-ket', desc:'Har kuni faol bo\'ling',          done: false },
                ].map(a => (
                  <div key={a.name} className={`${styles.achieveCard} ${a.done ? styles.unlocked : ''}`}>
                    <div className={styles.achieveIcon}>{a.icon}</div>
                    <div className={styles.achieveName}>{a.name}</div>
                    <div className={styles.achieveDesc}>{a.desc}</div>
                  </div>
                ))}
              </div>
            </section>

          </div>{/* /col left */}

          {/* RIGHT */}
          <div className={styles.col}>


            {/* Account management */}
            <section className={styles.section}>
              <div className={styles.sectionHead}>
                <h2 className={styles.sectionTitle}>Hisob boshqaruvi</h2>
              </div>
              <div className={styles.accountBtns}>
                <button className={`${styles.btn} ${styles.btnSecondary}`}
                  onClick={() => router.push('/security')}>
                  🔑 Parolni o'zgartirish
                </button>
                <button className={`${styles.btn} ${styles.btnDanger}`}
                  onClick={() => router.push('/settings/delete')}>
                  🗑️ Hisobni o'chirish
                </button>
              </div>
            </section>

          </div>{/* /col right */}

        </div>{/* /grid */}
      </div>{/* /main */}

      {/* ── Disable 2FA confirmation modal ── */}
      {showDisable2FA && (
        <div className={styles.modalOverlay} onClick={() => setShowDisable2FA(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <div className={styles.modalIcon}>🔓</div>
            <h3 className={styles.modalTitle}>2FA ni o'chirish</h3>
            <p className={styles.modalText}>
              Ikki bosqichli tekshiruvni o'chirish hisobingiz xavfsizligini kamaytiradi.
              Davom etishni xohlaysizmi?
            </p>
            <div className={styles.modalBtns}>
              <button className={`${styles.btn} ${styles.btnSecondary}`}
                onClick={() => setShowDisable2FA(false)}>Bekor qilish</button>
              <button className={`${styles.btn} ${styles.btnDanger}`}
                onClick={confirmDisable2FA}>Ha, o'chirish</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
