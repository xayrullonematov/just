import { jwtVerify } from 'jose';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const PUBLIC_PATHS = ['/', '/login', '/signup', '/forgot-password', '/reset-password', '/verify-email', '/verify-success'];

function getJwtSecret(): Uint8Array | null {
  const configured = process.env.AUTH_JWT_SECRET || process.env.SECRET_KEY || process.env.NEXTAUTH_SECRET || '';
  if (configured) return new TextEncoder().encode(configured);

  if (process.env.NODE_ENV !== 'production') {
    return new TextEncoder().encode('dev-secret');
  }

  return null;
}

async function hasValidAccessToken(req: NextRequest): Promise<boolean> {
  const token = req.cookies.get('access_token')?.value;
  if (!token) return false;

  const secret = getJwtSecret();
  if (!secret) return false;

  try {
    const { payload } = await jwtVerify(token, secret, {
      algorithms: ['HS256'],
    });
    return payload.typ === 'access' && typeof payload.sub === 'string' && payload.sub.length > 0;
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + '/'));

  const hasValidAccess = await hasValidAccessToken(req);
  const hasSession = Boolean(req.cookies.get('session_id')?.value);
  const isAuthenticated = hasValidAccess || hasSession;

  if (!isPublic && !isAuthenticated) {
    const url = new URL('/login', req.url);
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  if ((pathname === '/login' || pathname === '/signup') && isAuthenticated) {
    return NextResponse.redirect(new URL('/app', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
