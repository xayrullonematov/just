const RAW_API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
export const API = RAW_API.replace(/\/$/, '').endsWith('/api/v1')
  ? RAW_API.replace(/\/$/, '')
  : `${RAW_API.replace(/\/$/, '')}/api/v1`;

export function readCookie(name: string) {
  if (typeof document === 'undefined') return '';
  const m = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : '';
}

export async function csrf() {
  // This endpoint must set the csrf_token cookie
  const res = await fetch(`${API}/auth/csrf`, { credentials: 'include' });
  return res;
}

function csrfHeader(): Record<string, string> {
  // IMPORTANT: cookie name must match what backend sets
  const token = readCookie('csrf_token');
  return token ? { 'x-csrf-token': token } : {};
}

export async function postJSON(path: string, body: unknown) {
  const headers: Record<string, string> = {
    'content-type': 'application/json',
    ...csrfHeader(),
  };

  const res = await fetch(`${API}${path}`, {
    method: 'POST',
    credentials: 'include',
    headers,
    body: JSON.stringify(body),
  });

  return res.json().catch(() => ({}));
}

export async function deleteJSON(path: string) {
  const headers: Record<string, string> = {
    ...csrfHeader(),
  };

  const res = await fetch(`${API}${path}`, {
    method: 'DELETE',
    credentials: 'include',
    headers,
  });

  return res.json().catch(() => ({}));
}

export async function getJSON(path: string) {
  const res = await fetch(`${API}${path}`, { credentials: 'include', cache: 'no-store' });
  return res.json().catch(() => ({}));
}
