# Auto Testlar Monorepo

Production-oriented baseline:
- `apps/api`: FastAPI + SQLAlchemy + Alembic + anti-cheat attempt engine
- `apps/web`: Next.js 14 App Router frontend
- `docker-compose.yml`: web + api + postgres

## Quickstart
```bash
docker compose up --build
```

See:
- `docs/PROJECT_BLUEPRINT.md`
- `docs/SCALING_CHECKLIST_STATUS.md`


## Security note: rate limiting
- Production must use Redis-backed rate limiting.
- Set `RATE_LIMIT_BACKEND=auto` and `REDIS_URL=redis://redis:6379/0` (or your managed Redis URL).
- In `app_env=prod`, API startup fails fast if Redis rate limiter is unavailable.

- `/api/v1/admin/import/questions` now requires authenticated **admin** user and valid CSRF token.
- In production, if `TELEGRAM_BOT_USERNAME` is set, `TELEGRAM_BOT_TOKEN` must also be set (startup fails fast otherwise).
- In production, cookie security is fail-fast: `COOKIE_SECURE=true`, `COOKIE_SAMESITE` is `lax|strict|none`, `COOKIE_SAMESITE=none` requires secure cookies, and `FRONTEND_URL`/`BACKEND_URL` must use `https://`.
- API DB engine uses explicit pool controls via env: `DB_POOL_SIZE`, `DB_MAX_OVERFLOW`, `DB_POOL_TIMEOUT`, `DB_POOL_RECYCLE`, `DB_POOL_PRE_PING` (applied for non-SQLite backends).
- Answer sequencing lookups are indexed with `idx_answers_attempt_question (attempt_id, question_id)` for submit flow performance.
- `/api/v1/admin/import/questions` enforces upload safety limits (max file size/rows/JSON depth+nodes, file-type checks).
- Attempt finish is idempotent and persists `score_percent`, `answered_count`, `correct_answers`, `finished_at` server-side.
