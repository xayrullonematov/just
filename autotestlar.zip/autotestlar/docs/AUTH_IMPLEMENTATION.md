# 1) FILE TREE (added/changed)

```text
apps/api/
  alembic/versions/0002_auth_tables.py
  alembic/versions/0003_security_2fa.py
  app/core/config.py
  app/core/security.py
  app/api/routes.py
  app/models/models.py
  tests/test_auth_api.py
apps/web/
  middleware.ts
  lib/api.ts
  app/page.tsx
  app/app/page.tsx
  app/login/page.tsx
  app/signup/page.tsx
  app/forgot-password/page.tsx
  app/reset-password/page.tsx
  app/verify-email/page.tsx
  app/verify-success/page.tsx
  app/tickets/page.tsx
  app/notifications/page.tsx
```

# 2) DB SCHEMA CHANGES
Migration: `0002_auth_tables.py`
- `users.created_at` added
- `sessions(id,user_id,refresh_token_hash,created_at,expires_at,revoked_at)` + unique index on `refresh_token_hash`
- `email_verifications(id,user_id,token_hash,expires_at,used_at)` + unique index on `token_hash`
- `password_resets(id,user_id,token_hash,expires_at,used_at)` + unique index on `token_hash`
- `users.twofa_enabled`, `users.twofa_secret`
- `recovery_codes(code_hash unique, used_at)`
- `security_audit_events` append-only log table

# 3) API ENDPOINTS (Auth)
- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/verify-email`
- `POST /api/v1/auth/login`
- `POST /api/v1/auth/refresh`
- `POST /api/v1/auth/logout`
- `POST /api/v1/auth/forgot-password`
- `POST /api/v1/auth/reset-password`
- `POST /api/v1/auth/2fa/setup`
- `POST /api/v1/auth/2fa/enable`
- `POST /api/v1/auth/2fa/verify`
- `POST /api/v1/auth/logout-all`
- `GET /api/v1/auth/csrf`
- `GET /api/v1/me`
- `DELETE /api/v1/me`

Error format (all):
```json
{"error":{"code":"...","message":"...","field":null,"details":{}}}
```

Main auth error codes:
- `VALIDATION_ERROR`
- `TWO_FA_REQUIRED`
- `TWO_FA_INVALID`
- `WEAK_PASSWORD`
- `EMAIL_TAKEN`
- `EMAIL_NOT_VERIFIED`
- `AUTH_FAILED`
- `UNAUTHORIZED`
- `CSRF_INVALID`
- `TOKEN_INVALID`
- `RATE_LIMITED`

# 4) Frontend integration
- Cookies are HttpOnly and set by API (`access_token`, `refresh_token`).
- CSRF flow: frontend calls `GET /auth/csrf`, reads `csrf_token` cookie, sends header `X-CSRF-Token` for unsafe requests.
- Route protection uses Next middleware (`apps/web/middleware.ts`) with public/protected split; protected paths redirect to `/login`.

# 5) Tests
- `apps/api/tests/test_auth_api.py`
  - signup -> verify -> login -> me
  - unverified cannot login
  - refresh rotates token
  - logout works
  - forgot/reset flow and old password invalidation

# 6) RUNBOOK
```bash
# Start stack
docker compose up --build

# Migrate
cd apps/api
alembic upgrade head

# Seed demo data
python scripts_seed.py

# Run API tests
PYTHONPATH=. pytest -q
```

Dev links:
- signup returns `verification_link` in response when `app_env=dev`
- forgot-password returns `reset_link` in response when `app_env=dev`

## Assumptions
- Dev mode returns verification/reset links in API response; email logger redacts tokenized body output.
- `SameSite=lax` default for local dev; set `cookie_secure=true` in production behind HTTPS.
