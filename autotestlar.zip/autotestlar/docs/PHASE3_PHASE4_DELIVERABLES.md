# PHASE 3 & PHASE 4 DELIVERABLES

## 1) Page Map Table

| HTML | Next route | Purpose | Dynamic data | API endpoints | DB tables |
|---|---|---|---|---|---|
| auto-testlar-landing.html | `/` | Landing | public counts | `GET /api/v1/public/metrics` | users, tests, questions |
| login/signup/reset/etc | `/login`, `/signup`, `/forgot-password`, `/reset-password`, `/verify-email`, `/verify-success` | Auth lifecycle | auth state/errors | `/api/v1/auth/*` | users, sessions, email_verifications, password_resets |
| main-dashboard.html | `/app` | User overview | stats + daily tasks + weekly | `GET /api/v1/me`, `GET /api/v1/me/dashboard` | users, attempts, answers, tests |
| biletlar.html | `/tickets` | Ticket catalog | tests/progress | `GET /api/v1/tests?type=ticket&include_progress=1` | tests, attempts |
| imtihon.html | `/exam/[testId]` | Exam flow | current question/timer | `POST /api/v1/attempts/start`, `GET /api/v1/attempts/{id}/current`, `POST /api/v1/attempts/{id}/answer`, `POST /api/v1/attempts/{id}/finish` | attempts, attempt_questions, answers |
| korib-chiqish.html | `/review/[attemptId]` | Attempt review | chosen vs correct | `GET /api/v1/attempts/{id}/review` | answers, correct_answers |
| mashq/kunlik | `/practice`, `/daily` | Practice and daily start | start state/errors | `POST /api/v1/attempts/start`, `POST /api/v1/daily/start` | attempts, tests |
| xatolarim | `/mistakes` | Wrong-answer history | mistakes list | `GET /api/v1/me/mistakes` | attempts, answers, tests |
| profile/edit-pic/delete | `/profile`, `/settings/delete` | Account management | profile + avatar + delete | `GET /api/v1/me`, `POST /api/v1/me/avatar`, `DELETE /api/v1/me`, `POST /api/v1/auth/logout-all` | users, sessions |
| notifications | `/notifications` | Notification center | list + read state | `GET /api/v1/me/notifications`, `POST /api/v1/me/notifications/{id}/read` | notifications |
| two-factor-auth | `/security` | Security center | 2FA secret/codes/session status | `POST /api/v1/auth/2fa/setup`, `POST /api/v1/auth/2fa/enable`, `POST /api/v1/auth/refresh` | users, recovery_codes, sessions |
| admin import | `/admin/import` | Question import | upload status | `POST /api/v1/admin/import/questions` | tests, questions, options, correct_answers |

## 2) Folder Structure

```text
apps/
  api/
    alembic/
      versions/
        0001_init.py
        0002_auth_tables.py
        0003_security_2fa.py
        0004_phase3_page_map.py
    app/
      api/routes.py
      core/{config.py,security.py,email_service.py,rate_limit.py}
      db/{base.py,session.py}
      models/models.py
      services/attempts.py
    tests/{test_attempt_engine.py,test_auth_api.py}
  web/
    app/
      admin/import/page.tsx
      app/page.tsx
      daily/page.tsx
      exam/[testId]/page.tsx
      login/page.tsx
      mistakes/page.tsx
      notifications/page.tsx
      practice/page.tsx
      profile/page.tsx
      review/[attemptId]/page.tsx
      security/page.tsx
      settings/delete/page.tsx
      ...
    lib/api.ts
    middleware.ts
docs/
  PHASE3_PHASE4_DELIVERABLES.md
  PROJECT_BLUEPRINT.md
```

## 3) Key Code Files (what they do)

- `apps/api/app/api/routes.py`
  - Added page-map endpoints: `/public/metrics`, `/me/dashboard`, `/me/avatar`, `/daily/start`, `/me/mistakes`, `/me/notifications/{id}/read`.
  - Keeps auth/session/2FA/attempt/import routes in one router.
- `apps/api/app/models/models.py`
  - Added `users.avatar_url` to support profile/avatar UI.
- `apps/api/alembic/versions/0004_phase3_page_map.py`
  - Migration for `users.avatar_url`.
- `apps/web/app/app/page.tsx`
  - Dashboard now consumes real `/me/dashboard` data while preserving existing layout.
- `apps/web/app/daily/page.tsx`
  - Uses dedicated `/daily/start` endpoint.
- `apps/web/app/mistakes/page.tsx`
  - Uses `/me/mistakes` endpoint.
- `apps/web/app/notifications/page.tsx`
  - Adds "mark as read" via `/me/notifications/{id}/read`.
- `apps/web/app/profile/page.tsx`
  - Adds avatar update wiring via `/me/avatar`.

## 4) Run Locally with Docker

```bash
# from repo root
cd /workspace/web

docker compose up --build

# API shell (separate terminal if needed)
cd apps/api
alembic upgrade head
python scripts_seed.py
PYTHONPATH=. pytest -q

# Web build (optional check)
npm --prefix apps/web run build
```

## 5) UI Parity Notes (by page)

- `/app` dashboard: **layout preserved**; data source switched to `/me/dashboard`.
- `/tickets`, `/exam/[testId]`, `/review/[attemptId]`: **layout preserved**, backend wiring completed.
- `/practice`, `/daily`, `/mistakes`, `/notifications`, `/profile`: **same simple layout style retained**; now backed by dedicated endpoints.
- `/security` and `/admin/import`: **styled to match project card/gradient visual language** (not generic bare controls).
- Auth pages (`/login`, `/signup`, `/forgot-password`, `/reset-password`, `/verify-email`, `/verify-success`): **existing structure retained**; login includes 2FA challenge path.

## 6) Screen-by-screen working checklist

- [x] Landing metrics loads from backend.
- [x] Signup/login/logout/refresh/forgot/reset works.
- [x] Login handles 2FA challenge verify path.
- [x] Dashboard loads user overview data.
- [x] Tickets list works.
- [x] Practice start works.
- [x] Daily start works via `/daily/start`.
- [x] Exam current question/answer/finish works.
- [x] Review route works.
- [x] Mistakes list works via `/me/mistakes`.
- [x] Notifications list + mark-as-read works.
- [x] Profile fetch + avatar update + logout-all works.
- [x] Delete-account works.
- [x] Security page 2FA setup/enable/refresh actions wired.
- [x] Admin import upload wired.
