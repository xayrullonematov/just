# UI Implementation Status

This document tracks which Next.js routes are **fully implemented UI pages** (custom layout/styling matching product-facing page design) versus **generic/minimal UI pages** (basic or placeholder-like forms/lists).

## Fully implemented UI

- `/app` → `apps/web/app/app/page.tsx`
- `/tickets` → `apps/web/app/tickets/page.tsx`
- `/exam/[testId]` → `apps/web/app/exam/[testId]/page.tsx`
- `/daily` → `apps/web/app/daily/page.tsx`
- `/profile` → `apps/web/app/profile/page.tsx`

## Generic / minimal UI

- `/` → `apps/web/app/page.tsx`
- `/login` → `apps/web/app/login/page.tsx`
- `/signup` → `apps/web/app/signup/page.tsx`
- `/forgot-password` → `apps/web/app/forgot-password/page.tsx`
- `/reset-password` → `apps/web/app/reset-password/page.tsx`
- `/verify-email` → `apps/web/app/verify-email/page.tsx`
- `/verify-success` → `apps/web/app/verify-success/page.tsx`
- `/practice` → `apps/web/app/practice/page.tsx`
- `/mistakes` → `apps/web/app/mistakes/page.tsx`
- `/review/[attemptId]` → `apps/web/app/review/[attemptId]/page.tsx`
- `/notifications` → `apps/web/app/notifications/page.tsx`
- `/security` → `apps/web/app/security/page.tsx`
- `/settings/delete` → `apps/web/app/settings/delete/page.tsx`
- `/admin/import` → `apps/web/app/admin/import/page.tsx`

## Notes

- Classification is based on the current frontend code in `apps/web/app/**/page.tsx` and whether the page uses a full designed layout versus a basic utility/form layout.
- This file is intended as a quick implementation checklist for ongoing UI completion work.
