# AUTH CHECKLIST STATUS

## 1️⃣ CORE AUTH FLOWS
- [x] Signup works end-to-end
- [x] Email verification required before login
- [x] Login works and sets auth cookies
- [x] Logout revokes session and clears cookies
- [x] Forgot-password flow issues reset token
- [x] Reset-password validates token and updates password
- [x] Delete account supported (soft delete + anonymize)

## 2️⃣ DATABASE STRUCTURE
- [x] users: email unique, password_hash, is_email_verified, created_at, deleted_at
- [x] sessions: refresh_token_hash, expires_at, revoked_at + unique index
- [x] email_verifications: token_hash unique, expires_at, used_at
- [x] password_resets: token_hash unique, expires_at, used_at

## 3️⃣ TOKEN & SESSION MECHANICS
- [x] HTTP-only cookies
- [x] Access token short-lived
- [x] Refresh token long-lived
- [x] Refresh rotation
- [x] Logout revokes refresh token
- [x] Password reset revokes all sessions

## 4️⃣ COOKIES & CSRF
- [x] HttpOnly/Secure(prod configurable)/SameSite cookies
- [x] CSRF enabled for unsafe auth+attempt requests
- [x] CSRF endpoint exists
- [x] Frontend sends `X-CSRF-Token`
- [x] CORS configured

## 5️⃣ API ENDPOINTS (MINIMUM)
- [x] POST /api/v1/auth/signup
- [x] POST /api/v1/auth/verify-email
- [x] POST /api/v1/auth/login
- [x] POST /api/v1/auth/refresh
- [x] POST /api/v1/auth/logout
- [x] POST /api/v1/auth/forgot-password
- [x] POST /api/v1/auth/reset-password
- [x] GET /api/v1/me

## 6️⃣ SECURITY BASELINE
- [x] Password hashing with argon2
- [x] Rate limiting for login/signup/forgot+reset
- [x] Tokens random/hashed/single-use/expiring
- [x] Sensitive token payloads not logged by email service

## 7️⃣ FRONTEND INTEGRATION
- [x] Public auth routes
- [x] Protected route guard
- [x] Redirect unauthenticated -> /login
- [x] Redirect authenticated away from /login,/signup
- [x] Loading/error/success states on auth pages

## 8️⃣ EMAIL DELIVERY
- [x] Dev mode returns verification/reset links for local testing
- [x] Production provider path configured (SMTP env wiring)
- [x] Email templates exist (render functions)

## 9️⃣ OPTIONAL BUT RECOMMENDED
- [x] 2FA (TOTP)
- [x] Recovery codes
- [x] Log out all devices endpoint
- [x] Security audit events

## 🔟 TEST GATE
- [x] Signup creates unverified user
- [x] Verify-email token expires
- [x] Unverified users cannot login
- [x] Refresh rotates token
- [x] Logout invalidates session
- [x] Reset password revokes sessions
- [x] Rate limits enforced

## FINAL AUTH GATE
ALL CHECKED → AUTH READY
