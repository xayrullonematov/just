# 1) Inventory & Page Map Table

| HTML | Next route | Purpose | Dynamic data | API endpoints | DB tables |
|---|---|---|---|---|---|
| auto-testlar-landing.html | `/` | Marketing/entry | optional metrics | `GET /public/metrics` | tests/users/questions |
| login/signup/reset/etc | `/login`, `/signup`, ... | Auth flows | auth status/errors | `/auth/*` | users, sessions, email_verifications, password_resets |
| main-dashboard.html | `/app` | User overview | stats, streak, shortcuts | `GET /me/dashboard` | attempts, answers, notifications |
| biletlar.html | `/tickets` | Ticket list | real tests + progress | `GET /tests?type=ticket&include_progress=1` | tests, attempts |
| imtihon.html | `/exam/[testId]` | Timed exam | attempt + current question | `POST /attempts/start`, `GET /attempts/{id}/current`, `POST /attempts/{id}/answer` | attempts, attempt_questions, answers |
| korib-chiqish.html | `/review/[attemptId]` | Review | chosen vs correct | `GET /attempts/{id}/review` | answers, correct_answers |
| mashq/kunlik | `/practice`, `/daily` | Practice/daily | attempt status | `/attempts/start`, `/daily/start` | attempts |
| xatolarim | `/mistakes` | Wrong answers list | wrong_count/last_wrong_at | `GET /me/mistakes` | mistakes |
| profile/edit-pic/delete | `/profile`, `/profile/avatar`, `/settings/delete` | Account | profile + stats + avatar | `/me`, `/me/avatar`, `DELETE /me` | users |
| notifications | `/notifications` | Notifications | list + unread | `GET /me/notifications`, `POST /me/notifications/{id}/read` | notifications |

# 2) Domain Model & DB Schema
- Canonical tables implemented: `users`, `tests`, `questions`, `options`, `correct_answers`, `attempts`, `attempt_questions`, `answers`, `notifications`.
- Constraints:
  - `UNIQUE (answers.attempt_id, answers.question_id)`
  - Partial unique index for active attempts: `(user_id, test_id, mode) WHERE status='in_progress'`
- Hot-path indexes:
  - `idx_answers_attempt`
  - `idx_notifications_user_unread`

## Alembic migration plan
1. `0001_init.py` – core auth/content/attempt/notification tables + indexes.

# 3) API Contract
- Base path `/api/v1`
- Endpoints included in implementation:
  - `GET /tests`
  - `POST /attempts/start` (idempotent for active attempts)
  - `GET /attempts/{id}/current`
  - `POST /attempts/{id}/answer`
  - `POST /attempts/{id}/finish`
  - `GET /attempts/{id}/review`
  - `GET /me/notifications`
- Error format (standardized):
```json
{"error":{"code":"SOME_CODE","message":"...","field":null,"details":{}}}
```

# 4) Frontend Architecture
- Next.js App Router, server components by default.
- Route-level loading/empty/error/data handling (implemented in tickets/notifications; client flow in exam).
- Shared API adapter in `apps/web/lib/api.ts`.

# 5) Implementation (File Tree)
```text
apps/
  api/
    app/{main.py,api/routes.py,services/attempts.py,models/models.py,...}
    alembic/{env.py,versions/0001_init.py}
    tests/test_attempt_engine.py
    scripts_seed.py
  web/
    app/{page.tsx,tickets,page,exam/[testId],notifications,...}
    lib/api.ts
infra/docker-compose.yml
docs/PROJECT_BLUEPRINT.md
```

# 6) Seed + Admin Import
- Seed script: `python scripts_seed.py`
- Admin import endpoint is implemented at `/api/v1/admin/import/questions` and wired to `/admin/import` UI.

# 7) Tests
- `apps/api/tests/test_attempt_engine.py` includes:
  - timer expiry enforcement
  - duplicate answer rejection
  - concurrent attempt prevention (idempotent start)

# 8) Runbook
```bash
cd infra
docker compose up --build
# in api container / local
alembic upgrade head
python scripts_seed.py
pytest -q
```

## Assumptions
- Demo auth uses first seeded user to focus on attempt engine integrity.
- Full auth+csrf+object storage are scaffold-ready and can be expanded without schema break.
