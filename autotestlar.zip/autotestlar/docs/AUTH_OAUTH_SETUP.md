# OAuth + Telegram Auth Local Setup

## Environment variables

### Backend (`apps/api`)

```env
DATABASE_URL=postgresql+psycopg://postgres:postgres@db:5432/autotestlar
FRONTEND_URL=http://localhost:3000
BACKEND_URL=http://localhost:8000
COOKIE_DOMAIN=
COOKIE_SECURE=false
COOKIE_SAMESITE=lax
SESSION_TTL_DAYS=30
CSRF_COOKIE_NAME=csrf_token
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
TELEGRAM_BOT_TOKEN=
TELEGRAM_BOT_USERNAME=
TELEGRAM_AUTH_MAX_AGE_SECONDS=86400
```

### Frontend (`apps/web`)

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_GOOGLE_CLIENT_ID=
NEXT_PUBLIC_TELEGRAM_BOT_USERNAME=
```

## Google Cloud Console Redirect URI

Set the OAuth redirect URI to:

- `http://localhost:8000/api/v1/auth/google/callback`

## Telegram Widget setup

Use the same bot configured in backend:

- `TELEGRAM_BOT_USERNAME` / `NEXT_PUBLIC_TELEGRAM_BOT_USERNAME`

The login page uses Telegram official widget script and sends the signed payload to:

- `POST /api/v1/auth/telegram/callback`

## Docker compose

Run:

```bash
docker compose up --build
```

## Manual verification checklist

1. Open `http://localhost:3000/login`
2. Click **Google orqali kirish** → complete Google auth → redirected to `/app`.
3. Login with Telegram widget → redirected to `/app`.
4. Verify `GET http://localhost:8000/api/v1/auth/me` returns user JSON while logged in.
5. `POST /api/v1/auth/logout` with CSRF clears auth cookies.
6. Open protected page (`/app`) while logged out and verify redirect to `/login`.
